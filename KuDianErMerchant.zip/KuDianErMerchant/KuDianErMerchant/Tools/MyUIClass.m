//
//  MyUIClass.m
//  UIClass
//
//  Created by william on 2018/6/26.
//  Copyright © 2018年 william. All rights reserved.
//

#import "MyUIClass.h"

@implementation MyUIClass

+(UIView*)makeUIViewWithFrame:(CGRect)rect andBackColor:(UIColor *)color
{
    UIView *view = [[UIView alloc] initWithFrame:rect];
    view.backgroundColor = color;
    return view;
}

+(UILabel*)makeUILabelWithFrame:(CGRect)rect andBackColor:(UIColor *)backColor andText:(NSString *)text andTextColor:(UIColor *)textColor andFontSize:(CGFloat )FontSize andAlignment:(NSTextAlignment)alignment
{
    UILabel *lab = [[UILabel alloc] initWithFrame:rect];
    lab.text = text;
    lab.backgroundColor = backColor;
    lab.textColor = textColor;
//    lab.font = font;
    if (Screen_W  <= 320) {
        lab.font = [UIFont systemFontOfSize:FontSize-5.0];
    }else{
        lab.font = [UIFont systemFontOfSize:FontSize];
    }
    lab.textAlignment = alignment;
    
    return lab;
}

//UILabel~~~~
+(UILabel*)creatUILabelWithFrame:(CGRect)rect andBackColor:(UIColor*)backColor andTextColor:(UIColor*)textColor andFontSize:(CGFloat )FontSize andAlignment:(NSTextAlignment)alignment{
    UILabel *lab = [[UILabel alloc] initWithFrame:rect];
    lab.backgroundColor = backColor;
    lab.textColor = textColor;
    //    lab.font = font;
    if (Screen_W  <= 320) {
        lab.font = [UIFont systemFontOfSize:FontSize-4.0];
    }else{
        lab.font = [UIFont systemFontOfSize:FontSize];
    }
    lab.textAlignment = alignment;
    
    return lab;
}

//UILabel~~~~~~~~
+(UILabel*)simpleLabelWithFrame:(CGRect)rect andText:(NSString*)text andTextColor:(UIColor*)textColor andFontSize:(CGFloat )FontSize andAlignment:(NSTextAlignment)alignment{
    UILabel *lab = [[UILabel alloc] initWithFrame:rect];
    lab.text = text;
    lab.textColor = textColor;
    lab.numberOfLines = 0;
    if (Screen_W  <= 320) {
        lab.font = [UIFont systemFontOfSize:FontSize-4.0];
    }else{
        lab.font = [UIFont systemFontOfSize:FontSize];
    }
    lab.textAlignment = alignment;
    
    return lab;
}

+(UIImageView*)makeUIImageWithFrame:(CGRect)rect andPicName:(NSString *)imageName
{
    UIImageView *img = [[UIImageView alloc] initWithFrame:rect];
    img.image = [UIImage imageNamed:imageName];
    return img;
}

+(UITextField*)makeUITextFieldWithFrame:(CGRect)rect andDelegate:(id)target andBorderStyle:(UITextBorderStyle)borderStyle andPlaceHolder:(NSString *)holder andSecu:(BOOL)isSecu andLeftView:(UIView *)leftView andLeftViewMode:(UITextFieldViewMode)leftViewMode andRightView:(UIView *)rightView andRightViewMode:(UITextFieldViewMode)rightViewMode andClearBtnMode:(UITextFieldViewMode)clearMode andAutoCorrect:(UITextAutocorrectionType)correctType andAutoCapital:(UITextAutocapitalizationType)capitalType andKeyboardType:(UIKeyboardType)keyboard andReturnType:(UIReturnKeyType)returnKey andInputView:(UIView *)inputView
{
    UITextField *text = [[UITextField alloc] initWithFrame:rect];
    text.placeholder = holder;
    text.delegate = target;
    text.secureTextEntry = isSecu;
    text.borderStyle = borderStyle;
    text.leftView = leftView;
    text.leftViewMode = leftViewMode;
    text.rightView = rightView;
    text.rightViewMode = rightViewMode;
    text.clearButtonMode = clearMode;
    text.autocorrectionType = correctType;
    text.autocapitalizationType = capitalType;
    text.keyboardType = keyboard;
    text.returnKeyType = returnKey;
    text.inputView = inputView;
    return text;
}

+(UITextField*)creatTextFieldWithFrame:(CGRect)rect
                        andPlaceHolder:(NSString*)holder
                               andSecu:(BOOL)isSecu
                           andLeftView:(UIView*)leftView
                       andLeftViewMode:(UITextFieldViewMode)leftViewMode
                       andLeftViewFrame:(CGRect)rectt
                       andClearBtnMode:(UITextFieldViewMode)clearMode
                       andKeyboardType:(UIKeyboardType)keyboard
                         andReturnType:(UIReturnKeyType)returnKey
                          andimageView:(UIImageView *)imagev
                     andimageViewFrame:(CGRect )imagevRect
                     andimageViewImage:(NSString * )imageString
                          andBackColor:(UIColor *)backColor{
    
    UITextField *text = [[UITextField alloc] initWithFrame:rect];
    text.placeholder = holder;
    text.secureTextEntry = isSecu;
    leftView.frame = rectt;
    text.leftView = leftView;
    text.leftViewMode = leftViewMode;
    [leftView addSubview:imagev];
    imagev.frame = imagevRect;
    text.clearButtonMode = clearMode;
    [imagev setImage:[UIImage imageNamed:imageString]];
    text.keyboardType = keyboard;
    text.returnKeyType = returnKey;
    text.backgroundColor = backColor;
  
    return text;
}

//简单的TextField
+(UITextField*)simpleTextFieldWithFrame:(CGRect)rect
                         andPlaceHolder:(NSString*)holder
                        andClearBtnMode:(UITextFieldViewMode)clearMode
                           andBackColor:(UIColor *)backColor
                            andFontSize:(CGFloat )FontSize{
    UITextField *text = [[UITextField alloc] initWithFrame:rect];
    text.placeholder = holder;
    text.clearButtonMode = clearMode;
    text.backgroundColor = backColor;
    if (Screen_W  <= 320) {
        text.font = [UIFont systemFontOfSize:FontSize-3.0];
    }else{
        text.font = [UIFont systemFontOfSize:FontSize];
    }
    
    
    return text;
}


+(UIButton*)makeUIButtonWithFrame:(CGRect)rect andType:(UIButtonType)type andTitle:(NSString *)title andTitleFontSize:(CGFloat )FontSize andImageName:(NSString *)imageName andTarget:(id)target andSelector:(SEL)selector andEvent:(UIControlEvents)event andState:(UIControlState)state
{
    UIButton *btn = [UIButton buttonWithType:type];
    btn.frame = rect;
    if (Screen_W  <= 320) {
        btn.titleLabel.font = [UIFont systemFontOfSize:FontSize-4.0];
    }else{
        btn.titleLabel.font = [UIFont systemFontOfSize:FontSize];
    }
    //UIButtonTypeCustom = 0
    if(type == 0)
    {
        [btn setImage:[UIImage imageNamed:imageName] forState:state];
    }
    else
    {
        [btn setTitle:title forState:state];
    }
    [btn addTarget:target action:selector forControlEvents:event];
    return btn;
}

+(UIButton*)makeUIButtonWithFrame:(CGRect)rect andType:(UIButtonType)type andTitle:(NSString*)title andTitleFontSize:(CGFloat )FontSize andImageName:(NSString*)imageName andBackColor:(UIColor *)backColor andTarget:(id)target andSelector:(SEL)selector andEvent:(UIControlEvents)event andState:(UIControlState)state
{
    UIButton *btn = [UIButton buttonWithType:type];
    btn.frame = rect;
    btn.backgroundColor = backColor;
    if (Screen_W  <= 320) {
        btn.titleLabel.font = [UIFont systemFontOfSize:FontSize-4.0];
    }else{
        btn.titleLabel.font = [UIFont systemFontOfSize:FontSize];
    }
    //UIButtonTypeCustom = 0
    
    [btn setImage:[UIImage imageNamed:imageName] forState:state];
    
    [btn setTitle:title forState:state];
    
    [btn addTarget:target action:selector forControlEvents:event];
    return btn;
}


//有文字按钮
+(UIButton*)makeTitleButtonWithFrame:(CGRect)rect andType:(UIButtonType)type andBackColor:(UIColor *)backColor andTitle:(NSString*)title andTitleFontSize:(CGFloat )FontSize andTitleColor:(UIColor *)titleColor  andTarget:(id)target andSelector:(SEL)selector andEvent:(UIControlEvents)event andState:(UIControlState)state{
    
    UIButton *btn = [UIButton buttonWithType:type];
    btn.frame = rect;
    btn.backgroundColor = backColor;
    [btn setTitle:title forState:state];
    if (Screen_W  <= 320) {
        btn.titleLabel.font = [UIFont systemFontOfSize:FontSize-3.0];
    }else{
        btn.titleLabel.font = [UIFont systemFontOfSize:FontSize];
    }
    [btn setTitleColor:titleColor forState:state];
    [btn addTarget:target action:selector forControlEvents:event];
    
    return btn;
}

//图片按钮
+(UIButton*)makeImageButtonWithFrame:(CGRect)rect andType:(UIButtonType)type andImageName:(NSString*)imageName andTarget:(id)target andSelector:(SEL)selector andEvent:(UIControlEvents)event andState:(UIControlState)state{
    
    UIButton *btn = [UIButton buttonWithType:type];
    btn.frame = rect;
    [btn setImage:[UIImage imageNamed:imageName] forState:state];
    [btn addTarget:target action:selector forControlEvents:event];
    
    return btn;
}
//+(UIAlertView*)makeUIAlertView:(NSString *)messsage andTarget:(id)target
//{
//    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:messsage message:@"" delegate:target cancelButtonTitle:@"好的" otherButtonTitles: nil];
//    [alert show];
//    return alert;
//}

//判断手机号码格式是否正确
+ (BOOL)valiMobile:(NSString *)mobile{
    mobile = [mobile stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    NSString *NUM = @"^1[3456789]\\d{9}$";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", NUM];
    BOOL isMatch = [pred evaluateWithObject:mobile];
    
    if (isMatch) {
        return YES;
    }else{
        return NO;
    }
    
}

@end



