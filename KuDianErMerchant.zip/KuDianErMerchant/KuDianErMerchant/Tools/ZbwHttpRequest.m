//
//  ZbwHttpRequest.m
//  networkingBao
//
//  Created by william on 2018/9/14.
//  Copyright © 2018年 william. All rights reserved.
//

#import "ZbwHttpRequest.h"
#import "DFYSVP.h"

@implementation ZbwHttpRequest

static ZbwHttpRequest * webUtil = nil;

+ (ZbwHttpRequest *) shardWebUtil
{
    @synchronized([ZbwHttpRequest class])
    {
        if (!webUtil) {
            webUtil = [[[self class] alloc] init];
        }
        return webUtil;
    }
    return nil;
}

#pragma mark 检测网路状态
+ (void)netWorkStatus{
    
    /**
     *  AFNetworkReachabilityStatusUnknown          = -1,  // 未知
     *  AFNetworkReachabilityStatusNotReachable     = 0,   // 无连接
     *  AFNetworkReachabilityStatusReachableViaWWAN = 1,   // 3G
     *  AFNetworkReachabilityStatusReachableViaWiFi = 2,   // 局域网络Wifi
     */
    // 如果要检测网络状态的变化, 必须要用检测管理器的单例startMoitoring
    
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    // 检测网络连接的单例,网络变化时的回调方法
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        if(status == AFNetworkReachabilityStatusNotReachable){
            //            [UIView showAlertMsg:@"网络连接已断开，请检查您的网络！"];
            
            return ;
        }
    }];
    
}

#pragma mark - AFnetworking manager getter

- (AFHTTPSessionManager *)createAFHTTPSessionManager
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    //设置请求参数的类型:HTTP (AFJSONRequestSerializer,AFHTTPRequestSerializer)
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    //设置请求的超时时间
    manager.requestSerializer.timeoutInterval = 20.f;
    //设置服务器返回结果的类型:JSON (AFJSONResponseSerializer,AFHTTPResponseSerializer)
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html",@"text/plain", nil];
    
    //设置Header
    NSString *deviceUUID = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    [manager.requestSerializer setValue:deviceUUID forHTTPHeaderField:@"device-udid"];
    [manager.requestSerializer setValue:@"iPhone"forHTTPHeaderField:@"device-client"];
    [manager.requestSerializer setValue:@"6015"forHTTPHeaderField:@"device-code"];
    [manager.requestSerializer setValue:@"1.6"forHTTPHeaderField:@"api-version"];
    
    return manager;
}




/**
 *JSON方式获取数据 GET
 *url_path:获取数据的url地址
 *有返回值 类型
 */
- (void)getNetworkRequestURLString:(NSString *)url_path parameters:(id)parameters success:(void (^)(id obj))success fail:(void (^)(NSError *error))fail{
    DFYSVPLoading(@"请稍后...", NO);
    AFHTTPSessionManager *manager = [self createAFHTTPSessionManager];
    [manager GET:url_path parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [DFYSVP dismiss];
        success(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [DFYSVP dismiss];
        fail(error);
    }];
}

- (void)getNoLoadingNetworkRequestURLString:(NSString *)url_path parameters:(id)parameters success:(void (^)(id obj))success fail:(void (^)(NSError *error))fail{

    AFHTTPSessionManager *manager = [self createAFHTTPSessionManager];
    [manager GET:url_path parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {

        success(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {

        fail(error);
    }];
}

/**
 *JSON方式获取数据 POST
 *url_path:获取数据的url地址
 *有返回值 类型
 */
- (void)postNetworkRequestURLString:(NSString *)url_path parameters:(id)parameters success:(void (^)(id obj))success successOne:(void (^)(id responseObject))successOne successZero:(void (^)(id responseObject))successZero fail:(void (^)(NSError *error))fail{
    
    DFYSVPLoading(@"请稍后...", NO);
    
    AFHTTPSessionManager *manager = [self createAFHTTPSessionManager];
    

    [manager POST:url_path parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress){
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [DFYSVP dismiss];
        success(responseObject);
        
        NSString * suc = [NSString stringWithFormat:@"%@",responseObject[@"status"][@"succeed"]];
        
        if ([suc isEqual:@"1"]) {
            
            successOne(responseObject);
            
        }else{
            
            successZero(responseObject);
        }
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [DFYSVP dismiss];
        fail(error);
    }];
}










@end
