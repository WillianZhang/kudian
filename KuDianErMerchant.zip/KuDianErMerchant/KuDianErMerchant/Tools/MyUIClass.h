//
//  MyUIClass.h
//  UIClass
//
//  Created by william on 2018/6/26.
//  Copyright © 2018年 william. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface MyUIClass : NSObject//UI工厂类

//UIView
+(UIView*)makeUIViewWithFrame:(CGRect)rect andBackColor:(UIColor*)color;

//UILabel
+(UILabel*)makeUILabelWithFrame:(CGRect)rect andBackColor:(UIColor*)backColor andText:(NSString*)text andTextColor:(UIColor*)textColor andFontSize:(CGFloat )FontSize andAlignment:(NSTextAlignment)alignment;

//UILabel~~~~
+(UILabel*)creatUILabelWithFrame:(CGRect)rect andBackColor:(UIColor*)backColor andTextColor:(UIColor*)textColor andFontSize:(CGFloat )FontSize andAlignment:(NSTextAlignment)alignment;

//UILabel~~~~~~~~~
+(UILabel*)simpleLabelWithFrame:(CGRect)rect andText:(NSString*)text andTextColor:(UIColor*)textColor andFontSize:(CGFloat )FontSize andAlignment:(NSTextAlignment)alignment;

//UIImageView
+(UIImageView*)makeUIImageWithFrame:(CGRect)rect andPicName:(NSString*)imageName;

+(UITextField*)makeUITextFieldWithFrame:(CGRect)rect andDelegate:(id)target andBorderStyle:(UITextBorderStyle)borderStyle andPlaceHolder:(NSString*)holder andSecu:(BOOL)isSecu andLeftView:(UIView*)leftView andLeftViewMode:(UITextFieldViewMode)leftViewMode andRightView:(UIView*)rightView andRightViewMode:(UITextFieldViewMode)rightViewMode andClearBtnMode:(UITextFieldViewMode)clearMode andAutoCorrect:(UITextAutocorrectionType)correctType andAutoCapital:(UITextAutocapitalizationType)capitalType andKeyboardType:(UIKeyboardType)keyboard andReturnType:(UIReturnKeyType)returnKey andInputView:(UIView*)inputView;

+(UITextField*)creatTextFieldWithFrame:(CGRect)rect
                        andPlaceHolder:(NSString*)holder
                               andSecu:(BOOL)isSecu
                           andLeftView:(UIView*)leftView
                       andLeftViewMode:(UITextFieldViewMode)leftViewMode
                      andLeftViewFrame:(CGRect)rectt
                       andClearBtnMode:(UITextFieldViewMode)clearMode
                       andKeyboardType:(UIKeyboardType)keyboard
                         andReturnType:(UIReturnKeyType)returnKey
                          andimageView:(UIImageView *)imagev
                     andimageViewFrame:(CGRect )imagevRect
                     andimageViewImage:(NSString * )imageString
                          andBackColor:(UIColor *)backColor;

//简单的TextField
+(UITextField*)simpleTextFieldWithFrame:(CGRect)rect
                         andPlaceHolder:(NSString*)holder
                        andClearBtnMode:(UITextFieldViewMode)clearMode
                           andBackColor:(UIColor *)backColor
                            andFontSize:(CGFloat )FontSize;


+(UIButton*)makeUIButtonWithFrame:(CGRect)rect andType:(UIButtonType)type andTitle:(NSString*)title andTitleFontSize:(CGFloat )FontSize andImageName:(NSString*)imageName andTarget:(id)target andSelector:(SEL)selector andEvent:(UIControlEvents)event andState:(UIControlState)state;
//加了背景色
+(UIButton*)makeUIButtonWithFrame:(CGRect)rect andType:(UIButtonType)type andTitle:(NSString*)title andTitleFontSize:(CGFloat )FontSize andImageName:(NSString*)imageName andBackColor:(UIColor *)backColor andTarget:(id)target andSelector:(SEL)selector andEvent:(UIControlEvents)event andState:(UIControlState)state;

+(UIButton*)makeTitleButtonWithFrame:(CGRect)rect andType:(UIButtonType)type andBackColor:(UIColor *)backColor andTitle:(NSString*)title andTitleFontSize:(CGFloat )FontSize andTitleColor:(UIColor *)titleColor  andTarget:(id)target andSelector:(SEL)selector andEvent:(UIControlEvents)event andState:(UIControlState)state;

+(UIButton*)makeImageButtonWithFrame:(CGRect)rect andType:(UIButtonType)type andImageName:(NSString*)imageName andTarget:(id)target andSelector:(SEL)selector andEvent:(UIControlEvents)event andState:(UIControlState)state;

//+(UIAlertView*)makeUIAlertView:(NSString *)messsage andTarget:(id)target;
//-(void)creatAlertWithTitle:(NSString *)title andMessage:(NSString *)message andActionTitle:(NSString *)actionDefault andStyle:(UIAlertActionStyle )DefaultStyle andCancelActionTitle:(NSString *)actionCancel andCancelStyle:(UIAlertActionStyle )CancelStyle Default:(void (^)())fault Cancel:(void (^)())cancel;
//判断手机号码格式是否正确
+ (BOOL)valiMobile:(NSString *)mobile;

@end






