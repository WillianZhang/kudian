//
//  ZbwHttpRequest.h
//  networkingBao
//
//  Created by william on 2018/9/14.
//  Copyright © 2018年 william. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import <UIKit/UIKit.h>

@interface ZbwHttpRequest : NSObject

+ (ZbwHttpRequest *) shardWebUtil;

/**检测网路状态**/
+ (void)netWorkStatus;

/**
 *JSON方式获取数据 GET
 *url_path:获取数据的url地址
 *有返回值 类型
 */
- (void)getNetworkRequestURLString:(NSString *)url_path parameters:(id)parameters success:(void (^)(id obj))success fail:(void (^)(NSError *error))fail;

//不带加载菊花
- (void)getNoLoadingNetworkRequestURLString:(NSString *)url_path parameters:(id)parameters success:(void (^)(id obj))success fail:(void (^)(NSError *error))fail;

/**
 *JSON方式获取数据 POST
 *url_path:获取数据的url地址
 *有返回值 类型
 */
- (void)postNetworkRequestURLString:(NSString *)url_path parameters:(id)parameters success:(void (^)(id obj))success successOne:(void (^)(id responseObject))successOne successZero:(void (^)(id responseObject))successZero fail:(void (^)(NSError *error))fail;

@end
