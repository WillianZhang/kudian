//
//  UIButton+EnlargeTouchArea.h
//  MyBigQuan
//
//  Created by 不倒翁 on 16/1/13.
//  Copyright © 2016年 不倒翁. All rights reserved.
//  按钮扩大点击范围  直接引入头文件  需要的按钮处调用下面方法  调节上左下右等扩展距离

#import <UIKit/UIKit.h>

@interface UIButton (EnlargeTouchArea)

- (void)setEnlargeEdgeWithTop:(CGFloat) top right:(CGFloat) right bottom:(CGFloat) bottom left:(CGFloat) left;

@end
