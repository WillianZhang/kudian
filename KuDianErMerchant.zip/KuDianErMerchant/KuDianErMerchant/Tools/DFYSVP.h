//
//  DFYSVP.h
//  ETea
//
//  Created by 东方盈 on 16/6/29.
//  Copyright © 2016年 东方盈. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SVProgressHUD.h"

#define DFYSVPSuccess(msg) [DFYSVP showSVPWithType:DFYSVPTypeSuccess Msg:msg duration:1.0 allowEdit:NO];

#define DFYSVPError(msg) [DFYSVP showSVPWithType:DFYSVPTypeError Msg:msg duration:1.5 allowEdit:NO];

#define DFYSVPInfo(msg)      [DFYSVP showSVPWithType:DFYSVPTypeInfo Msg:msg duration:1.5 allowEdit:NO];

#define DFYSVPLoading(msg,allow) [DFYSVP showSVPWithType:DFYSVPTypeLoadingInterface Msg:msg duration:0 allowEdit:allow];

#define DFYSVPDataError   DFYSVPError(@"错误，请重试")

typedef enum {
    
    //默认无状态
    DFYSVPTypeNone=0,
    
    //无图片普通提示，显示在屏幕正中间
    DFYSVPTypeCenterMsg,
    
    //无图片普通提示，显示在屏幕下方，tabbar之上
    DFYSVPTypeBottomMsg,
    
    //Info
    DFYSVPTypeInfo,
    
    //Progress,可以互
    DFYSVPTypeLoadingInterface,
    
    //error
    DFYSVPTypeError,
    
    //success
    DFYSVPTypeSuccess
    
}DFYSVPType;

@interface DFYSVP : NSObject


/**
 *  展示提示框
 *
 *  @param type          类型
 *  @param msg           文字
 *  @param duration      时间（当type=CoreSVPTypeLoadingInterface时无效）
 *  @param allowEdit     否允许编辑
 */
+(void)showSVPWithType:(DFYSVPType)type Msg:(NSString *)msg duration:(CGFloat)duration allowEdit:(BOOL)allowEdit;

/*
 *  进度
 */
+(void)showProgess:(CGFloat)progress Msg:(NSString *)msg maskType:(SVProgressHUDMaskType)maskType;

/**
 *  隐藏提示框
 */
+(void)dismiss;

@end
