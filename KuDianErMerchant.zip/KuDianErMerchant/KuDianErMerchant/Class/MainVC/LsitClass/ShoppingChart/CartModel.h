//
//  CartModel.h
//  KuDianErMerchant
//
//  Created by william on 2018/8/20.
//  Copyright © 2018年 william. All rights reserved.
//  购物车模型

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CartModel : NSObject

@property (nonatomic,copy) NSString *sizeStr;
@property (nonatomic,copy) NSString *nameStr;
@property (nonatomic,copy) NSString *dateStr;
@property (nonatomic,assign) NSInteger number;
@property (nonatomic,copy) NSString *price;
@property (nonatomic,retain)UIImage *image;
@property (nonatomic,assign) BOOL isSelect;

@property (nonatomic,copy) NSDictionary *img;
@property (nonatomic,copy) NSString *goods_name;
@property (nonatomic,copy) NSString *goods_price;
@property (nonatomic,copy) NSString *goodsNumber;
@property (nonatomic,copy) NSString *rec_id;
@property (nonatomic,copy) NSString *goods_number;
@property (nonatomic,copy) NSString *goods_sn;

@end
//"store_id": "81",
//"rec_id": "2114",
//"user_id": "2",
//"goods_id": "1210",
//"goods_name": "橡皮",
//"goods_sn": "81_ECS001210",
//"goods_number": "1",
//"market_price": "0.01",
//"goods_price": "0.01",
//"goods_attr": [],
//"is_real": "1",
//"extension_code": "",
//"parent_id": "0",
//"is_gift": "0",
//"is_shipping": "1",
//"subtotal": "0.01",
//"goodsWeight": "0.000",
//"goods_attr_id": "",
//"formated_market_price": "￥0.01",
//"formated_goods_price": "￥0.01",
//"formated_subtotal": "￥0.01",
//"attr": "",
//"img": {
//    "thumb": "https://ecjia95079.oss-cn-beijing.aliyuncs.com/images/201807/goods_img/1210_G_1531699203266.jpg",
//    "url": "https://ecjia95079.oss-cn-beijing.aliyuncs.com/images/201807/source_img/1210_G_1531699203266.jpg",
//    "small": "https://ecjia95079.oss-cn-beijing.aliyuncs.com/images/201807/thumb_img/1210_G_1531699203266.jpg"
//},
//"store_name": "配送收银店铺"
//},
