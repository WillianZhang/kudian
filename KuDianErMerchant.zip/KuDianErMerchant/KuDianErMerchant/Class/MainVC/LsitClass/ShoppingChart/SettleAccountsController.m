//
//  SettleAccountsController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//  结账

#import "SettleAccountsController.h"
#import "CartModel.h"
#import "CartTableViewCell.h"
#define  TAG_BACKGROUNDVIEW 100
#import "DFYSVP.h"
#import "LoginController.h"
#import "CreatQrController.h"

@interface SettleAccountsController ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *myTableView;
    UIView *bgView;
    UIView *payStyleView;
    
    UIButton *selectAll;//全选按钮
    
    NSMutableArray *dataArray;//展示数据源数组
    
    BOOL isSelect;//是否全选
    
    NSMutableArray *selectGoods;//已选的商品集合
    NSMutableArray *selectGoods_rec_id;//已选的商品rec_id集合

    UILabel *subtotalPrice;//小计
    UILabel *priceLabel;//实际减现后合计
    UILabel *countLab;//总计数量
    UITextField *moneyFiled;//减现金额
    
    NSString * backOrder_id;
    NSString * backTotalPrice;
    NSString * backOrder_sn;
    
    
    NSMutableArray *clearMutableArray;//盛放购物车商品对应的rec_id。用于对应删除商品
    UIButton *reduced_priceBtn;//减现按钮
    
}
@property(nonatomic, strong) NSMutableArray *countAarray;
@end
@implementation SettleAccountsController

static NSString *inder = @"cellID";

-(void)viewWillAppear:(BOOL)animated
{

    //每次进入购物车的时候把选择的置空
    [selectGoods removeAllObjects];
    [selectGoods_rec_id removeAllObjects];
    isSelect = NO;

    selectAll.selected = NO;
    
    priceLabel.text = [NSString stringWithFormat:@"￥0.00"];
    [self creatCartList];
    
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [UIView animateWithDuration:0.5 animations:^{
        
        self->payStyleView.frame = CGRectMake(0, Screen_H-IPHONE_X_NAV_HEIGHT, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT);
    }];
}

//计算已选中商品金额

-(void)countPrice
{
    double totlePrice = 0.00;
    NSInteger totalcount = 0;
    
    for (CartModel *model in selectGoods) {
        NSInteger count = [model.goods_number integerValue];
        double price = [model.goods_price doubleValue];
        
        totlePrice += price*count;

        totalcount += count;
    }
    
    countLab.text = [NSString stringWithFormat:@"共%ld",totalcount];
    subtotalPrice.text = [NSString stringWithFormat:@"￥%.2f",totlePrice];
    
    if ([moneyFiled.text isEqualToString:@""]) {
       priceLabel.text = [NSString stringWithFormat:@"￥%.2f",totlePrice];
    }else{
   
        double jianxian = [moneyFiled.text doubleValue];
        double lastMoney  = totlePrice - jianxian;
        
        if (lastMoney >= 0) {
            priceLabel.text = [NSString stringWithFormat:@"￥%.2f",lastMoney];
        }else{
            
            [self showAlertWithTitle:@"提示" andMessage:@"输入减现金额超过最大限额" andActionTitle:@"确定" andactionBlock:^{
                
                self-> moneyFiled.text = @"0.1";
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        }
        
    }

}


 //创建测试数据源
-(void)creatData
{
  
    [self creatCartList];
    
    if (myTableView) {
        
        //进入购物车默认点中全选按钮
        [self selectAllBtnClick:selectAll];
        [myTableView reloadData];
    }
    else
    {
        [self setupMainView];
        [self selectAllBtnClick:selectAll];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad]; 
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"结账台";
    
    self.countAarray = [NSMutableArray arrayWithCapacity:13];
    dataArray = [NSMutableArray arrayWithCapacity:13];
    selectGoods = [NSMutableArray arrayWithCapacity:13];
    selectGoods_rec_id =[NSMutableArray arrayWithCapacity:13];
    clearMutableArray = [NSMutableArray arrayWithCapacity:13];
   
   
    //[self setupMainView];
    
    //[self creatData];  //有无数据  显示不同页面
    
    //增加监听，当键盘出现或改变时收出消息
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    //增加监听，当键退出时收出消息
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    //为导航栏添加右侧按钮-清空购物车
   // UIBarButtonItem *clearCart = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"set"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStyleDone target:self action:@selector(clearCartGoods)];

  
}


#pragma mark - 设置底部视图
-(void)setupBottomView
{

    //底部视图的 背景
    bgView = [[UIView alloc]initWithFrame:CGRectMake(0,Screen_H - IPHONE_X_NAV_HEIGHT-k_withBasedIphone6(128), Screen_W, k_withBasedIphone6(128))];
    bgView.backgroundColor = [UIColor whiteColor];
    bgView.layer.borderWidth = 1.0;
    bgView.layer.borderColor = Color(216, 217, 218).CGColor;
    [self.view addSubview:bgView];
    
    UIView *line1 = [MyUIClass makeUIViewWithFrame:CGRectMake(0, 0, Screen_W, 1) andBackColor:Color(216, 217, 218)];
    [bgView addSubview:line1];
    
    //全选按钮
    selectAll = [UIButton buttonWithType:UIButtonTypeCustom];
    selectAll.frame = CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(10), k_withBasedIphone6(60), k_withBasedIphone6(20));
    selectAll.titleLabel.font = [UIFont systemFontOfSize:15];
    [selectAll setTitle:@" 全选" forState:UIControlStateNormal];
    [selectAll setImage:[UIImage imageNamed:@"cart_unSelect_btn"] forState:UIControlStateNormal];
    [selectAll setImage:[UIImage imageNamed:@"cart_selected_btn"] forState:UIControlStateSelected];
    [selectAll setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [selectAll addTarget:self action:@selector(selectAllBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [bgView addSubview:selectAll];
    
    countLab = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(10), k_withBasedIphone6(30), k_withBasedIphone6(20)) andText:@"" andTextColor:Color(50, 50, 50) andFontSize:14.0 andAlignment:NSTextAlignmentRight];
    [bgView addSubview:countLab];
    
    UILabel *descountLab = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(120), k_withBasedIphone6(10), k_withBasedIphone6(100), k_withBasedIphone6(20)) andText:@"件商品   小计：" andTextColor:Color(50, 50, 50) andFontSize:14.0 andAlignment:NSTextAlignmentRight];
    [bgView addSubview:descountLab];
    
    
    subtotalPrice = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(220), k_withBasedIphone6(10), k_withBasedIphone6(90), k_withBasedIphone6(20)) andText:@"" andTextColor:[UIColor redColor] andFontSize:14.0 andAlignment:NSTextAlignmentLeft];
    [bgView addSubview:subtotalPrice];
    
    
    UIView *line2 = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(75), Screen_W, 1) andBackColor:Color(216, 217, 218)];
    [bgView addSubview:line2];
    
    //减现按钮
   CGRect reduced_priceBtnFrame = CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(40), k_withBasedIphone6(60), k_withBasedIphone6(20));
    reduced_priceBtn = [MyUIClass makeTitleButtonWithFrame:reduced_priceBtnFrame andType:UIButtonTypeCustom andBackColor:nil andTitle:@" 减现" andTitleFontSize:15.0 andTitleColor:[UIColor blackColor] andTarget:self andSelector:@selector(reduced_priceBtnClick:) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [reduced_priceBtn setImage:[UIImage imageNamed:@"cart_unSelect_btn"] forState:UIControlStateNormal];
    [reduced_priceBtn setImage:[UIImage imageNamed:@"cart_selected_btn"] forState:UIControlStateSelected];
    [bgView addSubview:reduced_priceBtn];
    
    //减现金额
    moneyFiled = [MyUIClass simpleTextFieldWithFrame:CGRectMake(k_withBasedIphone6(80), k_withBasedIphone6(40), k_withBasedIphone6(80), k_withBasedIphone6(20)) andPlaceHolder:@"" andClearBtnMode:UITextFieldViewModeWhileEditing andBackColor:[UIColor whiteColor] andFontSize:14.0];
    moneyFiled.keyboardType = UIKeyboardTypeDecimalPad;
    [moneyFiled addTarget:self action:@selector(textFieldChanged:) forControlEvents:UIControlEventEditingChanged];
    [bgView addSubview:moneyFiled];
    
    
    UIView *lineCut = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(80), k_withBasedIphone6(62), k_withBasedIphone6(80), k_withBasedIphone6(2)) andBackColor:Color(91, 202, 213)];
    [bgView addSubview:lineCut];
    
    
    //合计
    
    UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(110), k_withBasedIphone6(80), k_withBasedIphone6(50), k_withBasedIphone6(40)) andText:@"合计: " andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentCenter];
    [bgView addSubview:label];
    
    //价格
    priceLabel = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(160), k_withBasedIphone6(80), k_withBasedIphone6(100), k_withBasedIphone6(40)) andText:@"" andTextColor:[UIColor redColor] andFontSize:15.0 andAlignment:NSTextAlignmentCenter];
    [bgView addSubview:priceLabel];
    
    //结算按钮
    UIButton *btn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(260), k_withBasedIphone6(76), Screen_W-k_withBasedIphone6(260), k_withBasedIphone6(52)) andType:UIButtonTypeCustom andBackColor:Color(7, 196, 190) andTitle:@"结账" andTitleFontSize:17.0 andTitleColor:[UIColor whiteColor] andTarget:self andSelector:@selector(goPayBtnClick) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [bgView addSubview:btn];
    
    

}

#pragma mark - 设置底部支付方式视图
-(void)setupBottomPayView{
    
    payStyleView = [[UIView alloc]initWithFrame:CGRectMake(0, Screen_H-IPHONE_X_NAV_HEIGHT, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT)];
    payStyleView.backgroundColor = [UIColor blackColor];
    //payStyleView.alpha = 0.5;
    payStyleView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
    [self.view addSubview:payStyleView];
    
    UIView *bgview = [[UIView alloc]initWithFrame:CGRectMake(0, Screen_H-IPHONE_X_NAV_HEIGHT-k_withBasedIphone6(150) , Screen_W, k_withBasedIphone6(50))];
    bgview.backgroundColor = [UIColor whiteColor];
    [payStyleView addSubview:bgview];
    
    
    NSArray *array = @[@"二维码支付"];
    //NSArray *array = @[@"二维码支付",@"测试支付",@"测试支付"];
    for (int i = 0; i < 1; i++) {
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame  = CGRectMake(0, k_withBasedIphone6(50)*i, Screen_W, k_withBasedIphone6(50));
        btn.backgroundColor = [UIColor whiteColor];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setTitle:array[i] forState:UIControlStateNormal];
        btn.layer.borderColor = [UIColor lightGrayColor].CGColor;
        btn.layer.borderWidth = 1.0;
        [btn addTarget:self action:@selector(clickPayBtn) forControlEvents:UIControlEventTouchUpInside];
        [bgview addSubview:btn];
    }
    
}

#pragma mark - 设置主视图
-(void)setupMainView
{

//    //当购物车为空时,显示默认视图
//    if (dataArray.count == 0) {
//        [self cartEmptyShow];
//    }
//    //当购物车不为空时,tableView展示
//    else
//    {
        UIView *vi = [self.view viewWithTag:TAG_BACKGROUNDVIEW];
        [vi removeFromSuperview];
        
        myTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H - IPHONE_X_NAV_HEIGHT-k_withBasedIphone6(128)) style:UITableViewStylePlain];
        myTableView.delegate = self;
        myTableView.dataSource = self;
        myTableView.rowHeight = k_withBasedIphone6(100);
        //        myTableView.separatorStyle = UITableViewCellSeparatorStyleNone;//去除分割线
        myTableView.backgroundColor = [UIColor whiteColor];
        
        [myTableView registerClass:[CartTableViewCell class] forCellReuseIdentifier:@"cellID"];
        
        [self.view addSubview:myTableView];
        
        [self setupBottomView];
        
        [self setupBottomPayView];
        
   // }
    
    
}
//购物车为空时的默认视图
-(void)cartEmptyShow
{
    
    //默认视图背景
    UIView *backgroundView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H - 64)];
    backgroundView.tag = TAG_BACKGROUNDVIEW;
    backgroundView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:backgroundView];
    
    //默认图片
    UIImageView *img = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"cart_default_bg"]];
    img.center = CGPointMake(Screen_W/2.0, Screen_H/2.0 - 120);
    img.bounds = CGRectMake(0, 0, 247.0/187 * 100, 100);
    [backgroundView addSubview:img];
    
    UILabel *warnLabel = [[UILabel alloc]init];
    warnLabel.center = CGPointMake(Screen_W/2.0, Screen_H/2.0 - 10);
    warnLabel.bounds = CGRectMake(0, 0, Screen_W, 30);
    warnLabel.textAlignment = NSTextAlignmentCenter;
    warnLabel.text = @"购物车好空,买点什么呗!";
    warnLabel.font = [UIFont systemFontOfSize:15];
    warnLabel.textColor = kUIColorFromRGB(0x706F6F);
    [backgroundView addSubview:warnLabel];
    
    //默认视图按钮
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.center = CGPointMake(Screen_W/2.0, Screen_H/2.0 + 40);
    btn.bounds = CGRectMake(0, 0, Screen_W - 40, 40);
    [btn setBackgroundImage:[UIImage imageNamed:@"btn_background_red"] forState:UIControlStateNormal];
    [btn setTitle:@"去定制" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(goToMainmenuView) forControlEvents:UIControlEventTouchUpInside];
    [backgroundView addSubview:btn];
    
}
-(void)goToMainmenuView
{
    NSLog(@"去首页");
}
#pragma mark - tableView 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataArray.count;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CartTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellID"];
   cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.isSelected = isSelect;
    
    //是否被选中
    if ([selectGoods containsObject:[dataArray objectAtIndex:indexPath.row]]) {
        cell.isSelected = YES;
        
    }else{
        
        cell.isSelected = NO;
    }
    
    //选择回调
    cell.cartBlock = ^(BOOL isSelec){
        
        if (isSelec) {
            [self->selectGoods addObject:[self->dataArray objectAtIndex:indexPath.row]];
        }
        else
        {
            [self->selectGoods removeObject:[self->dataArray objectAtIndex:indexPath.row]];
        }
        
        if (self->selectGoods.count == self->dataArray.count) {
            self->selectAll.selected = YES;
        }
        else
        {
            self->selectAll.selected = NO;
        }
        
        [self countPrice];
    };

    __block CartTableViewCell *weakCell = cell;
    cell.numAddBlock =^(){
        //当点击数量小于1的时候 return  这边添加了小于1不可减少 更换减法按钮图片提示 但是点加法一定大于1 所以设置回原图片
        [weakCell.cutBtn setImage:[UIImage imageNamed:@"cutSymbols"] forState:UIControlStateNormal];
        
        NSInteger count = [weakCell.numberLabel.text integerValue];
        count++;
        NSString *numStr = [NSString stringWithFormat:@"%ld",(long)count];

        CartModel *model = [self->dataArray objectAtIndex:indexPath.row];

        weakCell.numberLabel.text = numStr;
        model.goods_number = numStr;
        NSLog(@"add%ld-%@-%@",(long)count,model.goods_number,model.rec_id);
        
        [self addGoodsNumber:model.rec_id andNumber:numStr];
        
       // [self->_countAarray replaceObjectAtIndex:indexPath.row withObject:numStr];
        if ([self->selectGoods containsObject:model]) {
            [self->selectGoods removeObject:model];
            [self->selectGoods addObject:model];
            [self countPrice];
        }

        //[self->_countAarray replaceObjectAtIndex:indexPath.row withObject:numStr];
    };

    cell.numCutBlock =^(){

        NSInteger count = [weakCell.numberLabel.text integerValue];
        count--;
        //当点击数量小于1的时候 return  这边添加了小于1不可减少 更换减法按钮图片提示
        if(count <= 0){
            [weakCell.cutBtn setImage:[UIImage imageNamed:@"cart_cutBtn_highlight"] forState:UIControlStateNormal];
            return ;
        }else{
           [weakCell.cutBtn setImage:[UIImage imageNamed:@"cutSymbols"] forState:UIControlStateNormal];
        }
        
        NSString *numStr = [NSString stringWithFormat:@"%ld",(long)count];

        CartModel *model = [self->dataArray objectAtIndex:indexPath.row];

        weakCell.numberLabel.text = numStr;
        
        

        model.goods_number = numStr;
        NSLog(@"cut%@-%@",model.goods_number,model.rec_id);
    
        [self addGoodsNumber:model.rec_id andNumber:numStr];
        
        //[self->_countAarray replaceObjectAtIndex:indexPath.row withObject:numStr];

        //判断已选择数组里有无该对象,有就删除  重新添加
        if ([self->selectGoods containsObject:model]) {
            [self->selectGoods removeObject:model];
            [self->selectGoods addObject:model];
            [self countPrice];
        }
        //[self->_countAarray replaceObjectAtIndex:indexPath.row withObject:numStr];
        //NSLog(@"s🐂s%@",self->_countAarray);
    };

    [cell reloadDataWith:[dataArray objectAtIndex:indexPath.row]];
    
    
    //cell.numberLabel.text = _countAarray[indexPath.row]; //更改数量 重新赋值  不会循环引用
    return cell;
}

-(void)reloadTable
{
    [myTableView reloadData];
}

-(NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"删除";
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"确定要删除该商品?删除后无法恢复!" preferredStyle:1];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
           
            

            
            NSLog(@"%@",self->dataArray);
            [self->clearMutableArray removeAllObjects];
            for (CartModel *model in self->dataArray) {

                [self->clearMutableArray addObject:model.rec_id];

            }
            NSLog(@"clearMutableArray%@",self->clearMutableArray);
//            NSLog(@"aaarray%@",array[indexPath.row]);
            NSString *string = self->clearMutableArray[indexPath.row];
            NSLog(@"%@",string);
            //[self->clearMutableArray removeObjectAtIndex:[[indexPath.row]intervalue]];
            [self clearCartGoods:self->clearMutableArray[indexPath.row]];
            //[self performSelector:@selector(reloadTable) withObject:nil afterDelay:0.5];
            
      
        }];
        
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        
        [alert addAction:okAction];
        [alert addAction:cancel];
        [self presentViewController:alert animated:YES completion:nil];
    }
}




#pragma mark - 按钮点击事件

-(void) checkOut{
  
    
}


//全选
-(void)selectAllBtnClick:(UIButton*)button
{
    //点击全选时,把之前已选择的全部删除
    [selectGoods removeAllObjects];
    
    button.selected = !button.selected;
    isSelect = button.selected;
    if (isSelect) {
        
        for (CartModel *model in dataArray) {
            [selectGoods addObject:model];
        }
    }
    else
    {
        [selectGoods removeAllObjects];
    }
    
    
    [myTableView reloadData];
    [self countPrice];
}


//监听减现输入框中现金变化 计算付款金额  --- c出现下面支付方式
- (void)textFieldChanged:(UITextField*)textField{
    
    NSString *string = textField.text;
    NSLog(@"%@",string);
    moneyFiled.text = string;
    [self countPrice];
}

//点击减现按钮
-(void)reduced_priceBtnClick:(UIButton *)btn{
    btn.selected = !btn.selected;
    isSelect = btn.selected;
    if (isSelect) {
        
        NSLog(@"111");
    }
    else
    {
       NSLog(@"222");
        [moneyFiled resignFirstResponder];
    }
}



#pragma mark - 酷点支付
//clickPayBtn点击支付按钮
-(void)clickPayBtn{
    NSLog(@"点击支付按钮");
    
    //请求支付方式接口order/pay
    [self order_pay];
}

-(void)order_pay{

  
    //http://ecjia.cckdtj.com/sites/api/?url=order/pay
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *member_token = [userDefault objectForKey:@"member_token"];
    NSString *temp = @"/sites/api/?url=order/pay";
    
    NSString *string = [cckdURL stringByAppendingString:temp];//订单支付
    NSDictionary *parameters = @{

                                 @"token" : member_token,
                                 @"order_id":[NSNumber numberWithInteger:[backOrder_id integerValue]]

                                 };
    __weak typeof(self) weakSelf = self;
   [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:parameters success:^(id obj) {
        
        NSLog(@"%@",obj);
        NSLog(@"%@",obj);
    } successOne:^(id responseObject) {


        //请求成功，则调转到二维码生成页面
        CreatQrController *vc = [[CreatQrController alloc]init];
        vc.amount = self->backTotalPrice;
        vc.order_sn = self->backOrder_sn;
        vc.order_id = self->backOrder_id;
        [weakSelf.navigationController pushViewController:vc animated:YES];


    } successZero:^(id responseObject) {
     
        NSString *alterStr = responseObject[@"status"][@"error_desc"];

        if ([alterStr isEqualToString:@"Invalid session"]) {

            //NSLog(@"token改变，登陆过期");

            [self showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{

                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];

            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];



        }else{

            [self showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        }

    } fail:^(NSError *error) {
     
        NSString *alterString = @"数据加载失败，请检查网络！";

        [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];


    }];
}


//清空购物车某个商品
-(void)clearCartGoods:(NSString *)rec_id{
    
  
    //http://ecjia.cckdtj.com/sites/api/?url=admin/flow/checkOrder
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userDefault objectForKey:@"Token"];
    NSString *member_user_id = [userDefault objectForKey:@"member_user_id"];
    NSString *temp = @"/sites/api/?url=admin/flow/checkOrder";
    NSString *string = [cckdURL stringByAppendingString:temp];//查询购物车接口
    NSDictionary *parameters = @{
                                 
                                 @"token" : token,
                                 @"deletegoods":@{
                                         @"rec_id":[NSNumber numberWithInteger:[rec_id integerValue]],
                                         },
                                 
                                 @"user":@{
                                         @"user_id":[NSNumber numberWithInteger:[member_user_id integerValue]],
                                         }
                                 };
    [dataArray removeAllObjects];//获取删除商品后的购物车 需清空先前数组 再次请求赋值
    //每次进入购物车的时候把选择的置空
    [selectGoods removeAllObjects];
    [selectGoods_rec_id removeAllObjects];
    isSelect = NO;
    selectAll.selected = NO;
    priceLabel.text = [NSString stringWithFormat:@"￥0.00"];
    
    __weak typeof(self) weakSelf = self;
   [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
        
        
        
        if ([responseObject[@"data"][@"goods_list"] isKindOfClass:[NSArray class]]) {
            
            NSArray * array = responseObject[@"data"][@"goods_list"];
            for (NSDictionary *dic in array) {
                CartModel *model = [CartModel new];
                [model setValuesForKeysWithDictionary:dic];
                model.goodsNumber = @"1";
                [self->dataArray addObject:model];
                [self->_countAarray addObject:model.goodsNumber];
            }
            
            [weakSelf selectAllBtnClick:self->selectAll];
            //延迟0.5s刷新一下,否则数据会乱
            [self performSelector:@selector(reloadTable) withObject:nil afterDelay:0.5];
            
           // [self countPrice];
            
      
        }else{
            
     
            [self->myTableView removeFromSuperview];
            [self->bgView removeFromSuperview];
            [self cartEmptyShow];
        }

        //NSLog(@"%@",self.REC_IDMutableArray);
    } successZero:^(id responseObject) {
    
        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");
            
            [self showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
 
        }else{
            
            [self showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        }
        
    } fail:^(NSError *error) {

        NSString *alterString = @"数据加载失败，请检查网络！";
         [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }];
}

#pragma mark - 键盘高度监听事件
//当键盘出现或改变时调用
- (void)keyboardWillShow:(NSNotification *)aNotification {
    //键盘监测启动 键盘跳出 改变减现按钮选中状态 对应状态修改图片
    reduced_priceBtn.selected = YES;
    
    //获取键盘的高度
    NSDictionary *userInfo = [aNotification userInfo];
    NSValue *aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    int height = keyboardRect.size.height;
    NSLog(@"键盘高度监听事件%d",height);
    
    bgView.frame = CGRectMake(0,Screen_H - IPHONE_X_NAV_HEIGHT-k_withBasedIphone6(128)-height, Screen_W, k_withBasedIphone6(128));
    
}
//当键退出时调用
- (void)keyboardWillHide:(NSNotification *)aNotification{
    bgView.frame = CGRectMake(0,Screen_H - IPHONE_X_NAV_HEIGHT-k_withBasedIphone6(128), Screen_W, k_withBasedIphone6(128));
}

//键盘Return按键回调
//- (BOOL)textFieldShouldReturn:(UITextField *)textField {
//    [textField resignFirstResponder];
//    return YES;
//}
//键盘回收
//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
//    [myTableView endEditing:YES];
//}


#pragma mark - 结账按钮
-(void)goPayBtnClick
{
    
    NSString *total_rec_id = @"";
    
    for (CartModel *model in selectGoods) {
        
        NSString *temp = [model.rec_id stringByAppendingString:@","];
        
        total_rec_id = [total_rec_id stringByAppendingString:temp];
        
    }
    
    if ([total_rec_id isEqualToString:@""]) {
        
        [self showAlertWithTitle:@"温馨提示" andMessage:@"请选中商品再进行结账" andActionTitle:@"好的" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }else{
        
    NSString *cccc = [total_rec_id substringToIndex:[total_rec_id length] - 1];
    
    NSLog(@"去结算%@",cccc);

    [self creatOrder_id:cccc];
   }
    
}


#pragma mark - parsing
//admin/flow/done收银购物流订单结算--汇总订单详情信息--产生订单号和金额--次订单一生成则购物车自动清空
-(void)creatOrder_id:(NSString *)rec_idList{

  
    //http://ecjia.cckdtj.com/sites/api/?url=admin/flow/done
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userDefault objectForKey:@"Token"];
    NSLog(@"creatOrder%@",token);
    
    NSString *temp = @"/sites/api/?url=admin/flow/done";
    NSString *string = [cckdURL stringByAppendingString:temp];//收银购物流订单结算
    NSDictionary *parameters = @{
                                 
                                 @"token" : token,
                                 @"pay_id":@11,
                                 @"shipping_id":@2,
                                 @"rec_id":rec_idList,
                                 
                                 };
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:parameters success:^(id obj) {
        
        
    } successOne:^(id responseObject) {
        
        NSLog(@"one%@",responseObject);
        
        NSString *st1 = [NSString stringWithFormat:@"%@",responseObject[@"data"][@"order_id"]];
        NSString *st2 = responseObject[@"data"][@"order_info"][@"order_amount"];
        NSString *st3 = [NSString stringWithFormat:@"%@",responseObject[@"data"][@"order_sn"]];
        
        self->backOrder_id = st1;
        self->backTotalPrice = st2;
        self->backOrder_sn = st3;
    
        [UIView animateWithDuration:0.5 animations:^{
            
            self->payStyleView.frame = CGRectMake(0,0 , Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT);
        }];
        
  
    } successZero:^(id responseObject) {
    NSLog(@"zero%@",responseObject);
        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");
            
            [weakSelf showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
 
        }else{
            
             [weakSelf showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        }
        
    } fail:^(NSError *error) {
  
        NSString *str = [NSString stringWithFormat:@"%@",error];
        //NSString *alterString = @"数据加载失败，请检查网络！";
        [weakSelf showAlertWithTitle:@"提示" andMessage:str andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
        
    }];
}

-(void)addGoodsNumber:(NSString *)rec_id andNumber:(NSString *)number{
  
    //http://ecjia.cckdtj.com/sites/api/?url=admin/flow/checkOrder
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userDefault objectForKey:@"Token"];
    NSString *member_user_id = [userDefault objectForKey:@"member_user_id"];
    NSString *temp = @"/sites/api/?url=admin/flow/checkOrder";
    NSString *string = [cckdURL stringByAppendingString:temp];//查询购物车接口
    NSDictionary *parameters = @{
                                 
                                 @"token" : token,
                                  @"updategoods":@{
                                          @"rec_id":[NSNumber numberWithInteger:[rec_id integerValue]],
                                          @"number":[NSNumber numberWithInteger:[number integerValue]]
                                          },

                                 @"user":@{
                                         @"user_id":[NSNumber numberWithInteger:[member_user_id integerValue]],
                                         }
                                 };
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
        
        [self->myTableView reloadData];
    
    } successZero:^(id responseObject) {
    
        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");
            [self showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
            
            
        }else{
            
            [weakSelf showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:^{
                
                [self->selectGoods removeAllObjects];
                [self->selectGoods_rec_id removeAllObjects];
                self->isSelect = NO;
                
                self->selectAll.selected = NO;
                
                self->priceLabel.text = [NSString stringWithFormat:@"￥0.00"];
                [self creatCartListAgain];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
        }
        
    } fail:^(NSError *error) {
        

        NSString *alterString = @"数据加载失败，请检查网络！";
        [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:^{
            
            [self->selectGoods removeAllObjects];
            [self->selectGoods_rec_id removeAllObjects];
            self->isSelect = NO;
            
            self->selectAll.selected = NO;
            
            self->priceLabel.text = [NSString stringWithFormat:@"￥0.00"];
            [self creatCartListAgain];
            
        } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];

    }];
}


//显示购物车内容
-(void)creatCartList{
 
    //http://ecjia.cckdtj.com/sites/api/?url=admin/flow/checkOrder
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userDefault objectForKey:@"Token"];
    NSString *member_user_id = [userDefault objectForKey:@"member_user_id"];
    
    //第一次进入程序 点击主页结账 没有对应key是member_user_id的赋值。只有点了自选按钮 根据提示框操作才会有 所依做判断 防止崩溃
    if (member_user_id == nil) {
        member_user_id = @"";
    }
    NSString *temp = @"/sites/api/?url=admin/flow/checkOrder";
    NSString *string = [cckdURL stringByAppendingString:temp];//查询购物车接口
    NSDictionary *parameters = @{
                                 
                                 @"token" : token,
                                 @"user":@{
                                         @"user_id":[NSNumber numberWithInteger:[member_user_id integerValue]],
                                         }
                                 };
    
    __weak typeof(self) weakSelf = self;
   [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
        

        if (![responseObject[@"data"][@"goods_list"] isKindOfClass:[NSArray class]] ) {
            
            //[self creatCartListAgain];
            [self cartEmptyShow];
            
        }else{
         
            [self setupMainView];
            [self->dataArray removeAllObjects];
            NSArray * array = responseObject[@"data"][@"goods_list"];//数组可以上空
            
            for (NSDictionary *dic in array) {
                CartModel *model = [CartModel new];
                [model setValuesForKeysWithDictionary:dic];
                 //model.goodsNumber = @"1";
                [self->dataArray addObject:model];
                //[self->_countAarray addObject:model.goodsNumber];
              }
            
        }
        [weakSelf selectAllBtnClick:self->selectAll];
        
        [self->myTableView reloadData];
 
        
    } successZero:^(id responseObject) {
    
        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");
    
            [self showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
        }else{
            
            [weakSelf showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:^{
                
                [self creatCartList];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
        }
        
    } fail:^(NSError *error) {
        
    
        NSString *alterString = @"数据加载失败，请检查网络！";
        [weakSelf showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:^{
            
            [self creatCartList];
            
        } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
  
    }];
  
}

//显示购物车内容
-(void)creatCartListAgain{
 
    //http://ecjia.cckdtj.com/sites/api/?url=admin/flow/checkOrder
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userDefault objectForKey:@"Token"];
    NSString *member_user_id = [userDefault objectForKey:@"member_user_id"];
    
    if (member_user_id == nil) {
        member_user_id = @"";
    }
    NSString *temp = @"/sites/api/?url=admin/flow/checkOrder";
    NSString *string = [cckdURL stringByAppendingString:temp];//查询购物车接口
    NSDictionary *parameters = @{
                                 
                                 @"token" : token,
                                 @"user":@{
                                         @"user_id":[NSNumber numberWithInteger:[member_user_id integerValue]],
                                         }
                                 };
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
  
            [self->dataArray removeAllObjects];
            NSArray * array = responseObject[@"data"][@"goods_list"];//数组可以上空
            
            for (NSDictionary *dic in array) {
                CartModel *model = [CartModel new];
                [model setValuesForKeysWithDictionary:dic];
                [self->dataArray addObject:model];
            
            }
            
            [self selectAllBtnClick:self->selectAll];
       
        
        [self->myTableView reloadData];
        
    } successZero:^(id responseObject) {
 
        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");

            [self showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
        }else{
            
            [weakSelf showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
        }
        
    } fail:^(NSError *error) {
        ;
        NSString *alterString = @"数据加载失败，请检查网络！";
        [weakSelf showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }];
    
}

//提示框小装 show = yes 有取消按钮。=no只有确定一个按钮__weak typeof(self) weakSelf = self;
-(void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message andActionTitle:(NSString *)actionTitle andactionBlock:(void(^)(void))ActionBlock andActionCancelTitle:(NSString *)actionCancelTitle andActionCancelBlock:(void(^)(void))ActionCancelBlock andBool:(BOOL)show {
    
    if (show) {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:actionCancelTitle style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionCancelBlock) {
                ActionCancelBlock();
            }
        }];
        [alert addAction:actionCancel];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }else{
       
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
