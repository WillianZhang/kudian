//
//  CartTableViewCell.m
//  KuDianErMerchant
//
//  Created by william on 2018/8/20.
//  Copyright © 2018年 william. All rights reserved.
//

#import "CartTableViewCell.h"

@interface CartTableViewCell ()

@end

@implementation CartTableViewCell



-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = RGBCOLOR(245, 246, 248);
        [self setupMainView];
    }
    return self;
}




//选中按钮点击事件
-(void)selectBtnClick:(UIButton*)button
{
    button.selected = !button.selected;
    if (self.cartBlock) {
        self.cartBlock(button.selected);
    }
}

// 数量加按钮
-(void)addBtnClick
{
//    NSInteger count = [self.numberLabel.text integerValue];
//    count ++;
//    self.numberLabel.text = [NSString stringWithFormat:@"%ld",count];
//    if (self.AddBlock) {
//        self.AddBlock(self.numberLabel);
//    }
    if (self.numAddBlock) {
        self.numAddBlock();
    }
}

//数量减按钮
-(void)cutBtnClick
{
//    NSInteger count = [self.numberLabel.text integerValue];
//    count --;
//    if (count < 0) {
//        return;
//    }
//    self.numberLabel.text = [NSString stringWithFormat:@"%ld",count];
//    if (self.CutBlock) {
//        self.CutBlock(self.numberLabel);
//    }
    if (self.numCutBlock) {
        self.numCutBlock();
    }
}

-(void)reloadDataWith:(CartModel*)model
{
    NSString *string = model.img[@"small"];
    NSURL *url = [NSURL URLWithString:string];
    [self.imageView_cell sd_setImageWithURL:url];
    

    self.nameLabel.text = model.goods_name;
    
    NSString *temp = [@"￥" stringByAppendingString:model.goods_price ];
    NSMutableAttributedString *fontAttributeNameStr = [[NSMutableAttributedString alloc]initWithString:temp];
    [fontAttributeNameStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:13] range:NSMakeRange(0, 1)];
    [fontAttributeNameStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:13] range:NSMakeRange(temp.length - 2, 2)];
    self.priceLabel.attributedText = fontAttributeNameStr;

    self.numberLabel.text = model.goods_number;

    self.selectBtn.selected = self.isSelected;
    
}
-(void)setupMainView
{
 
    //选中按钮
    self.selectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.selectBtn.frame = CGRectMake(k_withBasedIphone6(10), k_withBasedIphone6(30), k_withBasedIphone6(30), k_withBasedIphone6(30));
    self.selectBtn.selected = self.isSelected;
    [self.selectBtn setImage:[UIImage imageNamed:@"cart_unSelect_btn"] forState:UIControlStateNormal];
    [self.selectBtn setImage:[UIImage imageNamed:@"cart_selected_btn"] forState:UIControlStateSelected];
    [self.selectBtn addTarget:self action:@selector(selectBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:self.selectBtn];
    
    
    //显示照片
    self.imageView_cell = [[UIImageView alloc]initWithFrame:CGRectMake(k_withBasedIphone6(50), k_withBasedIphone6(10), k_withBasedIphone6(70), k_withBasedIphone6(80))];
    //self.imageView_cell.backgroundColor = [UIColor yellowColor];
    self.imageView_cell.contentMode = UIViewContentModeScaleAspectFit;
    [self addSubview:self.imageView_cell];
    
    //商品名
    CGRect nameLabelFrame = CGRectMake(k_withBasedIphone6(130), k_withBasedIphone6(10), k_withBasedIphone6(200), k_withBasedIphone6(45));
    self.nameLabel = [MyUIClass simpleLabelWithFrame:nameLabelFrame andText:@"" andTextColor:Color(50, 50, 50) andFontSize:16.0 andAlignment:NSTextAlignmentLeft];
    self.nameLabel.numberOfLines = 0;
    //self.nameLabel.backgroundColor = [UIColor lightGrayColor];
    [self addSubview:self.nameLabel];
    
   
    //价格
    self.priceLabel = [[UILabel alloc]init];
    self.priceLabel.frame = CGRectMake(k_withBasedIphone6(130), k_withBasedIphone6(60), k_withBasedIphone6(120), k_withBasedIphone6(25));
    self.priceLabel.font = [UIFont systemFontOfSize:18.0];
    self.priceLabel.textAlignment = NSTextAlignmentLeft;
    //self.priceLabel.backgroundColor = [UIColor lightGrayColor];
    self.priceLabel.textColor = BASECOLOR_RED;
    [self addSubview:self.priceLabel];
    
    //数量加按钮
    UIButton *addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//    addBtn.frame = CGRectMake(k_withBasedIphone6(260), k_withBasedIphone6(60), k_withBasedIphone6(25), k_withBasedIphone6(25));
    addBtn.frame = CGRectMake(k_withBasedIphone6(325), k_withBasedIphone6(60), k_withBasedIphone6(25), k_withBasedIphone6(25));
    [addBtn setImage:[UIImage imageNamed:@"addSymbols"] forState:UIControlStateNormal];
    addBtn.layer.borderWidth = 1.0;
    addBtn.layer.borderColor = Color(216, 217, 218).CGColor;
//    [addBtn setImage:[UIImage imageNamed:@"cart_addBtn_highlight"] forState:UIControlStateHighlighted];
    [addBtn addTarget:self action:@selector(addBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:addBtn];
    
    //数量减按钮
    self.cutBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _cutBtn.frame = CGRectMake(k_withBasedIphone6(260), k_withBasedIphone6(60), k_withBasedIphone6(25), k_withBasedIphone6(25));
    [_cutBtn setImage:[UIImage imageNamed:@"cutSymbols"] forState:UIControlStateNormal];
    _cutBtn.layer.borderWidth = 1.0;
    _cutBtn.layer.borderColor = Color(216, 217, 218).CGColor;
//    [cutBtn setImage:[UIImage imageNamed:@"cart_cutBtn_highlight"] forState:UIControlStateHighlighted];
    [_cutBtn addTarget:self action:@selector(cutBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_cutBtn];
    
    //数量显示
    self.numberLabel = [[UILabel alloc]init];
    self.numberLabel.frame = CGRectMake(k_withBasedIphone6(285), k_withBasedIphone6(60), k_withBasedIphone6(40), k_withBasedIphone6(25));
    self.numberLabel.textAlignment = NSTextAlignmentCenter;
    self.numberLabel.layer.borderWidth = 1.0;
    self.numberLabel.layer.borderColor = Color(216, 217, 218).CGColor;
//    self.numberLabel.text = @"1";
    self.numberLabel.font = [UIFont systemFontOfSize:15];
    [self addSubview:self.numberLabel];
    

}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
