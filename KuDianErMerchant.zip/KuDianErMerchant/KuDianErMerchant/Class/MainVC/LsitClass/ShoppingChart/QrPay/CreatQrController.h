//
//  CreatQrController.h
//  KuDianErMerchant
//
//  Created by william on 2018/8/25.
//  Copyright © 2018年 william. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreatQrController : UIViewController

@property(nonatomic , strong) NSString *amount;
@property(nonatomic , strong) NSString *order_sn;
@property(nonatomic , strong) NSString *order_id;
@end
