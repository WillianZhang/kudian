//
//  CreatQrController.m
//  KuDianErMerchant
//
//  Created by william on 2018/8/25.
//  Copyright © 2018年 william. All rights reserved.
// 生成支付二维码

#import "CreatQrController.h"
#import <CoreImage/CoreImage.h>
#import "PaySuccessController.h"
#import "BackMoneyController.h"
#import "BackMoneySuccessController.h"
#import "DFYSVP.h"

NSInteger count = 0;
@interface CreatQrController ()

@property(nonatomic ,strong) NSString *urlString;
@property(nonatomic ,strong) UIImageView *imageView;
//注意这里不需要*号 可以理解为dispatch_time_t 已经包含了
@property (nonatomic, strong) dispatch_source_t time;
@property (nonatomic, strong) UILabel *dateLabDetail;
@property (nonatomic, strong) UILabel *countLabDetail;

@property(nonatomic ,strong) NSString *billDate;
@property(nonatomic ,strong) NSString *billno;

@end

@implementation CreatQrController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    //DFYSVPLoading(@"请稍后...", NO);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = Color(7, 196, 190);
    //http://boss.tjcclz.com:8091/NewBossWebService.asmx/GetQrCode?requestType=1&amount=1
    //NSString * base = @"http://boss.tjcclz.com:8091/NewBossWebService.asmx/GetQrCode?requestType=0&amount=";
    NSString * base = @"http://ckpay.tjcclz.com:8091/NewBossWebService.asmx/GetQrCode?requestType=0&amount=";
    
    
    double count = [_amount doubleValue] ;
    double price =count *100;
    NSString *temp = [ NSString stringWithFormat:@"%.f",price];
    
    self.urlString = [base stringByAppendingString:temp];
    
   
    [self creacUI];
    //[self creeatDispatch];//开启检测订单状态线程
}

#pragma mark - 创建视图
-(void)creacUI{
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSDictionary *tempDic = [userDefault objectForKey:@"userinfoDic"];
    NSString *username = tempDic[@"username"];
    
    NSLog(@"username%@",username);
    
    UIView *baView = [[UIView alloc]initWithFrame:CGRectMake(k_withBasedIphone6(45), k_withBasedIphone6(60), k_withBasedIphone6(285), k_withBasedIphone6(350))];
    baView.backgroundColor = [UIColor whiteColor];
    baView.layer.cornerRadius = k_withBasedIphone6(14);
    baView.layer.masksToBounds = YES;
    [self.view addSubview:baView];
    
    if (username) {
        
        NSString *shopName = [@"商家名称："stringByAppendingString:username];
        UILabel *sellName = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(40), k_withBasedIphone6(20), k_withBasedIphone6(205), k_withBasedIphone6(25)) andText:shopName andTextColor:Color(50, 50, 50) andFontSize:16.0 andAlignment:NSTextAlignmentLeft];
        [baView addSubview:sellName];
        
    }else{
        
    }
    
    UILabel *dateLab = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(40), k_withBasedIphone6(45), k_withBasedIphone6(45), k_withBasedIphone6(25)) andText:@"时间：" andTextColor:Color(50, 50, 50) andFontSize:16.0 andAlignment:NSTextAlignmentLeft];
    
    self.dateLabDetail = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(85), k_withBasedIphone6(45), k_withBasedIphone6(160), k_withBasedIphone6(25)) andText:@"" andTextColor:Color(150, 150, 150) andFontSize:16.0 andAlignment:NSTextAlignmentLeft];
    
    
    UILabel *countLab = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(60), k_withBasedIphone6(90), k_withBasedIphone6(100), k_withBasedIphone6(25)) andText:@"订单金额：" andTextColor:Color(50, 50, 50) andFontSize:17.0 andAlignment:NSTextAlignmentCenter];
    
    
    NSString *temp = [@"￥" stringByAppendingString:self.amount];
    self.countLabDetail = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(160), k_withBasedIphone6(90), k_withBasedIphone6(155), k_withBasedIphone6(25)) andText:temp andTextColor:Color(230, 50, 50) andFontSize:18.0 andAlignment:NSTextAlignmentLeft];
    

    self.imageView = [[UIImageView alloc]initWithFrame:CGRectMake(k_withBasedIphone6(60), k_withBasedIphone6(140), k_withBasedIphone6(165), k_withBasedIphone6(165))];
    
    
    [baView addSubview:dateLab];
    [baView addSubview:_dateLabDetail];
    [baView addSubview:countLab];
    [baView addSubview:_countLabDetail];
    [baView addSubview:_imageView];
    
    UILabel *descripeLab = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(55), k_withBasedIphone6(430), k_withBasedIphone6(265), k_withBasedIphone6(50)) andText:@"付款说明：请扫瞄中心二维码支付订单，如有疑问请联系收银台相关负责人员" andTextColor:[UIColor whiteColor] andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
    descripeLab.numberOfLines = 0;
    [self.view addSubview:descripeLab];
    
    
    
    
    
     [self creatQr];
}


#pragma mark - 数据请求
-(void)creatQr{
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] getNetworkRequestURLString:_urlString parameters:nil success:^(id obj) {

//        NSLog(@"creatQr%@",obj);
//        billDate = "2018-09-11";
//        billNo = 4444201809111625191392519991;
//        billQRCode = "https://qr.95516.com/48020000/44441809113832300162383105";
//        errCode = SUCCESS;
//        errMsg = "\U67e5\U8be2\U4e8c\U7ef4\U7801\U6210\U529f";
//        instMid = QRPAYDEFAULT;
//        mid = 898120048140373;
//        msgSrc = "WWW.TJCKDXCY.COM";
//        msgType = "bills.getQRCode";
//        qrCodeId = 44441809113832300162383105;
//        responseTimestamp = "2018-09-11 16:23:00";
//        sign = 25A9079C67C7C841A0BDE7E52ECA8312;
//        tid = 01384572;
        if ([obj[@"errCode"] isEqualToString:@"SUCCESS"]) {
      
            
            //在请求成功取到链接后调用----请求不成功。先加数据实现生成二维码---在请求成功后开启监视线程
            NSString *string = obj[@"billQRCode"];
            weakSelf.billno = obj[@"billNo"];
            weakSelf.billDate = obj[@"billDate"];
            
            [weakSelf makeQR:string];

            weakSelf.dateLabDetail.text = obj[@"responseTimestamp"];
            [weakSelf creeatDispatch:obj[@"billNo"]];
        }else{
            
     
            NSString *alterStr = obj[@"errMsg"];
         
            [weakSelf showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"重试" andactionBlock:^{
                [weakSelf creatQr];
            } andActionCancelTitle:@"取消" andActionCancelBlock:^{
                
            } andBool:YES];
        }
        
    } fail:^(NSError *error) {
   
        NSLog(@"creatQr_error%@",error);
        
        NSString *alterString = @"数据加载失败，请检查网络！";

        [weakSelf showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"刷新" andactionBlock:^{
            [weakSelf creatQr];
        } andActionCancelTitle:@"取消" andActionCancelBlock:^{
            
        } andBool:YES];
    }];

}

//二维码控件初始化
-(void)makeQR:(NSString *)urlStr{
    //创建过滤器
    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    
    //过滤器恢复默认
    [filter setDefaults];
    
    //给过滤器添加数据
    NSString *string = urlStr;
    
    //将NSString格式转化成NSData格式
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    
    [filter setValue:data forKeyPath:@"inputMessage"];
    
    //获取二维码过滤器生成的二维码
    CIImage *image = [filter outputImage];
    
    //将获取到的二维码添加到imageview上
    // self.imageView.image =[UIImage imageWithCIImage:image];
    
    self.imageView.image = [self createNonInterpolatedUIImageFormCIImage:image withSize:k_withBasedIphone6(165)];
    
    
}


//根据CIImage生成指定大小的UIImage

//image CIImage  size  图片宽度

- (UIImage *)createNonInterpolatedUIImageFormCIImage:(CIImage *)image withSize:(CGFloat) size
{
    CGRect extent = CGRectIntegral(image.extent);
    CGFloat scale = MIN(size/CGRectGetWidth(extent), size/CGRectGetHeight(extent));
    
    // 1.创建bitmap;
    size_t width = CGRectGetWidth(extent) * scale;
    size_t height = CGRectGetHeight(extent) * scale;
    CGColorSpaceRef cs = CGColorSpaceCreateDeviceGray();
    CGContextRef bitmapRef = CGBitmapContextCreate(nil, width, height, 8, 0, cs, (CGBitmapInfo)kCGImageAlphaNone);
    CIContext *context = [CIContext contextWithOptions:nil];
    CGImageRef bitmapImage = [context createCGImage:image fromRect:extent];
    CGContextSetInterpolationQuality(bitmapRef, kCGInterpolationNone);
    CGContextScaleCTM(bitmapRef, scale, scale);
    CGContextDrawImage(bitmapRef, extent, bitmapImage);
    
    // 2.保存bitmap到图片
    CGImageRef scaledImage = CGBitmapContextCreateImage(bitmapRef);
    CGContextRelease(bitmapRef);
    CGImageRelease(bitmapImage);
    return [UIImage imageWithCGImage:scaledImage];
}


-(void)creeatDispatch:(NSString *)billNo{

    //获得队列
    dispatch_queue_t queue = dispatch_get_global_queue(0, 0);
    //创建一个定时器
    self.time = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    //设置开始时间
    dispatch_time_t start = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC));
    //设置时间间隔
    uint64_t interval = (uint64_t)(3.0* NSEC_PER_SEC);
    //设置定时器
    dispatch_source_set_timer(self.time, start, interval, 0);
    
    //由于定时器默认是暂停的所以我们启动一下
    //启动定时器
    dispatch_resume(self.time);
    
    //设置回调
    dispatch_source_set_event_handler(self.time, ^{
        
        //NSLog(@"请求成功开启监视线程");
        
        NSString *temp = @"http://ckpay.tjcclz.com:8091/NewBossWebService.asmx/GetOrderStatus?requestType=0&billno=";
        NSString *urlStr = [temp stringByAppendingString:billNo];
        
        [[ZbwHttpRequest shardWebUtil] getNoLoadingNetworkRequestURLString:urlStr parameters:nil success:^(id obj) {
            
            //NSLog(@"pay%@",obj);
            if ([obj[@"errCode"] isEqualToString:@"SUCCESS"]&&[obj[@"billStatus"] isEqualToString:@"PAID"]) {
                //支付成功取消定时器 并回调
                dispatch_cancel(self.time);
                //得到付款成功信息--跳转到成功页面
                
                [self payCash];//支付成功后 进行关单验证
               
            }
            
        } fail:^(NSError *error) {
            
        }];
     
//        //设置当执行五次是取消定时器---如果多久后没支付 停止 不再监测
//        count++;
//        if(count == 5){
//
//            dispatch_cancel(self.time);
//            //得到付款成功信息--跳转到成功页面
//        }
    });
}

//关单----
-(void)payCash{
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *tokenStr = [userDefault objectForKey:@"Token"];
    //http://wxmp.cckdtj.com/sites/api/?url=order/paycash&token=11&order_id=3467
    
    //LLog(@"%@-%@",tokenStr,_order_id);
    //NSString *string = @"http://wxmp.cckdtj.com/sites/api/?url=order/paycash&token=%@&order_id=%@";
    NSString *newStr = [NSString stringWithFormat:@"http://ecjia.cckdtj.com/sites/api/?url=order/paycash&token=%@&order_id=%@",tokenStr,_order_id];
    //LLog(@"%@",newStr);
    
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] getNetworkRequestURLString:newStr parameters:nil success:^(id obj) {
        
        NSString * suc = [NSString stringWithFormat:@"%@",obj[@"status"][@"succeed"]];
        if ([suc isEqual:@"1"] ) {
            //关单成功 提示支付成功
            PaySuccessController *vc = [[PaySuccessController alloc]init];
            [weakSelf presentViewController:vc animated:YES completion:nil];
        }else{
          
            //关单失败
            [weakSelf showAlertWithTitle:@"温馨提示" andMessage:@"您的订单提交失败,请检查网络" andActionTitle:@"重试" andactionBlock:^{
                
                [weakSelf payCash];
                
            } andActionCancelTitle:@"退款" andActionCancelBlock:^{
                
                BackMoneyController *vc = [[BackMoneyController alloc]init];
                vc.backMoneyBillDate = weakSelf.billDate;
                vc.backMoneyBillno = weakSelf.billno;
                vc.backMoneyAmount = weakSelf.amount;
                [weakSelf presentViewController:vc animated:YES completion:nil];
                
            } andBool:YES];
            
        }
    
        
    } fail:^(NSError *error) {
        say(@"关单失败%@",error);
        //关单失败
        [weakSelf showAlertWithTitle:@"温馨提示" andMessage:@"您的订单提交失败,请检查网络" andActionTitle:@"重试" andactionBlock:^{
            
            [weakSelf payCash];
            
        } andActionCancelTitle:@"退款" andActionCancelBlock:^{
            
            BackMoneyController *vc = [[BackMoneyController alloc]init];
            vc.backMoneyBillDate = weakSelf.billDate;
            vc.backMoneyBillno = weakSelf.billno;
            vc.backMoneyAmount = weakSelf.amount;
            [weakSelf presentViewController:vc animated:YES completion:nil];
            
        } andBool:YES];
        
    
    }];
}




//提示框小装 show = yes 有取消按钮。=no只有确定一个按钮
-(void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message andActionTitle:(NSString *)actionTitle andactionBlock:(void(^)(void))ActionBlock andActionCancelTitle:(NSString *)actionCancelTitle andActionCancelBlock:(void(^)(void))ActionCancelBlock andBool:(BOOL)show {
    
    if (show) {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:actionCancelTitle style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionCancelBlock) {
                ActionCancelBlock();
            }
        }];
        [alert addAction:actionCancel];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }else{
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}


-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    dispatch_cancel(self.time);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
