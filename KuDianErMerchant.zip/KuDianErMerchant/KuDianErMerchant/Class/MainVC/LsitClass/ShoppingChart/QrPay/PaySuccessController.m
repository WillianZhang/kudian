//
//  PaySuccessController.m
//  KuDianErMerchant
//
//  Created by william on 2018/8/27.
//  Copyright © 2018年 william. All rights reserved.
//

#import "PaySuccessController.h"

@interface PaySuccessController ()

@end

@implementation PaySuccessController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"付款成功";
    
    [self creatUI];
}

-(void)creatUI{
    
    UIImageView *imageView = [MyUIClass makeUIImageWithFrame:CGRectMake(k_withBasedIphone6(157), k_withBasedIphone6(100), k_withBasedIphone6(61), k_withBasedIphone6(56)) andPicName:@"paysuccess"];
    [self.view addSubview:imageView];
    
    
    UIButton *goFirstPageBtn = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(52), k_withBasedIphone6(240), k_withBasedIphone6(271), k_withBasedIphone6(45)) andType:UIButtonTypeCustom andImageName:@"gobackfirst" andTarget:self andSelector:@selector(pushToMainVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [self.view addSubview:goFirstPageBtn];
    
    
    UIButton *addMemberBtn = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(145), k_withBasedIphone6(340), k_withBasedIphone6(85), k_withBasedIphone6(19)) andType:UIButtonTypeCustom andImageName:@"addmember" andTarget:self andSelector:@selector(pushToAddmemberVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [self.view addSubview:addMemberBtn];
    
}


#pragma mark - 按钮点击事件
//返回首页
-(void)pushToMainVC{
    //发出通知app delegate中切换main为跟视图控制器
    [[NSNotificationCenter defaultCenter] postNotificationName:@"back" object:self];
}

//添加会员
-(void)pushToAddmemberVC{
    NSLog(@"进入会员添加页面");
}















- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
