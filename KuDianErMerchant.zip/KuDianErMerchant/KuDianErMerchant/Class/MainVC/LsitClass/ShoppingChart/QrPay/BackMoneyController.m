//
//  BackMoneyController.m
//  KuDianErMerchant
//
//  Created by william on 2018/9/12.
//  Copyright © 2018年 william. All rights reserved.
//

#import "BackMoneyController.h"
#import "BackMoneySuccessController.h"

@interface BackMoneyController ()

@end

@implementation BackMoneyController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = Color(230, 230, 230);
    self.title = @"退款";
    
    [self makeUI];
    LLog(@"aa%@-%@-%@",_backMoneyBillno,_backMoneyBillDate,_backMoneyAmount);
}


-(void)makeUI{
    
    UIView *view = [MyUIClass makeUIViewWithFrame:CGRectMake(0, 0, Screen_W, 64) andBackColor:Color(7, 196, 190)];
    [self.view addSubview:view];
    UILabel *title = [MyUIClass simpleLabelWithFrame:CGRectMake(Screen_W/4, 34, Screen_W/2, 18) andText:@"退款" andTextColor:[UIColor blackColor] andFontSize:16.0 andAlignment:NSTextAlignmentCenter];
    [view addSubview:title];
    
    
    UIImageView *image = [MyUIClass makeUIImageWithFrame:CGRectMake(k_withBasedIphone6(170), k_withBasedIphone6(89), k_withBasedIphone6(36), k_withBasedIphone6(37)) andPicName:@"backMoneyIcon"];
    [self.view addSubview:image];
    
    NSString *noStr = [@"订单编号："stringByAppendingString:_backMoneyBillno];
    UILabel *billno = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(30), k_withBasedIphone6(160), k_withBasedIphone6(315), k_withBasedIphone6(20)) andText:noStr andTextColor:Color(30, 30, 30) andFontSize:16.0 andAlignment:NSTextAlignmentLeft];
    [self.view addSubview:billno];
    
    NSString *dateStr = [@"订单日期："stringByAppendingString:_backMoneyBillDate];
    UILabel *billDate = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(30), k_withBasedIphone6(200), k_withBasedIphone6(315), k_withBasedIphone6(20)) andText:dateStr andTextColor:Color(30, 30, 30) andFontSize:16.0 andAlignment:NSTextAlignmentLeft];
    [self.view addSubview:billDate];
    
    NSString *countStr = [@"订单金额："stringByAppendingString:_backMoneyAmount];
    UILabel *amount = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(30), k_withBasedIphone6(240), k_withBasedIphone6(315), k_withBasedIphone6(20)) andText:countStr andTextColor:Color(30, 30, 30) andFontSize:16.0 andAlignment:NSTextAlignmentLeft];
    [self.view addSubview:amount];
    
    
    UIButton *parsingBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(35), k_withBasedIphone6(290), k_withBasedIphone6(315), k_withBasedIphone6(32)) andType:UIButtonTypeCustom andBackColor:Color(7, 196, 190) andTitle:@"立即退款" andTitleFontSize:15.0 andTitleColor:[UIColor whiteColor] andTarget:self andSelector:@selector(parsing) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    parsingBtn.layer.masksToBounds = YES;
    parsingBtn.layer.cornerRadius = 16;
    [self.view addSubview:parsingBtn];
    
    
}

//-(void)creatUI{
//
//
//    UIView *baView = [[UIView alloc]initWithFrame:CGRectMake(k_withBasedIphone6(45), k_withBasedIphone6(160), k_withBasedIphone6(285), k_withBasedIphone6(260))];
//    baView.backgroundColor = [UIColor whiteColor];
//    baView.layer.cornerRadius = k_withBasedIphone6(14);
//    baView.layer.masksToBounds = YES;
//    [self.view addSubview:baView];
//
//    UIView *bgcolor = [MyUIClass makeUIViewWithFrame:CGRectMake(0, 0, k_withBasedIphone6(285), k_withBasedIphone6(8)) andBackColor:Color(7, 196, 190)];
//    [baView addSubview:bgcolor];
//
//    NSString *noStr = [@"订单编号："stringByAppendingString:_backMoneyBillno];
//    UILabel *billno = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(40), k_withBasedIphone6(40), k_withBasedIphone6(205), k_withBasedIphone6(30)) andText:noStr andTextColor:Color(30, 30, 30) andFontSize:16.0 andAlignment:NSTextAlignmentLeft];
//    [baView addSubview:billno];
//
//    NSString *dateStr = [@"订单日期："stringByAppendingString:_backMoneyBillDate];
//    UILabel *billDate = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(40), k_withBasedIphone6(80), k_withBasedIphone6(205), k_withBasedIphone6(30)) andText:dateStr andTextColor:Color(30, 30, 30) andFontSize:16.0 andAlignment:NSTextAlignmentLeft];
//    [baView addSubview:billDate];
//
//    NSString *countStr = [@"订单金额："stringByAppendingString:_backMoneyAmount];
//    UILabel *amount = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(40), k_withBasedIphone6(120), k_withBasedIphone6(205), k_withBasedIphone6(30)) andText:countStr andTextColor:Color(30, 30, 30) andFontSize:16.0 andAlignment:NSTextAlignmentLeft];
//    [baView addSubview:amount];
//
//
//    UIButton *goFirstPageBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(30), k_withBasedIphone6(200), k_withBasedIphone6(100), k_withBasedIphone6(45)) andType:UIButtonTypeCustom andBackColor:Color(7, 196, 190) andTitle:@"返回首页" andTitleFontSize:15.0 andTitleColor:[UIColor whiteColor] andTarget:self andSelector:@selector(pushToMainVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//    [baView addSubview:goFirstPageBtn];
//
//    UIButton *parsingBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(155), k_withBasedIphone6(200), k_withBasedIphone6(100), k_withBasedIphone6(45)) andType:UIButtonTypeCustom andBackColor:Color(7, 196, 190) andTitle:@"立即退款" andTitleFontSize:15.0 andTitleColor:[UIColor whiteColor] andTarget:self andSelector:@selector(parsing) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//    [baView addSubview:parsingBtn];
//
//
//
//
//    
//
//
//}


#pragma mark - 按钮点击事件
//返回首页
-(void)pushToMainVC{
    //发出通知app delegate中切换main为跟视图控制器
    [[NSNotificationCenter defaultCenter] postNotificationName:@"back" object:self];
}

-(void)parsing{
    
    [self backMoney];
}


//退款
-(void)backMoney{
    //http://boss.tjcclz.com:8091/NewBossWebService.asmx/RetOrder?billDate=*&billno=*&amount=*&requestType=0

    double count = [_backMoneyAmount doubleValue] ;
    double price =count *100;
    NSString *temp = [ NSString stringWithFormat:@"%.f",price];

    NSString *newStr = [NSString stringWithFormat:@"http://ckpay.tjcclz.com:8091/NewBossWebService.asmx/RetOrder?billDate=%@&billno=%@&amount=%@&requestType=0",_backMoneyBillDate,_backMoneyBillno,temp];
    
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] getNetworkRequestURLString:newStr parameters:nil success:^(id obj) {

        
        if ([obj[@"errCode"] isEqualToString:@"SUCCESS"]) {
            
            if ([obj[@"refundStatus"] isEqualToString:@"SUCCESS"]){
                
                //退款成功
                BackMoneySuccessController *vc = [[BackMoneySuccessController alloc]init];
                [weakSelf presentViewController:vc animated:YES completion:nil];
                
            }else{
                
                //退款失败
                [weakSelf showAlertWithTitle:@"温馨提示" andMessage:@"您的退款提交失败,请检查网络" andActionTitle:@"重试" andactionBlock:^{
                    
                    [weakSelf backMoney];
                    
                } andActionCancelTitle:@"取消" andActionCancelBlock:^{
                    
                    
                } andBool:YES];
                
            }
            
        }else{
            
            //退款失败
            [weakSelf showAlertWithTitle:@"温馨提示" andMessage:@"您的退款提交失败,请检查网络" andActionTitle:@"重试" andactionBlock:^{
                
                [weakSelf backMoney];
                
            } andActionCancelTitle:@"取消" andActionCancelBlock:^{
                
                
            } andBool:YES];
        }
        
  
        
    } fail:^(NSError *error) {
        
        //退款失败
        [weakSelf showAlertWithTitle:@"温馨提示" andMessage:@"您的退款提交失败,请检查网络" andActionTitle:@"重试" andactionBlock:^{
            
            [weakSelf backMoney];
            
        } andActionCancelTitle:@"取消" andActionCancelBlock:^{
            
            
        } andBool:YES];

    }];
}



//提示框小装 show = yes 有取消按钮。=no只有确定一个按钮
-(void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message andActionTitle:(NSString *)actionTitle andactionBlock:(void(^)(void))ActionBlock andActionCancelTitle:(NSString *)actionCancelTitle andActionCancelBlock:(void(^)(void))ActionCancelBlock andBool:(BOOL)show {
    
    if (show) {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:actionCancelTitle style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionCancelBlock) {
                ActionCancelBlock();
            }
        }];
        [alert addAction:actionCancel];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }else{
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
