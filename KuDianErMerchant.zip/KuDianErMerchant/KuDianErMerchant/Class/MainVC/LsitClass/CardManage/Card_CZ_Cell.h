//
//  Card_CZ_Cell.h
//  KuDianErMerchant
//
//  Created by william on 2018/7/14.
//  Copyright © 2018年 william. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Card_CZ_Cell : UITableViewCell


@property(nonatomic, strong) UIButton *btn;
@property(nonatomic, strong) UILabel *limitLab;
@property(nonatomic, strong) UILabel *descripeLab;

@property (nonatomic, copy) void (^ClickRowBlock)(BOOL isClick);




@end
