//
//  Card_ZK_Cell.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/14.
//  Copyright © 2018年 william. All rights reserved.
//

#import "Card_ZK_Cell.h"

@implementation Card_ZK_Cell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
