//
//  CardSetCController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/10.
//  Copyright © 2018年 william. All rights reserved.
//  储值卡设置

#import "CardSetCController.h"
#import "Card_CZ_Cell.h"

@interface CardSetCController ()<UITableViewDelegate,UITableViewDataSource,UIPickerViewDelegate,UIPickerViewDataSource>

@property(nonatomic, strong) UITableView *TableView;
@property(nonatomic, strong) UITextField *format_priceField;
@property(nonatomic, strong) UITextField *priceField;

@property(nonatomic, strong) NSMutableArray *dateAarray;
@property(nonatomic, strong) NSMutableArray *seleAarray;


@property(nonatomic , strong) UIPickerView *pickerView;
@property(nonatomic , strong) UIButton *btnClose;
@property(nonatomic , strong) NSArray *yearArray;
@property(nonatomic , strong) NSArray *monthArray;
@property(nonatomic , strong) NSArray *dayArray;

@property(nonatomic , strong) UILabel *lab_year;
@property(nonatomic , strong) UILabel *lab_month;
@property(nonatomic , strong) UILabel *lab_day;

@end

@implementation CardSetCController
static NSString *inditer_CZ = @"cellCZ";

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = Color(255, 255, 255);
    self.title = @"储值卡设置";
    
    [self creatUI];
    
    _yearArray = [[NSArray alloc]initWithObjects:@"2010",@"2010",@"2010",@"2014",@"2015",@"2016",@"2017",@"2018",@"2019",@"2010",nil];
    _monthArray = [[NSArray alloc]initWithObjects:@"01",@"02",@"03",@"04",@"05",@"06",@"07",@"08",@"09",@"10",nil];
    _dayArray = [[NSArray alloc]initWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",nil];
}

-(void)creatUI{
 
    self.TableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT)];
    _TableView.delegate = self;
    _TableView.dataSource = self;
    _TableView.rowHeight = k_withBasedIphone6(85);
    [_TableView registerClass:[Card_CZ_Cell class] forCellReuseIdentifier:inditer_CZ];
    [self.view addSubview:_TableView];
    
    UIView *headV = [MyUIClass makeUIViewWithFrame:CGRectMake(0, 0, Screen_W, k_withBasedIphone6(270)) andBackColor:Color(245, 244, 249)];
    _TableView.tableHeaderView = headV;
    
    UILabel *lab_title = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(5), k_withBasedIphone6(100), k_withBasedIphone6(20)) andText:@"添加储值卡" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentLeft];
    [headV addSubview:lab_title];
    
    UIView *backV = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(30), Screen_W, k_withBasedIphone6(195)) andBackColor:Color(255, 255, 255)];
    [headV addSubview:backV];
    UILabel *lab1 = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(20), k_withBasedIphone6(70), k_withBasedIphone6(15)) andText:@"储值卡面额" andTextColor:Color(51, 51, 51) andFontSize:12.0 andAlignment:NSTextAlignmentLeft];
    [backV addSubview:lab1];
    UITextField *field1 = [MyUIClass simpleTextFieldWithFrame:CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(20), k_withBasedIphone6(100), k_withBasedIphone6(15)) andPlaceHolder:@"" andClearBtnMode:UITextFieldViewModeWhileEditing andBackColor:Color(255, 255, 255) andFontSize:12.0];
    [backV addSubview:field1];
    UIView *line1 = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(35), k_withBasedIphone6(100), k_withBasedIphone6(2)) andBackColor:Color(91, 202, 213)];
    [backV addSubview:line1];
    
    UILabel *lab2 = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(50), k_withBasedIphone6(60), k_withBasedIphone6(15)) andText:@"售卖金额" andTextColor:Color(51, 51, 51) andFontSize:12.0 andAlignment:NSTextAlignmentLeft];
    [backV addSubview:lab2];
    UITextField *field2 = [MyUIClass simpleTextFieldWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(50), k_withBasedIphone6(100), k_withBasedIphone6(15)) andPlaceHolder:@"" andClearBtnMode:UITextFieldViewModeWhileEditing andBackColor:Color(255, 255, 255) andFontSize:12.0];
    [backV addSubview:field2];
    UIView *line2 = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(65), k_withBasedIphone6(100), k_withBasedIphone6(2)) andBackColor:Color(91, 202, 213)];
    [backV addSubview:line2];
    
    UILabel *lab3 = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(80), k_withBasedIphone6(50), k_withBasedIphone6(25)) andText:@"有效期至" andTextColor:Color(51, 51, 51) andFontSize:12.0 andAlignment:NSTextAlignmentLeft];
    [backV addSubview:lab3];
  
    UIButton *btn1 = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(80), k_withBasedIphone6(80), k_withBasedIphone6(70), k_withBasedIphone6(20)) andType:UIButtonTypeCustom andImageName:@"" andTarget:self andSelector:@selector(btn1) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    btn1.backgroundColor = [UIColor greenColor];
    [backV addSubview:btn1];
    UIButton *btn2 = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(170), k_withBasedIphone6(80), k_withBasedIphone6(70), k_withBasedIphone6(20)) andType:UIButtonTypeCustom andImageName:@"" andTarget:self andSelector:@selector(btn2) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    btn2.backgroundColor = [UIColor greenColor];
    [backV addSubview:btn2];
    
    
    self.lab_year = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(80), k_withBasedIphone6(110), k_withBasedIphone6(80), k_withBasedIphone6(25)) andText:@"" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentCenter];
    _lab_year.backgroundColor = [UIColor yellowColor];
    [backV addSubview:_lab_year];
    self.lab_month = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(170), k_withBasedIphone6(110), k_withBasedIphone6(60), k_withBasedIphone6(25)) andText:@"" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentCenter];
    _lab_month.backgroundColor = [UIColor yellowColor];
    [backV addSubview:_lab_month];
    self.lab_day = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(240), k_withBasedIphone6(110), k_withBasedIphone6(60), k_withBasedIphone6(25)) andText:@"" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentCenter];
    _lab_day.backgroundColor = [UIColor yellowColor];
    [backV addSubview:_lab_day];
    
    UIButton *creatPicker = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(300), k_withBasedIphone6(110), k_withBasedIphone6(60), k_withBasedIphone6(25)) andType:UIButtonTypeCustom andBackColor:Color(91, 202, 213) andTitle:@"选择时间" andTitleFontSize:14.0 andTitleColor:Color(255, 255, 255) andTarget:self andSelector:@selector(creatUIPickerView) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [backV addSubview:creatPicker];
    
    UIButton *btn_addCard = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(130), k_withBasedIphone6(160), k_withBasedIphone6(115), k_withBasedIphone6(25)) andType:UIButtonTypeCustom andBackColor:Color(91, 202, 213) andTitle:@"确认添加" andTitleFontSize:14.0 andTitleColor:Color(255, 255, 255) andTarget:self andSelector:@selector(addCard) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [backV addSubview:btn_addCard];
    
    
    
    
    UIView *lastV = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(235), Screen_W, k_withBasedIphone6(32)) andBackColor:Color(255, 255, 255)];
    [headV addSubview:lastV];
    UILabel *lastV_lab_title = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(5), k_withBasedIphone6(100), k_withBasedIphone6(20)) andText:@"现有储值卡" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentLeft];
    [lastV addSubview:lastV_lab_title];

    
    self.dateAarray = [NSMutableArray arrayWithArray:@[@"111",@"222",@"333",@"444",@"555",@"666"]];
    self.seleAarray = [NSMutableArray arrayWithCapacity:13];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dateAarray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    Card_CZ_Cell *cell = [tableView dequeueReusableCellWithIdentifier:inditer_CZ];
    
//    cell.cellab.text = _dateAarray[indexPath.row];
    
    cell.ClickRowBlock = ^(BOOL isClick) {
        if (isClick) {//选中
       
            [self.seleAarray addObject:self->_dateAarray[indexPath.row]];
 
        } else {//取消选中

            [self.seleAarray removeObject:self->_dateAarray[indexPath.row]];
   
        }
    };
    
    
    return cell;
}


#pragma mark -- 按钮点击方法

-(void)btn1{
    
}

-(void)btn2{
    
}

-(void)addCard{
    
}

-(void)selector{
//    [self.dateAarray addObject:_field.text];
//    [_TableView reloadData];
}









- (UIPickerView *)pickerView{
    
    if (!_pickerView) {
        
        self.pickerView = [[UIPickerView alloc] init];
        
    }
    
    return _pickerView;
    
}

-(void)creatUIPickerView{
    
    self.pickerView.frame = CGRectMake(k_withBasedIphone6(60), k_withBasedIphone6(160), k_withBasedIphone6(250), k_withBasedIphone6(150));
    self.pickerView.backgroundColor = Color(94, 202, 214);
    // 显示选中框
    _pickerView.showsSelectionIndicator=YES;
    _pickerView.dataSource = self;
    _pickerView.delegate = self;
    [self.view addSubview:_pickerView];
    self.btnClose = [UIButton buttonWithType:(UIButtonTypeSystem)];
    _btnClose.frame = CGRectMake(k_withBasedIphone6(60), k_withBasedIphone6(280), k_withBasedIphone6(250), k_withBasedIphone6(30));
    [_btnClose setTitle:@"确定" forState:(UIControlStateNormal)];
    [_btnClose setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    _btnClose.backgroundColor = Color(116, 195, 255);
    _btnClose.titleLabel.font = [UIFont systemFontOfSize:19];
    [_btnClose addTarget:self action:@selector(close) forControlEvents:(UIControlEventTouchUpInside)];
    [self.view addSubview:_btnClose];
    
    
}
#pragma Mark -- UIPickerViewDataSource
// pickerView 列数
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 3;
}

// pickerView 每列个数
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
//    return [_numArray count];
        if (component == 0) {
            return [_yearArray count];
            
        }else if (component == 1){
            
            return [_monthArray count];
        }else{
    
        return [_dayArray count];
        }
}
// 每列宽度
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    return k_withBasedIphone6(80);
    //    if (component == 1) {
    //        return 40;
    //    }
    //    return 180;
}
// 返回选中的行
//- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
//{
//    if (component == 0) {
//        NSString  *_proNameStr = [_numArray objectAtIndex:row];
//        NSLog(@"nameStr=%@",_proNameStr);
//    } else {
//        NSString  *_proTimeStr = [_countryArray objectAtIndex:row];
//        NSLog(@"_proTimeStr=%@",_proTimeStr);
//    }
//
//}

//返回当前行的内容,此处是将数组中数值添加到滚动的那个显示栏上
-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
//    if (component == 0) {
//        _label.text = [_numArray objectAtIndex:row];
//        return [_numArray objectAtIndex:row];
//    } else {
//        _labDetail.text = [_countryArray objectAtIndex:row];
//        return [_countryArray objectAtIndex:row];
//
//    }
    
    if (component == 0) {
        _lab_year.text = [_yearArray objectAtIndex:row];

        return [_yearArray objectAtIndex:row];

    }else if (component == 1){
        _lab_month.text = [_monthArray objectAtIndex:row];

        return [_monthArray objectAtIndex:row];
    }else{
        _lab_day.text = [_dayArray objectAtIndex:row];

        return [_dayArray objectAtIndex:row];
    }
}

//选择器上的关闭按钮
- (void)close{
    
    [ _pickerView removeFromSuperview];
    [_btnClose removeFromSuperview];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
