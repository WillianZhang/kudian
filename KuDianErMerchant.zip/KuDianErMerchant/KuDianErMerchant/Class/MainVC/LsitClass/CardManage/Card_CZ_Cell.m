//
//  Card_CZ_Cell.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/14.
//  Copyright © 2018年 william. All rights reserved.
//

#import "Card_CZ_Cell.h"

@implementation Card_CZ_Cell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.backgroundColor = Color(245, 244, 249);
        
        UIView *back = [MyUIClass makeUIViewWithFrame:CGRectMake(0, 0, Screen_W, k_withBasedIphone6(75)) andBackColor:Color(255, 255, 255)];
        [self addSubview:back];
        
        self.btn = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(30), k_withBasedIphone6(30), k_withBasedIphone6(15), k_withBasedIphone6(15)) andType:UIButtonTypeCustom andImageName:@"未选中" andTarget:self andSelector:@selector(click:) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
        [back addSubview:_btn];
        
        UILabel *title = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(70), k_withBasedIphone6(20), k_withBasedIphone6(70), k_withBasedIphone6(20)) andText:@"储值卡" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentLeft];
        [back addSubview:title];
        
        self.limitLab =[MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(70), k_withBasedIphone6(40), k_withBasedIphone6(70), k_withBasedIphone6(20)) andText:@"xxxxx" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentLeft];
        [back addSubview:_limitLab];
        
        UIView *line = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(150), k_withBasedIphone6(5), k_withBasedIphone6(2), k_withBasedIphone6(70)) andBackColor:Color(245, 244, 249)];
        [back addSubview:line];
        
        self.descripeLab = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(160), k_withBasedIphone6(30), k_withBasedIphone6(100), k_withBasedIphone6(20)) andText:@"xxxxxxx" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentLeft];
        [back addSubview:_descripeLab];
        
        
    }
    return self;
}


//选中
- (void)click:(UIButton *)sender {
    sender.selected = !sender.selected;
    if (sender.selected) {
        [sender setImage:[UIImage imageNamed:@"选中"] forState:(UIControlStateNormal)];
    } else {
        [sender setImage:[UIImage imageNamed:@"未选中"] forState:(UIControlStateNormal)];
    }
    if (self.ClickRowBlock) {
        self.ClickRowBlock(sender.selected);
    }
}




- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
