//
//  CardManageController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//  卡管理

#import "CardManageController.h"
#import "CardSetCController.h"
#import "CardSetZKController.h"

@interface CardManageController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic ,strong) NSArray *imgArray;
@property(nonatomic ,strong) NSArray *titleArray;

@property(nonatomic ,strong) CardSetCController * cardSetC;
@property(nonatomic ,strong) CardSetZKController * CardSetZK;

@end

@implementation CardManageController
static NSString *indenfuer = @"cell";

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"卡管理";
    [self creatUI];
    self.imgArray = @[@"",@""];
    self.titleArray = @[@"储值卡设置",@"折扣卡设置"];
}

-(void)creatUI{
    UITableView * tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT) style:UITableViewStylePlain];
    //_memberListTableView.separatorColor = [UIColor blackColor];
//    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.rowHeight = k_withBasedIphone6(60);
    [tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:indenfuer];
    
    [self.view addSubview:tableView];
}


//UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.titleArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indenfuer];
    
    [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    UIImageView *headImage = [MyUIClass makeUIImageWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(15), k_withBasedIphone6(20), k_withBasedIphone6(30)) andPicName:_imgArray[indexPath.row]];
    
    UILabel *title = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(40), k_withBasedIphone6(15), k_withBasedIphone6(100), k_withBasedIphone6(30)) andText:_titleArray[indexPath.row] andTextColor:Color(51, 51, 51) andFontSize:14 andAlignment:NSTextAlignmentLeft];
    
    [cell addSubview:headImage];
    [cell addSubview:title];
 
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
   
    switch (indexPath.row) {
        case 0:
            
            _cardSetC = [[CardSetCController alloc]init];
            [self.navigationController pushViewController:_cardSetC animated:YES];
            
            break;
        case 1:
            
            _CardSetZK = [[CardSetZKController alloc]init];
            [self.navigationController pushViewController:_CardSetZK animated:YES];
            
            break;

        default:
            break;
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
