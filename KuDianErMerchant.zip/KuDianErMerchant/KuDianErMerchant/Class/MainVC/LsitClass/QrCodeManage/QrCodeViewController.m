//
//  cellModel.h
//  GractWall
//
//  Created by william on 2018/8/7.
//  Copyright © 2018年 william. All rights reserved.
//

//#import <Foundation/Foundation.h>
//
//@interface cellModel : NSObject
//
//@end
//
//  QrCodeViewController.m
//  BiKuMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//  二维码扫描

#import "QrCodeViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "LCQRCodeUtil.h"
#import "DFYSVP.h"
#import "OrderDetailController.h"
#import "LoginController.h"
#import "CartModel.h"
#import "SettleAccountsController.h"

#define SCREEN_BOUNDS  [UIScreen mainScreen].bounds

#define TOP (Screen_H-220)/3
#define LEFT (Screen_W-220)/2

#define kScanRect CGRectMake(LEFT, TOP, 220, 220)
@interface QrCodeViewController ()<AVCaptureMetadataOutputObjectsDelegate>
{
    int num;
    BOOL upOrdown;
    CAShapeLayer *cropLayer;
}

@property (strong,nonatomic)AVCaptureDevice * device;
@property (strong,nonatomic)AVCaptureDeviceInput * input;
@property (strong,nonatomic)AVCaptureMetadataOutput * output;
@property (strong,nonatomic)AVCaptureSession * session;
@property (strong,nonatomic)AVCaptureVideoPreviewLayer * preview;

@property (nonatomic, strong) UIImageView * line;
@property (nonatomic, strong) NSTimer * timer;
@property (nonatomic, strong) UILabel *desLabel;
@property (nonatomic, strong) UIButton *toNumBtn;

@property (nonatomic, strong) NSMutableArray *listArrGoods_sn;
@property (nonatomic, strong) NSMutableArray *listArrGoods_number;//购物车商品的单个数量容纳

@property (nonatomic, strong) NSMutableDictionary *goods_snToNnmDictionary;//盛放good_sn对应数量
@property (nonatomic, strong) NSMutableDictionary *goods_snToRecDictionary;//盛放good_sn对应rec_id
@property (nonatomic, strong) UIView *backCart;
@property (nonatomic, strong) UILabel *totalCount;


@end

@implementation QrCodeViewController

-(void)viewWillAppear:(BOOL)animated{
    
    [self.listArrGoods_sn removeAllObjects];
    [self.listArrGoods_number removeAllObjects];
    [self.goods_snToNnmDictionary removeAllObjects];
    [self.goods_snToRecDictionary removeAllObjects];
    
    [self creatCartList];
    
    if (self.session != nil && self.timer != nil) {
        [self.session startRunning];
        [self.timer setFireDate:[NSDate date]];
    }
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"扫码验证";
    self.view.backgroundColor = Color(246, 246, 246);
    //    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"验证记录" style:UIBarButtonItemStylePlain target:self action:@selector(pushToRecord)];
    
    self.listArrGoods_sn = [NSMutableArray arrayWithCapacity:13];
    self.listArrGoods_number = [NSMutableArray arrayWithCapacity:13];
    
    self.goods_snToNnmDictionary = [NSMutableDictionary dictionaryWithCapacity:13];
    self.goods_snToRecDictionary = [NSMutableDictionary dictionaryWithCapacity:13];
    
    [self setCropRect:kScanRect];
    
    [self performSelector:@selector(setupCamera) withObject:nil afterDelay:0.3];
    [self configView];
    [self creatCart];
    //    self.ShoppingCartView = [MyUIClass makeUIImageWithFrame:CGRectMake(Screen_W/3, Screen_H/5*3, Screen_W/3, Screen_W/3) andPicName:@"Shopping_Cart_Qr"];
    //    _ShoppingCartView.backgroundColor = [UIColor yellowColor];
    //    [self.view addSubview:_ShoppingCartView];
}

-(void)creatCart{
    self.backCart = [MyUIClass makeUIViewWithFrame:CGRectMake(Screen_W/3, Screen_H/3*2, Screen_W/3, Screen_W/3+30) andBackColor:[UIColor clearColor]];
    
    UIButton *cartBtn = [MyUIClass makeImageButtonWithFrame:CGRectMake(0, 20, Screen_W/3, Screen_W/3) andType:UIButtonTypeCustom andImageName:@"gouwuche" andTarget:self andSelector:@selector(pushToSettleVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    
    
    self.totalCount = [MyUIClass simpleLabelWithFrame:CGRectMake(Screen_W/3-40, 50, 35, 25) andText:@"0" andTextColor:Color(231, 43, 50) andFontSize:12 andAlignment:NSTextAlignmentCenter];
    self.totalCount.backgroundColor = [UIColor whiteColor];
    self.totalCount.layer.masksToBounds = YES;
    self.totalCount.layer.cornerRadius = 12;
    self.totalCount.layer.borderColor = Color(231, 43, 50).CGColor;
    self.totalCount.layer.borderWidth = 0.7;
    
    
    [self.view addSubview:_backCart];
    [_backCart addSubview:cartBtn];
    [_backCart addSubview:_totalCount];
}

//隐藏状态栏
//-(BOOL)prefersStatusBarHidden{
//    return  YES;
//}
//扫码框设置
-(void)configView{
    
    //    self.desLabel = [MyUIClass simpleLabelWithFrame:CGRectMake(Screen_W/4, TOP+250, Screen_W/2, 30) andText:@"未扫到二维码，点此反馈" andTextColor:Color(222, 222, 222) andFontSize:15.0 andAlignment:NSTextAlignmentCenter];
    //    self.desLabel.backgroundColor = [UIColor blackColor];
    //[self.view addSubview:self.desLabel];
    
    //    self.toNumBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    //    _toNumBtn.frame = CGRectMake(Screen_W/4*3, TOP+250, 30, 30);
    //    [_toNumBtn setBackgroundImage:[UIImage imageNamed:@"下一步"] forState:UIControlStateNormal];
    //    [_toNumBtn addTarget:self action:@selector(pushToNumSelector) forControlEvents:UIControlEventTouchUpInside];
    //[self.view addSubview:_toNumBtn];
    
    
    UIImageView * imageView = [[UIImageView alloc]initWithFrame:kScanRect];
    imageView.image = [UIImage imageNamed:@"pick_bg"];
    [self.view addSubview:imageView];
    
    upOrdown = NO;
    num =0;
    _line = [[UIImageView alloc] initWithFrame:CGRectMake(LEFT, TOP+10, 220, 2)];
    _line.image = [UIImage imageNamed:@"line.png"];
    [self.view addSubview:_line];
    
    self.timer = [NSTimer scheduledTimerWithTimeInterval:.02 target:self selector:@selector(animation1) userInfo:nil repeats:YES];
    
    
}

#pragma mark -- 按钮点击方法
-(void)pushToSettleVC{
    
    SettleAccountsController *vc = [[SettleAccountsController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    
}

//序列号验证
- (void)pushToNumSelector{
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    self.navigationController.navigationBar.tintColor = Color(150, 150, 150);
    
}

-(void)pushToRecord{
    NSLog(@"验证记录");
}
//扫码框小条上下动画
-(void)animation1
{
    if (upOrdown == NO) {
        num ++;
        _line.frame = CGRectMake(LEFT, TOP+10+2*num, 220, 2);
        if (2*num == 200) {
            upOrdown = YES;
        }
    }
    else {
        num --;
        _line.frame = CGRectMake(LEFT, TOP+10+2*num, 220, 2);
        if (num == 0) {
            upOrdown = NO;
        }
    }
    
}

//扫码框图层背景设置
- (void)setCropRect:(CGRect)cropRect{
    cropLayer = [[CAShapeLayer alloc] init];
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddRect(path, nil, cropRect);
    CGPathAddRect(path, nil, self.view.bounds);
    
    [cropLayer setFillRule:kCAFillRuleEvenOdd];
    [cropLayer setPath:path];
    [cropLayer setFillColor:Color(40, 40, 40).CGColor];//设置黑色透明覆盖
    [cropLayer setOpacity:0.7];
    
    
    [cropLayer setNeedsDisplay];
    
    [self.view.layer addSublayer:cropLayer];
    [self.view bringSubviewToFront:self.desLabel];
    [self.view bringSubviewToFront:self.toNumBtn];
    
}
//扫码功能及属性设置
- (void)setupCamera
{
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    if (device==nil) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"设备没有摄像头" preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
        }]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    // Device
    self.device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    
    // Input
    self.input = [AVCaptureDeviceInput deviceInputWithDevice:self.device error:nil];
    
    // Output
    self.output = [[AVCaptureMetadataOutput alloc]init];
    [self.output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    
    //设置扫描区域
    CGFloat top = TOP/Screen_H;
    CGFloat left = LEFT/Screen_W;
    CGFloat width = 220/Screen_W;
    CGFloat height = 220/Screen_H;
    ///top 与 left 互换  width 与 height 互换
    [self.output setRectOfInterest:CGRectMake(top,left, height, width)];
    
    
    // Session
    self.session = [[AVCaptureSession alloc]init];
    [self.session setSessionPreset:AVCaptureSessionPresetHigh];
    if ([self.session canAddInput:self.input])
    {
        [self.session addInput:self.input];
    }
    
    if ([self.session canAddOutput:self.output])
    {
        [self.session addOutput:self.output];
    }
    
    // 条码类型 AVMetadataObjectTypeQRCode常用二维码---AVMetadataObjectTypeEAN13Code，AVMetadataObjectTypeEAN8Code常用条形码
    [self.output setMetadataObjectTypes:[NSArray arrayWithObjects:AVMetadataObjectTypeEAN13Code,AVMetadataObjectTypeEAN8Code,AVMetadataObjectTypeCode39Code,AVMetadataObjectTypeCode39Mod43Code, nil]];
    
    // Preview
    self.preview =[AVCaptureVideoPreviewLayer layerWithSession:self.session];
    self.preview.videoGravity = AVLayerVideoGravityResizeAspectFill;
    self.preview.frame =self.view.layer.bounds;
    [self.view.layer insertSublayer:self.preview atIndex:0];
    
    // Start
    [self.session startRunning];
}

#pragma mark - AVCaptureMetadataOutputObjectsDelegate 扫描结果
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection
{
    NSString *stringValue;
    
    if ([metadataObjects count] >0)
    {
        //停止扫描
        [self.session stopRunning];
        [self.timer setFireDate:[NSDate distantFuture]];
        
        AVMetadataMachineReadableCodeObject * metadataObject = [metadataObjects objectAtIndex:0];
        stringValue = metadataObject.stringValue;
        
        NSLog(@"扫描结果是：%@",stringValue);
        
        //        NSArray *arry = metadataObject.corners;
        //        for (id temp in arry) {
        //
        //        }
        //扫描到的产品good_sn但是前面需要拼接店铺IDSeller_id
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        NSString *seller_id = [userDefault objectForKey:@"Seller_id"];
        NSString *temp = [@"_"stringByAppendingString:stringValue];
        NSString *seller_idStr = [NSString stringWithFormat:@"%@",seller_id];
        NSString *shopGood_sn =  [seller_idStr stringByAppendingString:temp];
        
        if ([_listArrGoods_sn containsObject:shopGood_sn]) {
            //购物车订单号包含点击的订单号
            
            NSString *rec_id = [self.goods_snToRecDictionary valueForKey:shopGood_sn];
            NSString *good_number = [self.goods_snToNnmDictionary valueForKey:shopGood_sn];
            NSLog(@"%@-%@",rec_id,good_number);
            NSInteger count = [good_number integerValue];
            count++;
            NSString *numStr = [NSString stringWithFormat:@"%ld",(long)count];
            
            [self addGoodsRec_id:rec_id andNumber:numStr];
            
        }else{
            
            //不包含默认第一次添加
            [self addGoodsForCart:shopGood_sn];
            
        }
        
        
    } else {
        NSLog(@"无扫描信息");
        
        NSString *alterString = @"数据加载失败，请检查网络！";
        [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:^{
            
            if (self.session != nil && self.timer != nil) {
                [self.session startRunning];
                [self.timer setFireDate:[NSDate date]];
            }
            
        } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
        return;
    }
    
}

#pragma mark - parsing
////扫码结果调用 查询商品 商品信息
//-(void)parsing:(NSString *)good_sn{
//    NSString *URLString = @"http://ecjia.cckdtj.com/sites/api/?url=admin/goods/product_search"; //扫码查询
//    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
//    NSString *tokenStr = [userDefault objectForKey:@"Token"];
//
//    NSDictionary *parameters = @{
//                                 @"token": tokenStr,
//                                 @"goods_sn": good_sn
//                                 };
//
//    [[MyHttpRequest shardWebUtil] postNetworkRequestURLString:URLString parameters:parameters success:^(id obj) {
//
//    } successOne:^(id responseObject) {
//            NSLog(@"aaaaa %@",responseObject);
//            //跳转 后传订单号。去下一个页面数据请求
//
//
//    } successZero:^(id responseObject) {
//
//        NSString *alterStr = responseObject[@"status"][@"error_desc"];
//
//        if ([alterStr isEqualToString:@"Invalid session"]) {
//
//            //            NSLog(@"token改变，登陆过期");
//            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"登陆过期，请重新登录" preferredStyle:(UIAlertControllerStyleAlert)];
//            UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
//
//                LoginController *vc = [[LoginController alloc]init];
//                [self.navigationController pushViewController:vc animated:YES];
//            }];
//            [alert addAction:action];
//            [self presentViewController:alert animated:YES completion:nil];
//
//        }else{
//
//                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"扫描结果" message:alterStr preferredStyle:UIAlertControllerStyleAlert];
//                [alert addAction:[UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//                    if (self.session != nil && self.timer != nil) {
//                        [self.session startRunning];
//                        [self.timer setFireDate:[NSDate date]];
//                    }
//
//                }]];
//                [self presentViewController:alert animated:YES completion:nil];
//            }
//
//    } fail:^(NSError *error) {
//
//    }];
//}


//点击添加购物车 第一次添加
-(void)addGoodsForCart:(NSString *)goods_sn{
  
    //http://ecjia.cckdtj.com/sites/api/?url=admin/flow/checkOrder
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userDefault objectForKey:@"Token"];
    NSString *member_user_id = [userDefault objectForKey:@"member_user_id"];
    NSString *temp = @"/sites/api/?url=admin/flow/checkOrder";
    NSString *string = [cckdURL stringByAppendingString:temp];//查询购物车接口
    NSDictionary *parameters = @{
                                 
                                 @"token" : token,
                                 @"addgoods":@{
                                         @"goods_sn":goods_sn,
                                         @"number":@1
                                         },
                                 
                                 @"user":@{
                                         @"user_id":[NSNumber numberWithInteger:[member_user_id integerValue]],
                                         }
                                 };
    
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
        
        
        NSInteger about = [self.totalCount.text integerValue];
        about++;
        NSString *temp = [NSString stringWithFormat:@"%ld",(long)about];
        self.totalCount.text = temp;
        
        [self shakeAnimation];
        
//        LLog(@"🐂哭%@",responseObject);
        NSArray * array = responseObject[@"data"][@"goods_list"];//数组可以上空
        for (NSDictionary *dic in array) {
            CartModel *model = [CartModel new];
            [model setValuesForKeysWithDictionary:dic];
            [self.listArrGoods_sn addObject:model.goods_sn];
            [self.goods_snToRecDictionary setValue:model.rec_id forKey:model.goods_sn];
            [self.goods_snToNnmDictionary setValue:@"1" forKey:model.goods_sn];
        }
        
        

        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            if (self.session != nil && self.timer != nil) {
                [self.session startRunning];
                [self.timer setFireDate:[NSDate date]];
            }
        });
        
        
    } successZero:^(id responseObject) {
   
        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");
            
            [self showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
            
            
        }else{
            
            [self showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:^{
                
                if (self.session != nil && self.timer != nil) {
                    [self.session startRunning];
                    [self.timer setFireDate:[NSDate date]];
                }
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        }
        
    } fail:^(NSError *error) {

        NSString *alterString = @"数据加载失败，请检查网络！";
        [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:^{
            
            if (self.session != nil && self.timer != nil) {
                [self.session startRunning];
                [self.timer setFireDate:[NSDate date]];
            }
        } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }];
    
    
}

//已经存在于购物车的走这个更新接口
-(void)addGoodsRec_id:(NSString *)rec_id andNumber:(NSString *)number{

    //http://ecjia.cckdtj.com/sites/api/?url=admin/flow/checkOrder
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userDefault objectForKey:@"Token"];
    NSString *member_user_id = [userDefault objectForKey:@"member_user_id"];
    NSString *temp = @"/sites/api/?url=admin/flow/checkOrder";
    NSString *string = [cckdURL stringByAppendingString:temp];//查询购物车接口
    NSDictionary *parameters = @{
                                 
                                 @"token" : token,
                                 @"updategoods":@{
                                         @"rec_id":[NSNumber numberWithInteger:[rec_id integerValue]],
                                         @"number":[NSNumber numberWithInteger:[number integerValue]]
                                         },
                                 
                                 @"user":@{
                                         @"user_id":[NSNumber numberWithInteger:[member_user_id integerValue]],
                                         }
                                 };
    __weak typeof(self) weakSelf = self;
     [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
        
        
//        LLog(@"%@",responseObject);
        NSInteger about = [self.totalCount.text integerValue];
        about++;
        NSString *temp = [NSString stringWithFormat:@"%ld",(long)about];
        self.totalCount.text = temp;
        
        [self shakeAnimation];
        
        [self.listArrGoods_sn removeAllObjects];
        [self.listArrGoods_number removeAllObjects];
        NSArray * array = responseObject[@"data"][@"goods_list"];//数组可以上空
        // [self.listArrGoods_number removeAllObjects];
        for (NSDictionary *dic in array) {
            CartModel *model = [CartModel new];
            [model setValuesForKeysWithDictionary:dic];
            [self.listArrGoods_sn addObject:model.goods_sn];
            //NSLog(@"%@-%@",model.rec_id,model.goods_number);
            [self.goods_snToRecDictionary setValue:model.rec_id forKey:model.goods_sn];
            [self.goods_snToNnmDictionary setValue:model.goods_number forKey:model.goods_sn];
            
            //NSLog(@"%@-%@",self.goods_snToRecDictionary,self.goods_snToNnmDictionary);
            //[self.listArrGoods_number addObject:model.goods_number];
            
        }
        

        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            if (self.session != nil && self.timer != nil) {
                [self.session startRunning];
                [self.timer setFireDate:[NSDate date]];
            }
        });
        
        
    } successZero:^(id responseObject) {
 
        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");
            [self showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
            
            
        }else{
            
            [self showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:^{
                
                if (self.session != nil && self.timer != nil) {
                    [self.session startRunning];
                    [self.timer setFireDate:[NSDate date]];
                }
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
        }
        
    } fail:^(NSError *error) {
        
 
        NSString *alterString = @"数据加载失败，请检查网络！";
        [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:^{
            
            if (self.session != nil && self.timer != nil) {
                [self.session startRunning];
                [self.timer setFireDate:[NSDate date]];
            }
        } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }];
}


//获取显示购物车内容-用于判定扫码得到的商品吗是否已经在购物车中
-(void)creatCartList{

    //http://ecjia.cckdtj.com/sites/api/?url=admin/flow/checkOrder
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *tokenStr = [userDefault objectForKey:@"Token"];
    NSString *User_id = [userDefault objectForKey:@"member_user_id"];
    //以后数据前加个判断可以预防返回或取到null数据导致的崩溃
    //    if (User_id == nil ) {
    //        User_id = @"";
    //    }
    NSLog(@"会员816的ID%@",User_id);
    NSString *string = @"http://ecjia.cckdtj.com/sites/api/?url=admin/flow/checkOrder";//查询购物车接口
    NSDictionary *parameters = @{
                                 
                                 @"token" : tokenStr,
                                 @"user":@{
                                         @"user_id":[NSNumber numberWithInteger:[User_id integerValue]],
                                         }
                                 };
    
    __weak typeof(self) weakSelf = self;
     [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
        
        
        LLog(@"zong%@",responseObject);
        if (![responseObject[@"data"][@"goods_list"] isKindOfClass:[NSArray class]] ) {
            
            self.totalCount.text = @"0";
            
        }else{
            
            NSArray * array = responseObject[@"data"][@"goods_list"];//数组可以上空
            // [self.listArrGoods_number removeAllObjects];
            for (NSDictionary *dic in array) {
                CartModel *model = [CartModel new];
                [model setValuesForKeysWithDictionary:dic];
                [self.listArrGoods_sn addObject:model.goods_sn];
                //NSLog(@"%@-%@",model.rec_id,model.goods_number);
                [self.goods_snToRecDictionary setValue:model.rec_id forKey:model.goods_sn];
                [self.goods_snToNnmDictionary setValue:model.goods_number forKey:model.goods_sn];
                
                //NSLog(@"%@-%@",self.goods_snToRecDictionary,self.goods_snToNnmDictionary);
                [self.listArrGoods_number addObject:model.goods_number];
                
            }
            
            CGFloat sum = [[self.listArrGoods_number valueForKeyPath:@"@sum.floatValue"] floatValue];
            self.totalCount.text = [NSString stringWithFormat:@"%.f",sum];
        }
        

        
    } successZero:^(id responseObject) {

        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");
            
            [self showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
        }else{
            
            [self showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:^{
                
                [self creatCartList];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
        }
        
    } fail:^(NSError *error) {
        
        NSString *alterString = @"数据加载失败，请检查网络！";
        [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:^{
            
            [self creatCartList];
            
        } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }];
    
}


//提示框小装 show = yes 有取消按钮。=no只有确定一个按钮
-(void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message andActionTitle:(NSString *)actionTitle andactionBlock:(void(^)(void))ActionBlock andActionCancelTitle:(NSString *)actionCancelTitle andActionCancelBlock:(void(^)(void))ActionCancelBlock andBool:(BOOL)show {
    
    if (show) {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:actionCancelTitle style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionCancelBlock) {
                ActionCancelBlock();
            }
        }];
        [alert addAction:actionCancel];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }else{
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}

- (void)dismiss:(UIAlertController *)alert{
    //    [alert dismissViewControllerAnimated:YES completion:nil];
    if (self.session != nil && self.timer != nil) {
        [self.session startRunning];
        [self.timer setFireDate:[NSDate date]];
    }
}


//购物车抖动动画
-(void)shakeAnimation{
    CAKeyframeAnimation *anima = [CAKeyframeAnimation animationWithKeyPath:@"transform.rotation"];//在这里@"transform.rotation"==@"transform.rotation.z"
    NSValue *value1 = [NSNumber numberWithFloat:-M_PI/180*4];
    NSValue *value2 = [NSNumber numberWithFloat:M_PI/180*4];
    NSValue *value3 = [NSNumber numberWithFloat:-M_PI/180*4];
    anima.values = @[value1,value2,value3];
    anima.repeatCount = 5;
    
    [_backCart.layer addAnimation:anima forKey:@"shakeAnimation"];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
