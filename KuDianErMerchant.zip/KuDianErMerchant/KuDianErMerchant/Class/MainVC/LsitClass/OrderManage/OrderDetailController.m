//
//  OrderDetailController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/11.
//  Copyright © 2018年 william. All rights reserved.
//

#import "OrderDetailController.h"

@interface OrderDetailController ()<UITableViewDataSource,UITableViewDelegate>

//@property(nonatomic, strong) UITableView *detailTableView;

@end

@implementation OrderDetailController
static NSString *identufuer = @"cellReuse";

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self parsing];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = Color(240, 240, 240);
    self.title = @"订单详情";
    [self creatUI];
    
    
}

-(void)parsing{
    NSString *URLString = @"http://ecjia.cckdtj.com/sites/api/?url=admin/orders/detail";
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *tokenStr = [userDefault objectForKey:@"Token"];
    NSLog(@"token改变%@",tokenStr);
    NSDictionary *parameters = @{
                                 
                                 
                                 
                                 @"token" : tokenStr,
                                 @"id" : _order_idString,
                    
                                 };
    
    [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:URLString parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
  
        NSArray *array = responseObject[@"data"];
        
        for (NSDictionary *dic in array) {
//            GoodManageModel *model = [GoodManageModel new];
//            [model setValuesForKeysWithDictionary:dic];
            //            NSLog(@"%@",model);
            
//            [self.itemsArray addObject:model];
            
            //            NSLog(@"%@--%@",self->_itemsArrName,self->_itemsArrImg );
        }
        
//        [self.goodsListTableView reloadData];
    } successZero:^(id responseObject) {
        
        //        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        //         NSLog(@"bbb %@",responseObject);
        
        //        if ([alterStr isEqualToString:@"Invalid session"]) {
        //
        //            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"登陆过期，请重新登录" preferredStyle:(UIAlertControllerStyleAlert)];
        //            UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
        //
        //                LoginViewController *vc = [[LoginViewController alloc]init];
        //                [self.navigationController pushViewController:vc animated:YES];
        //            }];
        //            [alert addAction:action];
        //            [self presentViewController:alert animated:YES completion:nil];
        //
        //        }else{
        //
        //            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:alterStr preferredStyle:(UIAlertControllerStyleAlert)];
        //            UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:(UIAlertActionStyleDefault) handler:nil];
        //            [alert addAction:action];
        //            [self presentViewController:alert animated:YES completion:nil];
        //        }
    } fail:^(NSError *error) {
        
    }];
}

-(void)creatUI{
   
    UITableView *tableView =  [[UITableView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT) style:UITableViewStylePlain];
  
    tableView.rowHeight = k_withBasedIphone6(90);
    tableView.dataSource = self;
    tableView.delegate = self;
 
    [tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:identufuer];
    [self.view addSubview:tableView];
    
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0,Screen_W, k_withBasedIphone6(110))];
    headerView.backgroundColor = [UIColor lightGrayColor];
    tableView.tableHeaderView = headerView;
    
    NSArray *arr = @[@"订单编号",@"订单创建时间",@"支付时间"];
    NSArray *arrtest = @[@"324324235345",@"2011.12.23 11.58",@"2011.12.23 11.58"];
    for (int i = 0; i < 3; i++) {
        
        UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(10)+k_withBasedIphone6(22)*i, k_withBasedIphone6(110), k_withBasedIphone6(20)) andText:arr[i] andTextColor:Color(51, 51, 51) andFontSize:13.0 andAlignment:NSTextAlignmentLeft];
        [headerView addSubview:label];
        
        UILabel *labell = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(120), k_withBasedIphone6(10)+k_withBasedIphone6(22)*i, k_withBasedIphone6(160), k_withBasedIphone6(20)) andText:arrtest[i] andTextColor:Color(180, 180, 180) andFontSize:13.0 andAlignment:NSTextAlignmentLeft];
        [headerView addSubview:labell];
        
    }
    UIView *line = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(76), Screen_W, k_withBasedIphone6(2)) andBackColor:Color(200, 200, 200)];
    [headerView addSubview:line];
    
    UILabel *title = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(80), k_withBasedIphone6(50), k_withBasedIphone6(25)) andText:@"商品" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentLeft];
    [headerView addSubview:title];
    

    UIView *footView = [[UIView alloc] initWithFrame:CGRectMake(0, 0,Screen_W, k_withBasedIphone6(210))];
    footView.backgroundColor = [UIColor lightGrayColor];
    tableView.tableFooterView = footView;
    
    UILabel *totalPrice = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(10), k_withBasedIphone6(120), k_withBasedIphone6(30)) andText:@"总价:444" andTextColor:Color(51, 51, 51) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
    [footView addSubview:totalPrice];
    
    UILabel *price = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(140), k_withBasedIphone6(10), k_withBasedIphone6(170), k_withBasedIphone6(30)) andText:@"实付款:134.01" andTextColor:Color(224, 27, 50) andFontSize:16.0 andAlignment:NSTextAlignmentLeft];
    [footView addSubview:price];
    
    UIButton *button = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(315), k_withBasedIphone6(10), k_withBasedIphone6(50), k_withBasedIphone6(20)) andType:UIButtonTypeCustom andBackColor:Color(255, 255, 255) andTitle:@"退款" andTitleFontSize:14.0 andTitleColor:Color(94, 202, 214) andTarget:self andSelector:@selector(backMoney) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [footView addSubview:button];
    
    UIView *lineeee = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(40), Screen_W, k_withBasedIphone6(2)) andBackColor:Color(200, 200, 200)];
    [footView addSubview:lineeee];
    
    UILabel *buyer = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(50), k_withBasedIphone6(60), k_withBasedIphone6(20)) andText:@"买家信息" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentLeft];
    [footView addSubview:buyer];
    
    UIView *lineee = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(80), Screen_W, k_withBasedIphone6(2)) andBackColor:Color(200, 200, 200)];
    [footView addSubview:lineee];
    
    NSArray *arrBuyer = @[@"会员ID：2345534",@"昵称：Jack 的我",@"手机号：13345675433"];
    for (int i = 0; i < 3; i++) {
        
        UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(90)+k_withBasedIphone6(22)*i, k_withBasedIphone6(200), k_withBasedIphone6(20)) andText:arrBuyer[i] andTextColor:Color(51, 51, 51) andFontSize:13.0 andAlignment:NSTextAlignmentLeft];
        [footView addSubview:label];
        
    }
    
    UIView *linee = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(164), Screen_W, k_withBasedIphone6(2)) andBackColor:Color(200, 200, 200)];
    [footView addSubview:linee];
    
    UILabel *orderStaue = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(170), k_withBasedIphone6(60), k_withBasedIphone6(30)) andText:@"订单状态" andTextColor:Color(51, 51, 51) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
    [footView addSubview:orderStaue];
    
    UILabel *staue = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(80), k_withBasedIphone6(170), k_withBasedIphone6(60), k_withBasedIphone6(30)) andText:@"已完成" andTextColor:Color(224, 27, 50) andFontSize:16.0 andAlignment:NSTextAlignmentLeft];
    [footView addSubview:staue];
    
}

#pragma mark--tableViewDataSource

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identufuer];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    UIImageView *goodsImage = [MyUIClass makeUIImageWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(10), k_withBasedIphone6(70), k_withBasedIphone6(70)) andPicName:@"goodsimage"];
    
    
    UILabel *goodsName = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(5), k_withBasedIphone6(255), k_withBasedIphone6(20)) andText:@"测试商品001" andTextColor:Color(51, 51, 51) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
    goodsName.backgroundColor = [UIColor yellowColor];
    
    UILabel *balance = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(30), k_withBasedIphone6(255), k_withBasedIphone6(20)) andText:@"重量：1kg 口味：孜然羊肉味" andTextColor:Color(200, 200, 200) andFontSize:13.0 andAlignment:NSTextAlignmentLeft];
    balance.backgroundColor = [UIColor purpleColor];
    
    UILabel *spend = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(60), k_withBasedIphone6(100), k_withBasedIphone6(25)) andText:@"¥1240" andTextColor:Color(224, 27, 50) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
    
    UILabel *spend1 = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(300), k_withBasedIphone6(60), k_withBasedIphone6(55), k_withBasedIphone6(20)) andText:@"数量：3" andTextColor:Color(200, 200, 200) andFontSize:13.0 andAlignment:NSTextAlignmentLeft];
    
   
    [cell addSubview:goodsImage];
    [cell addSubview:goodsName];
    [cell addSubview:balance];
    [cell addSubview:spend];
    [cell addSubview:spend1];
   
    return cell;
}



#pragma mark -- 按钮点击方法

-(void)backMoney{
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
