//
//  OrderListModel.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/19.
//  Copyright © 2018年 william. All rights reserved.
//

#import "OrderListModel.h"

@implementation OrderListModel

// 容错处理
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}


-(NSString *)description{
    return [NSString stringWithFormat:@"%@-%@-%@",_order_sn,_create_time,_order_id];
}


@end
