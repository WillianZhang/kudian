//
//  OrderListModel.h
//  KuDianErMerchant
//
//  Created by william on 2018/7/19.
//  Copyright © 2018年 william. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OrderListModel : NSObject

@property(nonatomic ,strong) NSString *order_sn;
@property(nonatomic ,strong) NSString *create_time;
@property(nonatomic ,strong) NSString *order_id;

@end
