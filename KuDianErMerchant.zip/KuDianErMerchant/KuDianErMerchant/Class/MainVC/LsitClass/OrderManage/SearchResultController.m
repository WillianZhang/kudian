//
//  SearchResultController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/11.
//  Copyright © 2018年 william. All rights reserved.
//  查询结果列表

#import "SearchResultController.h"
#import "OrderDetailController.h"

@interface SearchResultController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic, strong) UITableView *goodsListTableView;

@end

@implementation SearchResultController
static NSString *orderIdenfuer = @"cellOrder";

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = Color(240, 240, 240);
    self.title = @"搜索结果";
    [self creatUI];
}

-(void)creatUI{
    self.goodsListTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT) style:UITableViewStylePlain];
    //_memberListTableView.separatorColor = [UIColor blackColor];
    _goodsListTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _goodsListTableView.delegate = self;
    _goodsListTableView.dataSource = self;
    _goodsListTableView.rowHeight = k_withBasedIphone6(76);
    [_goodsListTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:orderIdenfuer];
    
    [self.view addSubview:_goodsListTableView];
}


//UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 20;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:orderIdenfuer];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    UILabel *memberID = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(10), k_withBasedIphone6(180), k_withBasedIphone6(20)) andText:@"订单编号 1009992292" andTextColor:Color(51, 51, 51) andFontSize:14 andAlignment:NSTextAlignmentLeft];
    
    UILabel *balance = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(30), k_withBasedIphone6(180), k_withBasedIphone6(20)) andText:@"2011.12.23 11.58" andTextColor:Color(51, 51, 51) andFontSize:14 andAlignment:NSTextAlignmentLeft];
    
    UILabel *spend = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(50), k_withBasedIphone6(180), k_withBasedIphone6(20)) andText:@"会员ID:240" andTextColor:Color(51, 51, 51) andFontSize:14 andAlignment:NSTextAlignmentRight];
    
    [cell addSubview:memberID];
    [cell addSubview:balance];
    [cell addSubview:spend];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    OrderDetailController *vc = [[OrderDetailController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    
}
//分区 header的高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    
    return k_withBasedIphone6(50);
}

// 分区 header的视图
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    UIView *aView = [[UIView alloc] init];
    aView.backgroundColor = Color(240, 240, 240);
    
    UIView *backView = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(0), k_withBasedIphone6(275), k_withBasedIphone6(50)) andBackColor:Color(94, 202, 214)];
    [aView addSubview:backView];
    
    
    UIButton *addMember = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(276), k_withBasedIphone6(0), k_withBasedIphone6(98), k_withBasedIphone6(50)) andType:0 andTitle:@"" andTitleFontSize:0.0 andImageName:@"addMember" andTarget:self andSelector:@selector(addMember) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [aView addSubview:addMember];
    
    
    return aView;
}

#pragma mark -- 按钮点击方法

-(void)addMember{
    

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
