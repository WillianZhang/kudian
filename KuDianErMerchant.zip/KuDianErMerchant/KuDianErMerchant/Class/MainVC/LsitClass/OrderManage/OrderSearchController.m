//
//  OrderSearchController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/11.
//  Copyright © 2018年 william. All rights reserved.
//  搜索订单

#import "OrderSearchController.h"

@interface OrderSearchController ()

@property(nonatomic, strong) UITextField *orderTextField;

@end

@implementation OrderSearchController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = Color(240, 240, 240);
    self.title = @"搜索订单";
    [self creatUI];
}

-(void)creatUI{
    
    UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(30), k_withBasedIphone6(40), k_withBasedIphone6(60), k_withBasedIphone6(20)) andText:@"订单号" andTextColor:Color(50, 50, 50) andFontSize:14.0 andAlignment:NSTextAlignmentCenter];
    
    self.orderTextField = [[UITextField alloc]initWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(40), k_withBasedIphone6(255), k_withBasedIphone6(20))];
    _orderTextField.font = [UIFont systemFontOfSize:14.0];
    _orderTextField.textAlignment = NSTextAlignmentCenter;
    _orderTextField.placeholder = @"请输入订单号或手机号进行搜索";
    
    UIView *line = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(30), k_withBasedIphone6(65), k_withBasedIphone6(315), k_withBasedIphone6(2)) andBackColor:Color(200, 200, 200)];
    
    [self.view addSubview:label];
    [self.view addSubview:_orderTextField];
    [self.view addSubview:line];
    
    
    UIButton *button = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(180), k_withBasedIphone6(175), k_withBasedIphone6(30)) andType:UIButtonTypeCustom andBackColor:Color(94, 202, 214) andTitle:@"下一步" andTitleFontSize:14.0 andTitleColor:Color(255, 255, 255) andTarget:self andSelector:@selector(pushToOrderDetail) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    
    [self.view addSubview:button];
    
    
}

//
-(void)pushToOrderDetail{
    
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end
