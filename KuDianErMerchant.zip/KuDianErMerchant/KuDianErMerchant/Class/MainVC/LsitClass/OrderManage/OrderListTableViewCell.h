//
//  OrderListTableViewCell.h
//  KuDianErMerchant
//
//  Created by william on 2018/7/19.
//  Copyright © 2018年 william. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OrderListModel.h"

@interface OrderListTableViewCell : UITableViewCell

@property(nonatomic , strong) UILabel *memberID;
@property(nonatomic , strong) UILabel *balance;
@property(nonatomic , strong) UILabel *spend;
@property(nonatomic , strong) UILabel *lab1;
@property(nonatomic , strong) UILabel *lab2;
@property(nonatomic , strong) UILabel *lab3;

@property(nonatomic , strong) OrderListModel *ListModel;

@end
