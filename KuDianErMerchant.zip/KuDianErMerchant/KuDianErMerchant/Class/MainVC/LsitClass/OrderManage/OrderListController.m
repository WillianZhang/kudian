//
//  OrderListController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//  订单管理

#import "OrderListController.h"
#import "OrderDetailController.h"
#import "OrderSearchController.h"
#import "OrderListModel.h"
#import "OrderListTableViewCell.h"

#import <WebKit/WebKit.h>
#import "DFYSVP.h"

@interface OrderListController ()<WKNavigationDelegate,WKUIDelegate,WKScriptMessageHandler>
//@interface OrderListController ()<UITableViewDelegate,UITableViewDataSource>
//@property(nonatomic, strong) UITableView *goodsListTableView;
//@property(nonatomic ,strong) NSMutableArray * itemsArray;
//@property(nonatomic ,strong) NSMutableArray * itemsOrder_id;
//@property (nonatomic, strong) NSString *page;
@property (nonatomic ,strong) WKWebView *webView;
@property (nonatomic ,strong) WKWebViewConfiguration *configuration;

@end

@implementation OrderListController
static NSString *orderIdenfuer = @"cellOrder";


-(void)viewWillAppear:(BOOL)animated{
    //这是删除所有缓存和cookie的
    NSSet *websiteDataTypes = [WKWebsiteDataStore allWebsiteDataTypes];
    //// Date from
    NSDate *dateFrom = [NSDate dateWithTimeIntervalSince1970:0];
    //// Execute
    [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:websiteDataTypes modifiedSince:dateFrom completionHandler:^{
        // Done
        
    }];
}

- (void)viewDidLoad{
    [super viewDidLoad];
    self.title = @"订单列表";
    //清除返回按钮上文字
    //    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:nil action:nil];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];//改变返回按钮颜色
    self.navigationController.navigationBarHidden = NO;//是否隐藏导航
    self.navigationController.navigationBar.barTintColor = Color(7, 196, 190);//导航栏颜色
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName :  [UIColor whiteColor]};//导航栏标题颜色
    self.view.backgroundColor = Color(240, 240, 240);
    
    [self creatWkWebView];

}


-(void)creatWkWebView{
    DFYSVPLoading(@"请稍等...", NO);
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *tokenStr = [userDefault objectForKey:@"Token"];
    NSString *deviceUUID = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    
    NSString *newStr = [NSString stringWithFormat:@"/sites/m/index.php?m=neworder&c=index&a=order_list&typeTo=ios&client=iPhone&code=6015&version=1.6&udid=%@&token=%@",deviceUUID,tokenStr];
    NSString *string = [cckdURL stringByAppendingString:newStr];
    
    //    NSString *string = @"http://ecjia.cckdtj.com";
    
    self.configuration = [[WKWebViewConfiguration alloc] init];
    [_configuration.userContentController addScriptMessageHandler:self name:@"scan"];
    
    self.webView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H-64) configuration:_configuration];
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:string]]];
    self.webView.navigationDelegate = self;
    self.webView.UIDelegate = self;
    //开了支持滑动返回
    self.webView.allowsBackForwardNavigationGestures = YES;
    [self.view addSubview:self.webView];
    
    
    //h5页面加载代理方法貌似不稳定 设置延时。消除提示框
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(20.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [DFYSVP dismiss];
    });
    
}



- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
    //网页导航加载完毕
    [DFYSVP dismiss];
}

- (void)webView:(WKWebView *)webView didFailNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {

   [DFYSVP dismiss];
    [self showAlertWithTitle:@"温馨提示" andMessage:@"数据加载失败，请检查网络" andActionTitle:@"重试" andactionBlock:^{
        
        [self creatWkWebView];
        
    } andActionCancelTitle:@"取消" andActionCancelBlock:nil andBool:YES];

}


- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message{
    
    if ([message.name isEqualToString:@"scan"]) {
        //调用原生扫码
        [[NSNotificationCenter defaultCenter] postNotificationName:@"changeRootVC" object:self];//通知，修改MAIN成跟视图
    }
}
#pragma mark WKUIDelegate
//在JS端调用alert函数时，会触发此代理方法。
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:message?:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:([UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler();
    }])];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL))completionHandler{
    //    DLOG(@"msg = %@ frmae = %@",message,frame);
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:message?:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:([UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(NO);
    }])];
    [alertController addAction:([UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(YES);
    }])];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * _Nullable))completionHandler{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:prompt message:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.text = defaultText;
    }];
    [alertController addAction:([UIAlertAction actionWithTitle:@"完成" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(alertController.textFields[0].text?:@"");
    }])];
    [self presentViewController:alertController animated:YES completion:nil];
}

-(WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures
{
    if (!navigationAction.targetFrame.isMainFrame) {
        [webView loadRequest:navigationAction.request];
    }
    return nil;
}


-(void)dealloc{
    say(@"注册页面释放了吗？");
    
}

//退出页面释放内存
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    ///关闭web页时会释放内存
    [self.configuration.userContentController removeScriptMessageHandlerForName:@"scan"];
    self.webView.navigationDelegate = nil;
    self.webView.UIDelegate = nil;
}


//提示框小装 show = yes 有取消按钮。=no只有确定一个按钮
-(void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message andActionTitle:(NSString *)actionTitle andactionBlock:(void(^)(void))ActionBlock andActionCancelTitle:(NSString *)actionCancelTitle andActionCancelBlock:(void(^)(void))ActionCancelBlock andBool:(BOOL)show {
    
    if (show) {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:actionCancelTitle style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionCancelBlock) {
                ActionCancelBlock();
            }
        }];
        [alert addAction:actionCancel];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }else{
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}



/*
  //原生代码实现
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = Color(240, 240, 240);
    self.title = @"订单列表";

    self.goodsListTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self LoadNewData];
    }];
   [self.goodsListTableView.mj_header beginRefreshing];
    
 
    self.goodsListTableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self LoadMoreData];
    }];
   

}

static int goodPage = 1;
-(void)LoadMoreData{
    
    [self.goodsListTableView.mj_footer beginRefreshing];
    goodPage++;
    self.page = [NSString stringWithFormat:@"%d",goodPage];
    [self parsing:_page];
}

-(void)LoadNewData{
    [_itemsArray removeAllObjects];
    [self parsing:@"1"];
}

-(void)parsing:(NSString *)page{
    NSString *URLString = @"http://ecjia.cckdtj.com/sites/api/?url=admin/orders/list";
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *tokenStr = [userDefault objectForKey:@"Token"];
    NSLog(@"token改变%@",tokenStr);
    NSDictionary *parameters = @{
                                 
//
                                 @"token" : tokenStr,
                                 @"pagination":@{
                                         @"count" : @"7",
                                         @"page"  : page
                                         },
                                 @"type" : @"",
                                 @"keywords" : @"",
                                 
                                 
                                 };
    
    [[MyHttpRequest shardWebUtil] postNetworkRequestURLString:URLString parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
        
        LLog(@"OrderListController.m %@",responseObject);
    
        
        NSArray *array = responseObject[@"data"];
        
        for (NSDictionary *dic in array) {
            OrderListModel *model = [OrderListModel new];
            [model setValuesForKeysWithDictionary:dic];
//                        NSLog(@"%@",model);
            
            [self.itemsArray addObject:model];
            [self.itemsOrder_id addObject:model.order_id];
//            NSLog(@"OrderListController.m %@",self->_itemsArray);
            
        }
        
       [self.goodsListTableView reloadData];
        [self.goodsListTableView.mj_header endRefreshing];
        [self.goodsListTableView.mj_footer endRefreshing];
    } successZero:^(id responseObject) {
        
        //        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        //         NSLog(@"bbb %@",responseObject);
        
        //        if ([alterStr isEqualToString:@"Invalid session"]) {
        //
        //            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"登陆过期，请重新登录" preferredStyle:(UIAlertControllerStyleAlert)];
        //            UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
        //
        //                LoginViewController *vc = [[LoginViewController alloc]init];
        //                [self.navigationController pushViewController:vc animated:YES];
        //            }];
        //            [alert addAction:action];
        //            [self presentViewController:alert animated:YES completion:nil];
        //
        //        }else{
        //
        //            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:alterStr preferredStyle:(UIAlertControllerStyleAlert)];
        //            UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:(UIAlertActionStyleDefault) handler:nil];
        //            [alert addAction:action];
        //            [self presentViewController:alert animated:YES completion:nil];
        //        }
    } fail:^(NSError *error) {
        
    }];
}


#pragma mark - UITableViewDataSource and UITableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _itemsArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    OrderListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:orderIdenfuer];
  
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    OrderListModel *model  = _itemsArray[indexPath.row];
    cell.ListModel = model;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"点击cell");
    
    OrderDetailController *vc = [[OrderDetailController alloc]init];
    
    vc.order_idString = self.itemsOrder_id[indexPath.row];
    //NSString *test = self.itemsOrder_id[indexPath.row];
   
    
    [self.navigationController pushViewController:vc animated:YES];
  
}
//分区 header的高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    
    return k_withBasedIphone6(70);
}

// 分区 header的视图
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    UIView *aView = [[UIView alloc] init];
    aView.backgroundColor = Color(240, 240, 240);
    
    UILabel *count = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(3), 0, k_withBasedIphone6(124), k_withBasedIphone6(20)) andText:@"总订单  15800" andTextColor:Color(150, 150, 150) andFontSize:13.0 andAlignment:NSTextAlignmentCenter];
    [aView addSubview:count];
    UILabel *countOnSell = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(127), 0, k_withBasedIphone6(124), k_withBasedIphone6(20)) andText:@"今日订单  150" andTextColor:Color(150, 150, 150) andFontSize:13.0 andAlignment:NSTextAlignmentCenter];
    [aView addSubview:countOnSell];
    UILabel *countUnSell = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(251), 0, k_withBasedIphone6(124), k_withBasedIphone6(20)) andText:@"本月订单  15" andTextColor:Color(150, 150, 150) andFontSize:13.0 andAlignment:NSTextAlignmentCenter];
    [aView addSubview:countUnSell];
    
    UIView *backView = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(20), k_withBasedIphone6(275), k_withBasedIphone6(50)) andBackColor:Color(94, 202, 214)];
    [aView addSubview:backView];

    
    UIButton *selectBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(276), k_withBasedIphone6(20), k_withBasedIphone6(98), k_withBasedIphone6(50)) andType:UIButtonTypeCustom andBackColor:Color(218, 177, 121) andTitle:@"订单查询" andTitleFontSize:14.0 andTitleColor:[UIColor whiteColor] andTarget:self andSelector:@selector(orderSearch) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [aView addSubview:selectBtn];
    

    return aView;
}





#pragma mark - 按钮点击方法

//订单查询
-(void)orderSearch{
   
    OrderSearchController *vc = [[OrderSearchController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}



















//lazy

-(UITableView *)goodsListTableView{
    
    if (!_goodsListTableView) {
        self.goodsListTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT) style:UITableViewStylePlain];
        //_memberListTableView.separatorColor = [UIColor blackColor];
        _goodsListTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _goodsListTableView.delegate = self;
        _goodsListTableView.dataSource = self;
        _goodsListTableView.rowHeight = k_withBasedIphone6(76);
        [_goodsListTableView registerClass:[OrderListTableViewCell class] forCellReuseIdentifier:orderIdenfuer];
        
        [self.view addSubview:_goodsListTableView];
    }
    return _goodsListTableView;
}






-(NSMutableArray *)itemsArray{
    if (!_itemsArray) {
        _itemsArray = [NSMutableArray arrayWithCapacity:13];
    }
    return _itemsArray;
}

-(NSMutableArray *)itemsOrder_id{
    if (!_itemsOrder_id) {
        _itemsOrder_id = [NSMutableArray arrayWithCapacity:13];
    }
    return _itemsOrder_id;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
*/

@end
