//
//  OrderListTableViewCell.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/19.
//  Copyright © 2018年 william. All rights reserved.
//

#import "OrderListTableViewCell.h"

@implementation OrderListTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.memberID = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(10), k_withBasedIphone6(180), k_withBasedIphone6(20)) andText:@"" andTextColor:Color(150, 150, 150) andFontSize:14.0 andAlignment:NSTextAlignmentLeft];
        
        self.balance = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(30), k_withBasedIphone6(180), k_withBasedIphone6(20)) andText:@"" andTextColor:Color(150, 150, 150)andFontSize:13.0 andAlignment:NSTextAlignmentLeft];
        
        self.spend = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(50), k_withBasedIphone6(180), k_withBasedIphone6(20)) andText:@"会员ID:240" andTextColor:Color(150, 150, 150) andFontSize:13.0 andAlignment:NSTextAlignmentLeft];
        
        self.lab1 = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(200), k_withBasedIphone6(20), k_withBasedIphone6(90), k_withBasedIphone6(20)) andText:@"$45.7" andTextColor:Color(150, 150, 150) andFontSize:13.0 andAlignment:NSTextAlignmentCenter];
        self.lab2 = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(200), k_withBasedIphone6(40), k_withBasedIphone6(90), k_withBasedIphone6(20)) andText:@"($45.7)" andTextColor:Color(150, 150, 150) andFontSize:13.0 andAlignment:NSTextAlignmentCenter];
        
        
        self.lab3 = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(290), k_withBasedIphone6(30), k_withBasedIphone6(60), k_withBasedIphone6(20)) andText:@"已结算" andTextColor:Color(150, 150, 150) andFontSize:13.0 andAlignment:NSTextAlignmentCenter];
        
        
        
        [self addSubview:_memberID];
        [self addSubview:_balance];
        [self addSubview:_spend];
        [self addSubview:_lab1];
        [self addSubview:_lab2];
        [self addSubview:_lab3];
        
    }
    return self;
}



-(void)setListModel:(OrderListModel *)ListModel{
    
    self.memberID.text = ListModel.order_sn;
    self.balance.text = ListModel.create_time;
    
}



- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
