//
//  SellCardController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//  售卖储值卡

#import "SellCardController.h"

@interface SellCardController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic , strong) UIButton *sellBtn;

@end

@implementation SellCardController
static NSString *cardIdentufuer = @"cellcard";

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"售卖储值卡与折扣卡";
    self.view.backgroundColor = Color(246, 246, 246);
    [self creatUI];
}

-(void)creatUI{
    
    UITableView *cardTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT) style:UITableViewStylePlain];
    cardTableView.separatorStyle = UITableViewCellSelectionStyleNone;
    cardTableView.delegate = self;
    cardTableView.dataSource = self;
    cardTableView.rowHeight = k_withBasedIphone6(86);
    [cardTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:cardIdentufuer];
    
    [self.view addSubview:cardTableView];
    
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, k_withBasedIphone6(100))];
//    footerView.backgroundColor = [UIColor redColor];
    cardTableView.tableFooterView = footerView;
    UIButton *button = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(50), k_withBasedIphone6(50), k_withBasedIphone6(275), k_withBasedIphone6(40)) andType:UIButtonTypeCustom andBackColor:Color(94, 202, 214) andTitle:@"确认售卖" andTitleFontSize:15.0 andTitleColor:Color(255, 255, 255) andTarget:self andSelector:@selector(pushToQR_code) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [footerView addSubview:button];
}

#pragma mark_____tableViewDataSource

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cardIdentufuer];
    cell.backgroundColor = Color(245, 245, 245);
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    UIView *backView = [MyUIClass makeUIViewWithFrame:CGRectMake(0, 0, k_withBasedIphone6(375), k_withBasedIphone6(76)) andBackColor:Color(255, 255, 255)];
    [cell addSubview:backView];
    
    self.sellBtn = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(30), k_withBasedIphone6(30), k_withBasedIphone6(15), k_withBasedIphone6(15)) andType:UIButtonTypeCustom andImageName:@"未选中" andTarget:self andSelector:@selector(changestaue) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [backView addSubview:_sellBtn];
    
    UILabel *tit = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(70), k_withBasedIphone6(15), k_withBasedIphone6(100), k_withBasedIphone6(25)) andText:@"储值卡" andTextColor:Color(51, 51, 51) andFontSize:16 andAlignment:NSTextAlignmentLeft];
    [backView addSubview:tit];
    
    UILabel *tittle = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(70), k_withBasedIphone6(40), k_withBasedIphone6(280), k_withBasedIphone6(20)) andText:@"面额200元" andTextColor:Color(200, 200, 200) andFontSize:14 andAlignment:NSTextAlignmentLeft];
    [backView addSubview:tittle];
    
    UILabel *descripe = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(160), k_withBasedIphone6(25), k_withBasedIphone6(115), k_withBasedIphone6(25)) andText:@"售卖金额198元" andTextColor:Color(200, 200, 200) andFontSize:14 andAlignment:NSTextAlignmentLeft];
    [backView addSubview:descripe];
  
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return @"售卖储值卡";
    }else{
        return @"售卖折扣卡";
    }
}



- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return k_withBasedIphone6(35);
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *back = [[UIView alloc]init];
    back.backgroundColor = Color(246, 246, 246);
    UILabel *tit = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(5), k_withBasedIphone6(100), k_withBasedIphone6(25)) andText:@"售卖储值卡" andTextColor:Color(51, 51, 51) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
    [back addSubview:tit];
    return back;
}


int j = 1;
-(void)changestaue{
    
    if (j == 1) {
        [self.sellBtn setImage:[UIImage imageNamed:@"选中"] forState:UIControlStateNormal];
        j = 2;
    }else{
        [self.sellBtn setImage:[UIImage imageNamed:@"未选中"] forState:UIControlStateNormal];
        j = 1;
    }
    
}


-(void)pushToQR_code{
    NSLog(@"二维码");
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
