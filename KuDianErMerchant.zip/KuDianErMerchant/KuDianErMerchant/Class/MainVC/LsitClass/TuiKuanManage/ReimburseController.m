//
//  ReimburseController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//  退款管理

#import "ReimburseController.h"

@interface ReimburseController ()

@property(nonatomic, strong) UITextField *moneyField;

@end

@implementation ReimburseController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = Color(255, 255, 255);
    self.title = @"退款";
    
    [self creatUI];
}

-(void)creatUI{
    
    UILabel *lab = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(60), k_withBasedIphone6(60), k_withBasedIphone6(60), k_withBasedIphone6(30)) andText:@"退款金额" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentCenter];
    [self.view addSubview:lab];
    
    self.moneyField = [[UITextField alloc]initWithFrame:CGRectMake(k_withBasedIphone6(150), k_withBasedIphone6(60), k_withBasedIphone6(140), k_withBasedIphone6(28))];
    _moneyField.font = [UIFont systemFontOfSize:13];
    _moneyField.placeholder = @"请输入退款金额";
    [self.view addSubview:_moneyField];
    
    UIView * line = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(150), k_withBasedIphone6(88), k_withBasedIphone6(140), k_withBasedIphone6(2)) andBackColor:Color(91, 202, 213)];
    [self.view addSubview:line];
    
    UILabel *lab1 = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(295), k_withBasedIphone6(60), k_withBasedIphone6(20), k_withBasedIphone6(30)) andText:@"元" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentCenter];
    [self.view addSubview:lab1];
    
    UIButton *btn = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(120), k_withBasedIphone6(120), k_withBasedIphone6(135), k_withBasedIphone6(30)) andType:1 andTitle:@"确认退款" andTitleFontSize:14.0 andImageName:nil andTarget:nil andSelector:@selector(selector) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.layer.masksToBounds = YES;
    btn.layer.cornerRadius = 4;
    [btn setBackgroundColor:Color(91, 202, 213)];
    [self.view addSubview:btn];
    
}

-(void)selector{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
