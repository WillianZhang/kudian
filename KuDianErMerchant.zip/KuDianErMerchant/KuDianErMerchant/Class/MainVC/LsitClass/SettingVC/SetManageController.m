//
//  SetManageController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//  设置

#import "SetManageController.h"

@interface SetManageController ()

@property(nonatomic, strong) UIButton *headBtn;
@property(nonatomic, strong) UIButton *selBtn;

@end

@implementation SetManageController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = Color(255, 255, 255);
    self.title = @"设置使用功能";
    
    [self creatUI];
}

-(void)creatUI{
    
    UIView *view = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(60), k_withBasedIphone6(50), k_withBasedIphone6(255), k_withBasedIphone6(120)) andBackColor:Color(255, 255, 255)];
    view.layer.borderWidth = 2.0;
    view.layer.borderColor = Color(91, 202, 213).CGColor;
    view.layer.masksToBounds = YES;
    view.layer.cornerRadius = 10;
    [self.view addSubview:view];
    
    self.headBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.headBtn setImage:[UIImage imageNamed:@"未选中"] forState:UIControlStateNormal];
//    _headBtn.backgroundColor = [UIColor yellowColor];
    [_headBtn addTarget:self action:@selector(changestaue1) forControlEvents:UIControlEventTouchUpInside];
    _headBtn.frame = CGRectMake(k_withBasedIphone6(70), k_withBasedIphone6(30), k_withBasedIphone6(15), k_withBasedIphone6(15));
    [view addSubview:_headBtn];
    
    UILabel *member = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(95), k_withBasedIphone6(20), k_withBasedIphone6(135), k_withBasedIphone6(35)) andText:@"会员系统" andTextColor:Color(91, 202, 213) andFontSize:17.0 andAlignment:NSTextAlignmentLeft];
    [view addSubview:member];
    
    NSArray *array = @[@"储值卡管理",@"会员管理"];
    for (int i = 0; i < 2; i++) {
        UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(80),k_withBasedIphone6(55)+ k_withBasedIphone6(25)*i, k_withBasedIphone6(85), k_withBasedIphone6(25)) andText:array[i] andTextColor:Color(110, 110, 110) andFontSize:14.0 andAlignment:NSTextAlignmentLeft];
        [view addSubview:label];
    }
    
    
    UIView *viewL = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(60), k_withBasedIphone6(200), k_withBasedIphone6(255), k_withBasedIphone6(120)) andBackColor:Color(255, 255, 255)];
    viewL.layer.borderWidth = 2.0;
    viewL.layer.borderColor = Color(91, 202, 213).CGColor;
    viewL.layer.masksToBounds = YES;
    viewL.layer.cornerRadius = 10;
    [self.view addSubview:viewL];
    
    self.selBtn = [UIButton buttonWithType:UIButtonTypeCustom];
//    _selBtn.backgroundColor = [UIColor yellowColor];
    [self.selBtn setImage:[UIImage imageNamed:@"未选中"] forState:UIControlStateNormal];
    [_selBtn addTarget:self action:@selector(changestaue2) forControlEvents:UIControlEventTouchUpInside];
    _selBtn.frame = CGRectMake(k_withBasedIphone6(70), k_withBasedIphone6(30), k_withBasedIphone6(15), k_withBasedIphone6(15));
    [viewL addSubview:_selBtn];
    
    UILabel *order = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(95), k_withBasedIphone6(20), k_withBasedIphone6(135), k_withBasedIphone6(35)) andText:@"订单系统" andTextColor:Color(91, 202, 213) andFontSize:17.0 andAlignment:NSTextAlignmentLeft];
    [viewL addSubview:order];
    
    NSArray *arr = @[@"商品管理",@"采购管理",@"订单管理",@"库存管理"];
    for (int i = 0; i < 4; i++) {
        UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(50)+i%2 * k_withBasedIphone6(80),k_withBasedIphone6(55)+ i/2*k_withBasedIphone6(25), k_withBasedIphone6(70), k_withBasedIphone6(25)) andText:arr[i] andTextColor:Color(110, 110, 110) andFontSize:14.0 andAlignment:NSTextAlignmentLeft];
        [viewL addSubview:label];
    }
    
    
    UIButton *sureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    sureBtn.frame = CGRectMake(k_withBasedIphone6(50), k_withBasedIphone6(370), k_withBasedIphone6(275), k_withBasedIphone6(45));
    sureBtn.backgroundColor = Color(91, 202, 213);
    [sureBtn setTitle:@"确定" forState:UIControlStateNormal];
    [sureBtn setTitleColor:Color(255, 255, 255) forState:UIControlStateNormal];
    
    [self.view addSubview:sureBtn];
    
}



-(void)changestaue1{
    [self.headBtn setImage:[UIImage imageNamed:@"选中"] forState:UIControlStateNormal];
    [self.selBtn setImage:[UIImage imageNamed:@"未选中"] forState:UIControlStateNormal];
}

-(void)changestaue2{
    [self.selBtn setImage:[UIImage imageNamed:@"选中"] forState:UIControlStateNormal];
    [self.headBtn setImage:[UIImage imageNamed:@"未选中"] forState:UIControlStateNormal];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
