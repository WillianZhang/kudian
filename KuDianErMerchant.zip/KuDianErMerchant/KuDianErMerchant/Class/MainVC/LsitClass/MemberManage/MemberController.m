//
//  MemberController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//  会员管理

#import "MemberController.h"
#import "AddMemberController.h"
#import "MemberDetailController.h"

@interface MemberController ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>
@property(nonatomic, strong) UITableView *memberListTableView;
@end

@implementation MemberController
static NSString *idenfuer = @"cellReu";

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = Color(240, 240, 240);
    self.title = @"会员列表";
    [self creatUI];
}

-(void)creatUI{
    self.memberListTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT) style:UITableViewStylePlain];
        //_memberListTableView.separatorColor = [UIColor blackColor];
        _memberListTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _memberListTableView.delegate = self;
    _memberListTableView.dataSource = self;
    _memberListTableView.rowHeight = k_withBasedIphone6(50);
    [_memberListTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:idenfuer];
    
    [self.view addSubview:_memberListTableView];
}


//UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 20;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:idenfuer];
    
   [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    UILabel *memberID = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(35), k_withBasedIphone6(15), k_withBasedIphone6(90), k_withBasedIphone6(20)) andText:@"13633231473" andTextColor:Color(51, 51, 51) andFontSize:14 andAlignment:NSTextAlignmentLeft];
    
    UILabel *balance = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(150), k_withBasedIphone6(15), k_withBasedIphone6(60), k_withBasedIphone6(20)) andText:@"¥100.00" andTextColor:Color(51, 51, 51) andFontSize:14 andAlignment:NSTextAlignmentLeft];
    
    UILabel *spend = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(240), k_withBasedIphone6(15), k_withBasedIphone6(60), k_withBasedIphone6(20)) andText:@"¥240.00" andTextColor:Color(51, 51, 51) andFontSize:14 andAlignment:NSTextAlignmentRight];
    
    [cell addSubview:memberID];
    [cell addSubview:balance];
    [cell addSubview:spend];

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    say(@"点击cell");
    MemberDetailController *vc = [[MemberDetailController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}
//分区 header的高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
   
    return k_withBasedIphone6(115);
}

// 分区 header的视图
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
   
    UIView *aView = [[UIView alloc] init];
    aView.backgroundColor = Color(240, 240, 240);
    
    UILabel *count = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), 0, k_withBasedIphone6(130), k_withBasedIphone6(20)) andText:@"总会员数量  15800" andTextColor:Color(150, 150, 150) andFontSize:13.0 andAlignment:NSTextAlignmentLeft];
    [aView addSubview:count];
    
    UIView *bgView = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(20), k_withBasedIphone6(275), k_withBasedIphone6(43)) andBackColor:Color(199, 187, 171)];
    [aView addSubview:bgView];
    

    UIView *leftView = [[UIView alloc]init];                  //textFile左视图
    UIButton *search = [UIButton buttonWithType:UIButtonTypeCustom];          //左视图上图片
    UITextField *textFiled = [[UITextField alloc]init];
    
    textFiled.frame = CGRectMake(k_withBasedIphone6(15), k_withBasedIphone6(6), k_withBasedIphone6(245), k_withBasedIphone6(30));
    
    CGRect leftViewFrame = CGRectMake(0, 0, k_withBasedIphone6(31), k_withBasedIphone6(30));
    CGRect imageViewFrame = CGRectMake(0, 0, k_withBasedIphone6(31), k_withBasedIphone6(30));
    leftView.frame = leftViewFrame;
    textFiled.leftView = leftView;
    textFiled.leftViewMode = UITextFieldViewModeAlways;
    textFiled.placeholder = @"请输入会员手机号进行搜索";
    textFiled.font = [UIFont systemFontOfSize:14];
    [leftView addSubview:search];
    search.frame = imageViewFrame;
    textFiled.layer.masksToBounds = YES;
    textFiled.layer.cornerRadius = 15;
    textFiled.clearButtonMode = UITextFieldViewModeAlways;
    [search setBackgroundImage:[UIImage imageNamed:@"搜索"] forState:UIControlStateNormal];
    textFiled.keyboardType = UIKeyboardTypeDefault;
    textFiled.delegate = self;
    textFiled.returnKeyType = UIReturnKeySearch;
    textFiled.backgroundColor = [UIColor whiteColor];
    [bgView addSubview:textFiled];
    
    
    
    UIButton *addMember = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(277), k_withBasedIphone6(20), k_withBasedIphone6(98), k_withBasedIphone6(43)) andType:0 andTitle:@"" andTitleFontSize:0.0 andImageName:@"addMember" andTarget:self andSelector:@selector(addMember) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [aView addSubview:addMember];
    
    UIView *backView = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(65), Screen_W, k_withBasedIphone6(50)) andBackColor:Color(94, 202, 214)];
    [aView addSubview:backView];
    
    
    return aView;
}

#pragma mark -- 按钮点击方法

-(void)addMember{
    AddMemberController *vc = [[AddMemberController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

//点击search的操作
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    say(@"这里就是你要做的操作");
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
