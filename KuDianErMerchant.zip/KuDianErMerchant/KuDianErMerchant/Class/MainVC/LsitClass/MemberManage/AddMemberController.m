//
//  AddMemberController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/9.
//  Copyright © 2018年 william. All rights reserved.
//

#import "AddMemberController.h"

@interface AddMemberController ()
{
    int _time;
    NSTimer *_timer;
}

@property(nonatomic , strong) NSArray *numArray;
@property(nonatomic , strong) NSArray *countryArray;
@property(nonatomic , strong) UIPickerView *pickerView;
@property(nonatomic,strong) UIButton *btnClose;
@property(nonatomic,strong) UILabel *label;
@property(nonatomic,strong) UILabel *labDetail;
@end

@implementation AddMemberController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"添加会员";
    self.view.backgroundColor = Color(255, 255, 255);
    _time = 60;
    
    [self creatUI];
}

-(void)creatUI{
//    self.label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(40), k_withBasedIphone6(55), k_withBasedIphone6(30)) andText:@"+86" andTextColor:Color(50, 50, 50) andFontSize:17.0 andAlignment:NSTextAlignmentLeft];
//    _label.backgroundColor = [UIColor yellowColor];
//    [self.view addSubview:_label];
//
//    self.labDetail = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(40), k_withBasedIphone6(180), k_withBasedIphone6(30)) andText:@"中国" andTextColor:Color(50, 50, 50) andFontSize:17.0 andAlignment:NSTextAlignmentLeft];
//    _labDetail.backgroundColor = [UIColor yellowColor];
//    [self.view addSubview:_labDetail];
    
    NSArray *arr = @[@"会员姓名",@"会员手机号",@"验证码"];
    NSArray *array = @[@"",@"填写手机号",@"填写手机验证码"];
    
    for (int i = 0; i < 3; i++) {
        
        
        
        UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(40)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(80), k_withBasedIphone6(30)) andText:@"" andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
        label.text = arr[i];
        label.tag = i;
        label.backgroundColor = [UIColor yellowColor];
        [self.view addSubview:label];
        
        UITextField *filed = [[UITextField alloc]initWithFrame:CGRectMake(k_withBasedIphone6(110), k_withBasedIphone6(40)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(160), k_withBasedIphone6(30))];
        filed.placeholder  = array[i];
        filed.tag = 10+i;
        filed.backgroundColor = [UIColor yellowColor];
        [self.view addSubview:filed];
        
        UIView *line = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(78)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(335), k_withBasedIphone6(2)) andBackColor:Color(222, 222, 222)];
        [self.view addSubview:line];
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(k_withBasedIphone6(270), k_withBasedIphone6(40)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(85), k_withBasedIphone6(30));
        btn.tag = 20+i;
        [self.view addSubview:btn];
        
        if (btn.tag == 21){
            btn.backgroundColor = Color(205, 190, 150);
            btn.titleLabel.font = [UIFont systemFontOfSize:14.0];
            [btn setTitle:@"获取验证码" forState:(UIControlStateNormal)];
            [btn addTarget:self action:@selector(getMobile) forControlEvents:UIControlEventTouchUpInside];
        }
            
        
    }
 
        
        
    
    
//    UIButton *loginBtn = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(60), k_withBasedIphone6(230), k_withBasedIphone6(110), k_withBasedIphone6(33)) andType:1 andTitle:@"保存" andTitleFontSize:18.0 andImageName:nil andBackColor:Color(205, 190, 150) andTarget:self andSelector:@selector(pushToMain) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//    [loginBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//    [self.view addSubview:loginBtn];
//    
//    UIButton *loginByPassword = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(205), k_withBasedIphone6(230), k_withBasedIphone6(110), k_withBasedIphone6(33)) andType:1 andTitle:@"继续添加" andTitleFontSize:14.0 andImageName:nil andBackColor:Color(94, 202, 214) andTarget:self andSelector:@selector(passwordLogin) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//    [loginByPassword setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//    [self.view addSubview:loginByPassword];
    

}


- (void)getMobile
{
    say(@"getMobilegetMobile");
    UITextField *textField = (UITextField *)[self.view viewWithTag:1000];
    if ([textField.text isEqualToString:@""])
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请填写正确的手机号" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"知道了" style:(UIAlertActionStyleDefault) handler:nil];
        [alert addAction:action];
        [self presentViewController:alert animated:YES completion:nil];
    }
    else
    {
        if (_time == 60 || _time == 0)
        {
            say(@"开始倒计时");
            
            [self.view endEditing:YES];
            
            
            //开启定时器
            [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(time:) userInfo:nil repeats:YES];
            say(@"成功");
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"发送成功" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *action = [UIAlertAction actionWithTitle:@"知道了" style:(UIAlertActionStyleDefault) handler:nil];
            [alert addAction:action];
            [self presentViewController:alert animated:YES completion:nil];
            
            
        }
    }
    
}

// 获取验证码
- (void)time:(NSTimer *)timer
{
    UIButton *_btnGet = (UIButton *)[self.view viewWithTag:21];
    if (_time == 0) {
   
        [timer invalidate];
        timer = nil;
        //_jiShiLab.text = @"重新获取";
        [_btnGet setTitle:@"重新获取" forState:(UIControlStateNormal)];
        _time = 60;
    }else
    {
   
        [self.view reloadInputViews];
        [_btnGet setTitle:[NSString stringWithFormat:@"%ds",_time] forState:(UIControlStateNormal)];
        //_jiShiLab.text = [NSString stringWithFormat:@"%d秒后重新获取",_time];
        _time -=  1;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
