//
//  MemberDetailController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/9.
//  Copyright © 2018年 william. All rights reserved.
//

#import "MemberDetailController.h"

@interface MemberDetailController ()

@end

@implementation MemberDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"会员信息";
    self.view.backgroundColor = Color(255, 255, 255);
    [self creatUI];
}

-(void)creatUI{
    
    NSArray *arr = @[@"会员ID",@"会员姓名",@"会员昵称",@"会员电话",@"充值金额",@"消费金额",@"物流地址"];
    NSArray *array = @[@"32525245345",@"阿大",@"兜兜风",@"12345678900",@"100元",@"444元",@"内蒙古赛汗塔拉"];
    
    for (int i = 0; i < 7; i++) {
        
        
        
        UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(50), k_withBasedIphone6(40)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(80), k_withBasedIphone6(30)) andText:@"" andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
        label.text = arr[i];

        label.backgroundColor = [UIColor yellowColor];
        [self.view addSubview:label];
        
        UILabel *lab = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(140), k_withBasedIphone6(40)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(185), k_withBasedIphone6(30)) andText:array[i] andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
         lab.backgroundColor = [UIColor yellowColor];
        [self.view addSubview:lab];
        
        UIView *line = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(50), k_withBasedIphone6(78)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(275), k_withBasedIphone6(2)) andBackColor:Color(222, 222, 222)];
        [self.view addSubview:line];
        
    
        
        
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
