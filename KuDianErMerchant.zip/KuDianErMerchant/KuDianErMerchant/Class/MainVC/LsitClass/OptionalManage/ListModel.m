//
//  ListModel.m
//  KuDianErMerchant
//
//  Created by william on 2018/8/20.
//  Copyright © 2018年 william. All rights reserved.
//

#import "ListModel.h"

@implementation ListModel

// 容错处理
- (void)setValue:(id)value forUndefinedKey:(NSString *)key  {
    if([key isEqualToString:@"id"])
        self.NewId = value;
}



-(NSString *)description{
    return [NSString stringWithFormat:@"%@-%@-%@-%@-%@-%@",_NewId,_name,_img,_unformatted_shop_price,_goods_sn,_shop_price];
}

@end
