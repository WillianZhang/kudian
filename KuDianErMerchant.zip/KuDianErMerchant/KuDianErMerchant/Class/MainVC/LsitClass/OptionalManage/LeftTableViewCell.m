//
//  LeftTableViewCell.m
//  KuDianErMerchant
//
//  Created by william on 2018/8/21.
//  Copyright © 2018年 william. All rights reserved.
//

#import "LeftTableViewCell.h"

@implementation LeftTableViewCell


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.titleLabel = [MyUIClass simpleLabelWithFrame:CGRectMake(0, 0, k_withBasedIphone6(85), k_withBasedIphone6(70)) andText:@"" andTextColor:[UIColor blackColor] andFontSize:14.0 andAlignment:NSTextAlignmentCenter];
        self.titleLabel.layer.borderWidth = 1.0;
        self.titleLabel.layer.borderColor = Color(244, 245, 249).CGColor;
        [self addSubview:_titleLabel];
        
    }
    return self;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {

    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
    self.contentView.backgroundColor = selected ? Color(244, 245, 249) : [UIColor clearColor];
    //    self.highlighted = selected;
    self.titleLabel.textColor =  selected ? Color(7, 196, 190) : [UIColor blackColor];
}

@end
