//
//  ClassModel.m
//  KuDianErMerchant
//
//  Created by william on 2018/8/20.
//  Copyright © 2018年 william. All rights reserved.
//

#import "ClassModel.h"

@implementation ClassModel


// 容错处理
- (void)setValue:(id)value forUndefinedKey:(NSString *)key  {
    if([key isEqualToString:@"id"])
        self.NewId = value;
}



-(NSString *)description{
    return [NSString stringWithFormat:@"%@-%@-%@-%@",_NewId,_name,_image,_children];
}

@end
