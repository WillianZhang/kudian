//
//  ClassModel.h
//  KuDianErMerchant
//
//  Created by william on 2018/8/20.
//  Copyright © 2018年 william. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ClassModel : NSObject

@property (nonatomic, copy) NSString *children;
@property (nonatomic,copy) NSString *NewId;
@property (nonatomic, copy) NSString *image;
@property (nonatomic, copy) NSString *name;



@end

//{
//    data =     (
//                {
//                    children =             (
//                    );
//                    id = 96;
//                    image = "";
//                    name = "\U5927\U5206\U7c7b";
//                },
//                {
//                    children =             (
//                    );
//                    id = 97;
//                    image = "";
//                    name = "\U6c34\U679c";
//                },
//                {
//                    children =             (
//                    );
//                    id = 98;
//                    image = "";
//                    name = "\U6587\U5177";
//                }
//                );
//    status =     {
//        succeed = 1;
//    };
//}
