//
//  GoodsTableViewCell.h
//  KuDianErMerchant
//
//  Created by william on 2018/7/12.
//  Copyright © 2018年 william. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ListModel.h"

@interface GoodsTableViewCell : UITableViewCell

@property(nonatomic, strong) UIImageView *goodImageView;
@property(nonatomic, strong) UILabel *goodsNameLabel;

@property(nonatomic, strong) UILabel *priceLabel;
@property(nonatomic, strong) UILabel *countLabel;//数量
@property(nonatomic, strong) UIButton *cutBtn;
@property(nonatomic, strong) UIButton *addBtn;

@property(nonatomic, strong) UIButton *clickBtn;
/**
 选中
 */
@property (nonatomic, copy) void (^ClickRowBlock)(UILabel *countLabel);

@property (nonatomic, copy) void (^ClickBlock)(UIImageView *view);

/**
 加
 */
@property (nonatomic, copy) void (^AddBlock)(UILabel *countLabel);

/**
 减
 */
@property (nonatomic, copy) void (^CutBlock)(UILabel *countLabel);


@property (nonatomic, strong) ListModel *goodsModel;




@end
