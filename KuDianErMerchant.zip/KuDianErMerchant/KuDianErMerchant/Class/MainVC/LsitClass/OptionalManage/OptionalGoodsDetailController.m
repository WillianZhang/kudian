//
//  OptionalGoodsDetailController.m
//  KuDianErMerchant
//
//  Created by william on 2018/9/10.
//  Copyright © 2018年 william. All rights reserved.
//

#import "OptionalGoodsDetailController.h"
#import "DFYSVP.h"
#import "LoginController.h"

@interface OptionalGoodsDetailController ()

@property(nonatomic , strong) NSString *name;
@property(nonatomic , strong) NSString *shop_price;
@property(nonatomic , strong) NSString *goods_desc;
@property(nonatomic , strong) NSDictionary *img;

@end

@implementation OptionalGoodsDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"商品详情";
    self.view.backgroundColor = [UIColor whiteColor];
    
    LLog(@"%@",_detailGoods_id);
    [self parsing:_detailGoods_id];
    
}


-(void)creatUI{
    
    UIScrollView *scroll = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, Screen_W, k_withBasedIphone6(667))];
    scroll.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:scroll];
    
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, Screen_W, k_withBasedIphone6(314))];
    [imageView sd_setImageWithURL:[NSURL URLWithString:_img[@"url"]]];
    [scroll addSubview:imageView];
    
    NSMutableAttributedString *fontAttributeNameStr = [[NSMutableAttributedString alloc]initWithString:_shop_price];
    [fontAttributeNameStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:13] range:NSMakeRange(0, 1)];
    UILabel *price = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(314), k_withBasedIphone6(200), k_withBasedIphone6(50)) andText:@"" andTextColor:Color(160, 30, 30) andFontSize:19.0 andAlignment:NSTextAlignmentLeft];
    price.attributedText = fontAttributeNameStr;
    [scroll addSubview:price];
    
    UILabel *name = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(364), k_withBasedIphone6(200), k_withBasedIphone6(50)) andText:_name andTextColor:Color(30, 30, 30) andFontSize:17.0 andAlignment:NSTextAlignmentLeft];
    [scroll addSubview:name];
    
    
    NSString *string = @"商品的一些简单信息描述，包含规格，产品功能，使用或食用的方法等等～～～～～～";
    UILabel *descripe = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(414), k_withBasedIphone6(335), k_withBasedIphone6(253)) andText:string andTextColor:Color(140, 140, 140) andFontSize:17.0 andAlignment:NSTextAlignmentLeft];
    descripe.backgroundColor = Color(240, 240, 240);
    descripe.numberOfLines = 0;
    [scroll addSubview:descripe];
    
    
}

-(void)parsing:(NSString *)sender{

    //http://ecjia.cckdtj.com/sites/api/?url=admin/goods/detail 

    NSString *string = @"/sites/api/?url=admin/goods/detail";//商品分类接口
    NSString *strUrl = [cckdURL stringByAppendingString:string];
    LLog(@"%@",string);
    NSDictionary *parameters = @{
                                 
                                 @"goods_id" : sender,

                                 };
    [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:strUrl parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
        
        LLog(@"%@",responseObject);
        self.img = responseObject[@"data"][@"img"];
        self.shop_price = responseObject[@"data"][@"shop_price"];
        self.name = responseObject[@"data"][@"name"];
        
        LLog(@"%@-%@-%@",self->_img,self->_shop_price,self->_name);
        
        [self creatUI];
        

        
    } successZero:^(id responseObject) {
 
        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");
            
            __weak typeof(self) weakSelf = self;
            [self showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
        }else{
            
            [self showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
        }
        
    } fail:^(NSError *error) {
        
    
        NSString *alterString = @"数据加载失败，请检查网络！";
        [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }];
}








//提示框小装 show = yes 有取消按钮。=no只有确定一个按钮
-(void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message andActionTitle:(NSString *)actionTitle andactionBlock:(void(^)(void))ActionBlock andActionCancelTitle:(NSString *)actionCancelTitle andActionCancelBlock:(void(^)(void))ActionCancelBlock andBool:(BOOL)show {
    
    if (show) {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:actionCancelTitle style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionCancelBlock) {
                ActionCancelBlock();
            }
        }];
        [alert addAction:actionCancel];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }else{
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}













- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
