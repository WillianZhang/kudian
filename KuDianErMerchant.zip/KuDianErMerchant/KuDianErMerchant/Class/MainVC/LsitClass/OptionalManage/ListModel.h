//
//  ListModel.h
//  KuDianErMerchant
//
//  Created by william on 2018/8/20.
//  Copyright © 2018年 william. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ListModel : NSObject

@property (nonatomic,copy) NSString *NewId;  //id
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSDictionary *img;
@property (nonatomic, copy) NSString *unformatted_shop_price;
@property (nonatomic, copy) NSString *goods_sn;
@property (nonatomic, copy) NSString *shop_price;

@end
//"id": "1669",
//"name": "测试11111121",
//"goods_sn": "81_ECS001669",
//"market_price": 0,
//"unformatted_market_price": "0.00",
//"shop_price": "￥1.00",
//"unformatted_shop_price": "1.00",
//"promote_price": "",
//"unformatted_promote_price": 0,
//"img": {
//    "thumb": "https://ecjia95079.oss-cn-beijing.aliyuncs.com/data/statics/nopic.png",
//    "url": "https://ecjia95079.oss-cn-beijing.aliyuncs.com/data/statics/nopic.png",
//    "small": "https://ecjia95079.oss-cn-beijing.aliyuncs.com/data/statics/nopic.png"
//},
//"properties": [],
//"specification": [],
//"activity_type": "GENERAL_GOODS",
//"object_id": 0,
//"saving_price": 0,
//"formatted_saving_price": ""
