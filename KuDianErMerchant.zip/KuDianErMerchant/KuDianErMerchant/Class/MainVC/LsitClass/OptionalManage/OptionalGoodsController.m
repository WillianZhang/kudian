//
//  OptionalGoodsController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/12.
//  Copyright © 2018年 william. All rights reserved.
//  自选订单

#import "OptionalGoodsController.h"
#import "GoodsTableViewCell.h"
#import "LoginController.h"
#import "ClassModel.h"
#import "ListModel.h"
#import "DFYSVP.h"
#import "SettleAccountsController.h"
#import "LeftTableViewCell.h"
#import "CartModel.h"
#import "PurchaseCarAnimationTool.h"//动画
#import "OptionalGoodsDetailController.h"

@interface OptionalGoodsController ()<UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource>

@property(nonatomic, strong) UITextField *textFiled;
@property(nonatomic, strong) UITableView *tableviewLeft;
@property(nonatomic, strong) UITableView *goodsTableView;
@property(nonatomic, strong) UIView *backCart;//自选购物车背景view

@property (nonatomic, strong) NSMutableArray *selectArray;

@property (nonatomic, strong) UILabel *totalCount;//购物车上小标题

@property (nonatomic, strong) NSMutableArray *classArr;
@property (nonatomic, strong) NSMutableArray *classMutableArr;//右侧列表数据model盛放
@property (nonatomic, strong) NSMutableArray *listArr;//右侧列表数据大数组盛放

@property (nonatomic, strong) NSMutableArray *IDMutableArray;//盛放产品ID
@property (nonatomic, strong) NSMutableArray *REC_IDMutableArray;//盛放产品ID

@property (nonatomic, strong) NSString *keywords;
@property (nonatomic, strong) NSString *category_id;
@property (nonatomic, strong) NSString *page;

@property (nonatomic, strong) NSMutableDictionary *goods_snNnumberDictionary;//盛放产品ID
@property (nonatomic, strong) NSArray *countArr;//盛放修改后产品数量

//用于请求购物车接口
@property (nonatomic, strong) NSMutableArray *listArrRec_id;
@property (nonatomic, strong) NSMutableArray *listArrGoods_number;
@property (nonatomic, strong) NSMutableArray *listArrGoods_sn;

@property (nonatomic, strong) NSMutableDictionary *goods_snToNnmDictionary;//盛放good_sn对应数量
@property (nonatomic, strong) NSMutableDictionary *goods_snToRecDictionary;//盛放good_sn对应rec_id

@property (nonatomic, strong) UIButton *allBtn;//自选左侧上边的全部，请求数据中没有，自己添加的全部

@property (nonatomic, assign) CGRect rect;
@property (nonatomic, strong) UIImageView *ImageView;

@property (nonatomic, strong) NSMutableArray *detailID;//盛放good_id，用于下一级详情页

@property (nonatomic, strong)NSString *searchStr;

@end

@implementation OptionalGoodsController
static NSString *indenterL = @"cellLeft";
static NSString *indenterR = @"cellRight";

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self.listArrGoods_sn removeAllObjects];
    [self.listArrGoods_number removeAllObjects];
    [self.goods_snToNnmDictionary removeAllObjects];
    [self.goods_snToRecDictionary removeAllObjects];
    [_IDMutableArray removeAllObjects];
    [_goods_snNnumberDictionary removeAllObjects];
    [self creatCartList];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"自选";
    self.view.backgroundColor = Color(244, 245, 249);
    [self creatUI];

    self.page = @"1";
    self.keywords = @"";
    self.category_id = @"";
    
    self.classArr = [NSMutableArray arrayWithCapacity:13];
    self.listArr = [NSMutableArray arrayWithCapacity:13];
    self.classMutableArr = [NSMutableArray arrayWithCapacity:13];
    
    [self leftDetailParsing];
    
 
    self.goodsTableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(addGoods)];

    
    self.IDMutableArray = [NSMutableArray arrayWithCapacity:13];
    self.REC_IDMutableArray = [NSMutableArray arrayWithCapacity:13];
    self.goods_snNnumberDictionary = [NSMutableDictionary dictionaryWithCapacity:13];
    self.countArr = [NSArray array];
    
    self.listArrRec_id = [NSMutableArray arrayWithCapacity:13];
    self.listArrGoods_number = [NSMutableArray arrayWithCapacity:13];
    self.listArrGoods_sn = [NSMutableArray arrayWithCapacity:13];
    
    self.goods_snToNnmDictionary = [NSMutableDictionary dictionaryWithCapacity:13];
    self.goods_snToRecDictionary = [NSMutableDictionary dictionaryWithCapacity:13];
    
    self.detailID = [NSMutableArray arrayWithCapacity:13];
   
}

static int goodPage = 1;

-(void)addGoods{
 
    goodPage++;
    self.page = [NSString stringWithFormat:@"%d",goodPage];
    [self rightDetailParsingWithCategory_id:_category_id andKeywords:_keywords andPage:_page];
    
}


#pragma mark - 创建控件

-(void)creatUI{
    
    UIView *bgView = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(0), k_withBasedIphone6(1), k_withBasedIphone6(375), k_withBasedIphone6(50)) andBackColor:Color(255, 255, 255)];
    [self.view addSubview:bgView];
    
    //搜索框
    
    CGRect frame = CGRectMake(k_withBasedIphone6(30), k_withBasedIphone6(10), k_withBasedIphone6(315), k_withBasedIphone6(30));
    UIView *leftView = [[UIView alloc]init];                  //textFile左视图
    CGRect leftViewFrame = CGRectMake(0, 0, k_withBasedIphone6(50), k_withBasedIphone6(30));
    self.textFiled = [MyUIClass creatTextFieldWithFrame:frame andPlaceHolder:@"请输入需要搜索的商品编号" andSecu:NO andLeftView:leftView andLeftViewMode:UITextFieldViewModeAlways andLeftViewFrame:leftViewFrame andClearBtnMode:UITextFieldViewModeAlways andKeyboardType:UIKeyboardTypeDefault andReturnType:UIReturnKeySearch andimageView:nil andimageViewFrame:CGRectZero andimageViewImage:nil andBackColor:Color(244, 245, 249)];
    [_textFiled addTarget:self action:@selector(fieldClick:) forControlEvents:UIControlEventEditingChanged];
    _textFiled.delegate = self;
    _textFiled.font = [UIFont systemFontOfSize:14];
    _textFiled.layer.masksToBounds = YES;
    _textFiled.layer.cornerRadius = 15;
    
    UIButton *search = [UIButton buttonWithType:UIButtonTypeCustom];          //左视图上图片
    [search setEnlargeEdgeWithTop:k_withBasedIphone6(5) right:0 bottom:k_withBasedIphone6(5) left:k_withBasedIphone6(20)];
    [leftView addSubview:search];
    search.frame = CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(5), k_withBasedIphone6(20), k_withBasedIphone6(20));
    [search setBackgroundImage:[UIImage imageNamed:@"search"] forState:UIControlStateNormal];
    //search.backgroundColor = [UIColor redColor];
    [search addTarget:self action:@selector(secrch) forControlEvents:UIControlEventTouchUpInside];
   
    [bgView addSubview:_textFiled];
    
    
    
    
    [self  creatLeftTableView];
    [self creatRightTableView];
    
    //可拖动的购物车小框
    self.backCart = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(315), k_withBasedIphone6(500), k_withBasedIphone6(50), k_withBasedIphone6(60)) andBackColor:[UIColor clearColor]];
    UIButton *cartBtn = [MyUIClass makeImageButtonWithFrame:CGRectMake(0, k_withBasedIphone6(10), k_withBasedIphone6(44), k_withBasedIphone6(44)) andType:UIButtonTypeCustom andImageName:@"shoppingCart" andTarget:self andSelector:@selector(pushToSettleVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    cartBtn.layer.masksToBounds = YES;
    cartBtn.layer.cornerRadius = k_withBasedIphone6(22);
    cartBtn.layer.borderColor = Color(217, 217, 217).CGColor;
    cartBtn.layer.borderWidth = 2.0;
    
    self.totalCount = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(22), k_withBasedIphone6(2), k_withBasedIphone6(25), k_withBasedIphone6(18)) andText:@"0" andTextColor:Color(231, 43, 50) andFontSize:12 andAlignment:NSTextAlignmentCenter];
    self.totalCount.backgroundColor = [UIColor whiteColor];
    self.totalCount.layer.masksToBounds = YES;
    self.totalCount.layer.cornerRadius = k_withBasedIphone6(9);
    self.totalCount.layer.borderColor = Color(231, 43, 50).CGColor;
    self.totalCount.layer.borderWidth = 0.7;
    
    
    [self.view addSubview:_backCart];
    [_backCart addSubview:cartBtn];
    [_backCart addSubview:_totalCount];
    
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panView:)];
    [_backCart addGestureRecognizer:pan];
}


-(void)creatLeftTableView{
    
    self.tableviewLeft = [[UITableView alloc]initWithFrame:CGRectMake(0, k_withBasedIphone6(52), k_withBasedIphone6(85), Screen_H-IPHONE_X_NAV_HEIGHT -k_withBasedIphone6(52)) style:UITableViewStylePlain];
    _tableviewLeft.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableviewLeft.delegate = self;
    _tableviewLeft.dataSource = self;
    _tableviewLeft.rowHeight = k_withBasedIphone6(70);
    [_tableviewLeft registerClass:[LeftTableViewCell class] forCellReuseIdentifier:indenterL];
    [self.view addSubview:_tableviewLeft];

}

-(void)creatRightTableView{
    
    self.goodsTableView = [[UITableView alloc]initWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(52), k_withBasedIphone6(285), Screen_H-IPHONE_X_NAV_HEIGHT -k_withBasedIphone6(52)) style:UITableViewStylePlain];
    _goodsTableView.delegate = self;
    _goodsTableView.dataSource = self;
    _goodsTableView.rowHeight = k_withBasedIphone6(90);
    [_goodsTableView registerClass:[GoodsTableViewCell class] forCellReuseIdentifier:indenterR];
    [self.view addSubview:_goodsTableView];
}

#pragma mark - tableView 数据源/代理方法

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if ([tableView isEqual:self.tableviewLeft]) {
        return _classArr.count;
        
    }else if ([tableView isEqual:self.goodsTableView]){
        
        return _listArr.count;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([tableView isEqual:self.tableviewLeft]) {
        LeftTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indenterL];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.titleLabel.text = _classArr[indexPath.row][@"name"];
        
         [self.tableviewLeft selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionNone];
        
        return cell;
        
    }else if ([tableView isEqual:self.goodsTableView]){
        
     
        GoodsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indenterR];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        ListModel *model = _classMutableArr[indexPath.row];
        cell.goodsModel = model;
        
//        cell.CutBlock = ^(UILabel *countLabel) {
//            NSLog(@"CutBlock-%@", countLabel.text);
//            goodsModel.count = countLabel.text;
//        };
//
//        cell.AddBlock = ^(UILabel *countLabel) {
//            NSLog(@"AddBlock-%@", countLabel.text);
//            goodsModel.count = countLabel.text;
//        };
//
//        cell.ClickRowBlock = ^(UILabel *countLabel) {
////            [self.selectArray addObject:countLabel.text];
//            NSLog(@"%@",self.selectArray);
//
//        };
        //__block GoodsTableViewCell *weakCell = cell;
        

        cell.ClickBlock = ^(UIImageView *view) {

            //获取cell再屏幕上坐标 实现点击添加按钮的动画坐标获取。在点击事件请求成功中实现动画
            CGRect rectInTableView = [self->_goodsTableView rectForRowAtIndexPath:indexPath];
            self.rect = [self->_goodsTableView convertRect:rectInTableView toView:[self->_goodsTableView superview]];
            self.ImageView = view;
            
            
            if ([self->_listArrGoods_sn containsObject:model.goods_sn]) {
               //购物车订单号包含点击的订单号
                NSString *rec_id = [self.goods_snToRecDictionary valueForKey:model.goods_sn];
                NSString *good_number = [self.goods_snToNnmDictionary valueForKey:model.goods_sn];

                NSInteger count = [good_number integerValue];
                count++;
                NSString *numStr = [NSString stringWithFormat:@"%ld",(long)count];
                
                [self addGoodsRec_id:rec_id andNumber:numStr];
                
            }else{
                //购物车不包含点击的订单号--第一次添加
            
                [self addGoodsForCart:model.goods_sn andgoodsNumber:@"1"];
          
            }
        };
        
        
        return cell;
        
    }
    return nil;

}



-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
   
    //点击修改cell上字体颜色
    if ([tableView isEqual:self.tableviewLeft]) {
        
        [self.allBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        LeftTableViewCell *leftCell = [tableView cellForRowAtIndexPath:indexPath];
        leftCell.contentView.backgroundColor = Color(244, 245, 249);
        
        NSArray *array = [tableView visibleCells];//获取左侧tableView的cell并便利
        for (LeftTableViewCell *leftCell in array) {
            // 不打对勾
            leftCell.titleLabel.textColor = [UIColor blackColor];
        }
        // 打对勾
        leftCell.titleLabel.textColor = Color(7, 196, 190);

        [self.listArr removeAllObjects];//选中不同分类 先清空右侧盛放数据数组
        [self.classMutableArr removeAllObjects];
        [self.detailID removeAllObjects];
        
        self.category_id = [NSString stringWithFormat:@"%@",_classArr[indexPath.row][@"id"]];
        
        if (indexPath.row == 0) {
            self.category_id = @"";
        }
      
        [self rightDetailParsingWithCategory_id:_category_id andKeywords:_keywords andPage:@"1"];
        
        [_tableviewLeft selectRowAtIndexPath:indexPath animated:YES scrollPosition: UITableViewScrollPositionNone];
        
    }else if ([tableView isEqual:self.goodsTableView]){
   
        OptionalGoodsDetailController *vc = [[OptionalGoodsDetailController alloc]init];
        vc.detailGoods_id = _detailID[indexPath.row];
        [self.navigationController pushViewController:vc animated:YES];
        
    }else{
        
        return;
    }
   
    
}


//可移动购物车平移
-(void)panView:(UIPanGestureRecognizer *)sender{
    
    CGPoint point = [sender translationInView:sender.view];
    sender.view.transform = CGAffineTransformTranslate(sender.view.transform, point.x, point.y);
    [sender setTranslation:CGPointZero inView:sender.view];

//    if (_backCart.frame.origin.x <= 0 ||_backCart.frame.origin.x >=Screen_W-k_withBasedIphone6(60) ||_backCart.frame.origin.y >= Screen_H -IPHONE_X_NAV_HEIGHT-k_withBasedIphone6(60) ||_backCart.frame.origin.y <= IPHONE_X_NAV_HEIGHT) {
//        //做一些判定使其不能继续错误滑动
//
//    }
    if (_backCart.frame.origin.x < k_withBasedIphone6(60)) {
    
        _backCart.frame = CGRectMake(k_withBasedIphone6(60), _backCart.frame.origin.y, _backCart.frame.size.width, _backCart.frame.size.height);
        
    }
    if (_backCart.frame.origin.x > Screen_W-k_withBasedIphone6(60)) {
      
        _backCart.frame = CGRectMake(Screen_W-k_withBasedIphone6(60), _backCart.frame.origin.y, _backCart.frame.size.width, _backCart.frame.size.height);
    }
    
    if (_backCart.frame.origin.y < IPHONE_X_NAV_HEIGHT) {
        
         _backCart.frame = CGRectMake(_backCart.frame.origin.x, IPHONE_X_NAV_HEIGHT, _backCart.frame.size.width, _backCart.frame.size.height);
    }
    
    if (_backCart.frame.origin.y > Screen_H -IPHONE_X_NAV_HEIGHT-k_withBasedIphone6(60)) {
        
        _backCart.frame = CGRectMake(_backCart.frame.origin.x, Screen_H -IPHONE_X_NAV_HEIGHT-k_withBasedIphone6(60), _backCart.frame.size.width, _backCart.frame.size.height);
    }
    
}


#pragma mark - 按钮点击事件

-(void)pushToSettleVC{

    SettleAccountsController *vc = [[SettleAccountsController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];

}

-(void)fieldClick:(UITextField *)sender{
    self.searchStr = sender.text;
    //LLog(@"🐂aa%@",_searchStr);
}

-(void)secrch{
    //NSLog(@"点击搜索");
    [_textFiled resignFirstResponder];
    if (_searchStr) {
        [self searchGoods:_searchStr];
    }
}

//点击search的操作
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    //这里就是你要做的操作
    [_textFiled resignFirstResponder];
    
    if (_searchStr) {
        [self searchGoods:_searchStr];
    }
    
    
    return YES;
}

#pragma mark - parsing
//右侧自选列表数据请求
-(void)rightDetailParsingWithCategory_id:(NSString *)category_id andKeywords:(NSString *)keywords andPage:(NSString *)page{

    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *rightToken = [userDefault objectForKey:@"Token"];
    NSString *rightSeller_id = [userDefault objectForKey:@"Seller_id"];
    NSString *temp = @"/sites/api/?url=merchant/goods/list";
    NSString *string = [cckdURL stringByAppendingString:temp];//商品列表

    NSDictionary *parameters = @{
                                 @"token": rightToken,
                                 
                                 @"seller_id": [NSNumber numberWithInteger:[rightSeller_id integerValue]],
                                 
                                 @"filter" : @{
                                         @"category_id" : [NSNumber numberWithInteger:[category_id integerValue]],//fenlei
                                         @"keywords" : keywords,
                                         @"sort_by" : @"",
                                         },
                                 
                                 @"pagination": @{
                                         @"count" : @8,
                                         @"page"  : [NSNumber numberWithInteger:[page integerValue]]
                                         }
                                 
                                 };
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
        //LLog(@"右侧数据请求aa%@",responseObject);
        [self.classMutableArr removeAllObjects];
        //在执行前已经清空
        [self.listArr addObjectsFromArray:responseObject[@"data"]];
  
        for (NSDictionary *dic in self.listArr) {
            ListModel *mode = [ListModel new];
            [mode setValuesForKeysWithDictionary:dic];
            [self->_classMutableArr addObject:mode];
            [self->_detailID addObject:mode.NewId];
        }
        
        
        int lastPage = [responseObject[@"paginated"][@"more"] intValue];
  
        if (lastPage == 1) {
            [self.goodsTableView.mj_footer endRefreshing];
        }else{
            [self.goodsTableView.mj_footer endRefreshingWithNoMoreData];
        }
        
        [self.goodsTableView reloadData];
        
        
    } successZero:^(id responseObject) {
        
        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");
            [self showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
            
        }else{
            
            
            [self showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:^{
                
                [self rightDetailParsingWithCategory_id:weakSelf.category_id andKeywords:weakSelf.keywords andPage:weakSelf.page];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
        }
        
    } fail:^(NSError *error) {
 
        NSString *alterString = @"数据加载失败，请检查网络！";
        [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }];
}


//左侧列表数据请求
-(void)leftDetailParsing{

    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *tokenStr = [userDefault objectForKey:@"Token"];
    NSString *seller_id = [userDefault objectForKey:@"Seller_id"];
    //http://ecjia.cckdtj.com/sites/api/?url=merchant/goods/category
    NSString *string = @"/sites/api/?url=merchant/goods/category";//商品分类接口
    NSString *strUrl = [cckdURL stringByAppendingString:string];
    NSDictionary *parameters = @{
                                 @"token": tokenStr,
                                 @"seller_id": [NSNumber numberWithInteger:[seller_id integerValue]],
                                 };
    
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:strUrl parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
        
        //NSLog(@"左侧数据请求aa%@",responseObject);
        NSDictionary *tempDic = @{
                                  @"children": @[],
                                        @"id": @"",
                                     @"image": @"",
                                      @"name": @"全部"
                                 };
        
        
        
        [self.classArr addObject:tempDic];
        [self.classArr addObjectsFromArray:responseObject[@"data"]];
        
        //LLog(@"%@",self->_classArr);
 
        [self rightDetailParsingWithCategory_id:self->_category_id andKeywords:self->_keywords andPage:self->_page];
        
        [self.tableviewLeft reloadData];
        
    } successZero:^(id responseObject) {

        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");
            
            [self showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
        }else{
            
            [self showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        }
        
    } fail:^(NSError *error) {
    
        NSString *alterString = @"数据加载失败，请检查网络！";
        [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }];
}

//添加购物车 使用sn和数量
-(void)addGoodsForCart:(NSString *)goods_sn andgoodsNumber:(NSString *)number{
 
    //http://ecjia.cckdtj.com/sites/api/?url=admin/flow/checkOrder
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userDefault objectForKey:@"Token"];
    NSString *member_user_id = [userDefault objectForKey:@"member_user_id"];
    NSString *temp = @"/sites/api/?url=admin/flow/checkOrder";
    NSString *string = [cckdURL stringByAppendingString:temp];//查询购物车接口
    NSDictionary *parameters = @{
                                 
                                 @"token" : token,
                                 @"addgoods":@{
                                         @"goods_sn":goods_sn,
                                         @"number":[NSNumber numberWithInteger:[number integerValue]]
                                         },
                                 
                                 @"user":@{
                                         @"user_id":[NSNumber numberWithInteger:[member_user_id integerValue]],
                                         }
                                 };
     __weak typeof(self) weakSelf = self;
     [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
        //加入购物车动画
        CGRect imageViewRect   = self.ImageView.frame;
        imageViewRect.origin.y = self->_rect.origin.y + imageViewRect.origin.y;
        imageViewRect.origin.x = self->_rect.origin.x ;
        [[PurchaseCarAnimationTool shareTool] startAnimationandView:self.ImageView
                                                               rect:imageViewRect
                                                        finisnPoint:CGPointMake(self->_backCart.frame.origin.x+k_withBasedIphone6(30), self->_backCart.frame.origin.y+k_withBasedIphone6(60))
                                                        finishBlock:^(BOOL finish) {
                                                            [self shakeAnimation];
                                                        }];
        //小购物车提示框
        NSInteger about = [self.totalCount.text integerValue];
        about++;
        NSString *temp = [NSString stringWithFormat:@"%ld",(long)about];
        self.totalCount.text = temp;
        
        [self.listArrGoods_sn removeAllObjects];
        NSArray * array = responseObject[@"data"][@"goods_list"];//数组可以上空
        for (NSDictionary *dic in array) {
            CartModel *model = [CartModel new];
            [model setValuesForKeysWithDictionary:dic];
            [self.listArrGoods_sn addObject:model.goods_sn];
            [self.goods_snToRecDictionary setValue:model.rec_id forKey:model.goods_sn];
            [self.goods_snToNnmDictionary setValue:model.goods_number forKey:model.goods_sn];
        }
 
    } successZero:^(id responseObject) {

        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");
           
            [self showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
            
            
        }else{
            
            [self showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        }
        
    } fail:^(NSError *error) {

        NSString *alterString = @"数据加载失败，请检查网络！";
        [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }];
    
    
}



//已经存在于购物车的走这个更新接口
-(void)addGoodsRec_id:(NSString *)rec_id andNumber:(NSString *)number{
    //http://ecjia.cckdtj.com/sites/api/?url=admin/flow/checkOrder
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userDefault objectForKey:@"Token"];
    NSString *member_user_id = [userDefault objectForKey:@"member_user_id"];
    NSString *temp = @"/sites/api/?url=admin/flow/checkOrder";////查询购物车接口
    NSString *string = [cckdURL stringByAppendingString:temp];
    NSDictionary *parameters = @{
                                 
                                 @"token" : token,
                                 @"updategoods":@{
                                         @"rec_id":[NSNumber numberWithInteger:[rec_id integerValue]],
                                         @"number":[NSNumber numberWithInteger:[number integerValue]]
                                         },
                                 
                                 @"user":@{
                                         @"user_id":[NSNumber numberWithInteger:[member_user_id integerValue]],
                                         }
                                 };
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
        //加入购物车动画
        CGRect imageViewRect   = self.ImageView.frame;
        imageViewRect.origin.y = self->_rect.origin.y + imageViewRect.origin.y;
        imageViewRect.origin.x = self->_rect.origin.x ;
        [[PurchaseCarAnimationTool shareTool] startAnimationandView:self.ImageView
                                                               rect:imageViewRect
                                                        finisnPoint:CGPointMake(self->_backCart.frame.origin.x+k_withBasedIphone6(30), self->_backCart.frame.origin.y+k_withBasedIphone6(60))
                                                        finishBlock:^(BOOL finish) {
                                                            [self shakeAnimation];
                                                        }];
        //小购物车提示框
        NSInteger about = [self.totalCount.text integerValue];
        about++;
        NSString *temp = [NSString stringWithFormat:@"%ld",(long)about];
        self.totalCount.text = temp;
        
        [self.listArrGoods_sn removeAllObjects];
        NSArray * array = responseObject[@"data"][@"goods_list"];//数组可以上空
        // [self.listArrGoods_number removeAllObjects];
        for (NSDictionary *dic in array) {
            CartModel *model = [CartModel new];
            [model setValuesForKeysWithDictionary:dic];
            [self.listArrGoods_sn addObject:model.goods_sn];
            //NSLog(@"%@-%@",model.rec_id,model.goods_number);
            [self.goods_snToRecDictionary setValue:model.rec_id forKey:model.goods_sn];
            [self.goods_snToNnmDictionary setValue:model.goods_number forKey:model.goods_sn];
        }

    } successZero:^(id responseObject) {

        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");
            [self showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
            
            
        }else{
            
            [self showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
        }
        
    } fail:^(NSError *error) {
        
        NSString *alterString = @"数据加载失败，请检查网络！";
        [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }];
}


-(void)searchGoods:(NSString *)sender{
    
    //http://ecjia.cckdtj.com/sites/api/?url=admin/goods/product_search
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userDefault objectForKey:@"Token"];
    NSString *string = @"/sites/api/?url=admin/goods/product_search";//搜索接口
    NSString *strUrl = [cckdURL stringByAppendingString:string];
    NSDictionary *parameters = @{
                                 
                                 @"token" : token,
                                 @"goods_sn" : sender
                                 };
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:strUrl parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
        [self.listArr removeAllObjects];
        [self.classMutableArr removeAllObjects];
        [self.detailID removeAllObjects];
        
        [self.listArr addObjectsFromArray:responseObject[@"data"]];
        
        for (NSDictionary *dic in self.listArr) {
            ListModel *mode = [ListModel new];
            [mode setValuesForKeysWithDictionary:dic];
            [self->_classMutableArr addObject:mode];
            [self->_detailID addObject:mode.NewId];
        }
        
        [self.goodsTableView reloadData];
 
    } successZero:^(id responseObject) {
     
        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");
            [weakSelf showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
            
            
        }else{
            
            [weakSelf showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
        }
        
    } fail:^(NSError *error) {
        
        NSString *alterString = @"数据加载失败，请检查网络！";
        [weakSelf showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }];
    
}



//提示框小装 show = yes 有取消按钮。=no只有确定一个按钮
-(void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message andActionTitle:(NSString *)actionTitle andactionBlock:(void(^)(void))ActionBlock andActionCancelTitle:(NSString *)actionCancelTitle andActionCancelBlock:(void(^)(void))ActionCancelBlock andBool:(BOOL)show {
    
    if (show) {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:actionCancelTitle style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionCancelBlock) {
                ActionCancelBlock();
            }
        }];
        [alert addAction:actionCancel];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }else{
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}



//获取显示购物车内容-用于判定商品吗是否已经在购物车中
-(void)creatCartList{
 
    //http://ecjia.cckdtj.com/sites/api/?url=admin/flow/checkOrder
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *tokenStr = [userDefault objectForKey:@"Token"];
    NSString *User_id = [userDefault objectForKey:@"member_user_id"];
    //以后数据前加个判断可以预防返回或取到null数据导致的崩溃
//    if (User_id == nil ) {
//        User_id = @"";
//    }
    NSString *temp = @"/sites/api/?url=admin/flow/checkOrder";
    NSString *string = [cckdURL stringByAppendingString:temp];//查询购物车接口
    NSDictionary *parameters = @{
                                 
                                 @"token" : tokenStr,
                                 @"user":@{
                                         @"user_id":[NSNumber numberWithInteger:[User_id integerValue]] ,
                                         }
                                 };
    
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:parameters success:^(id obj) {
        
    } successOne:^(id responseObject) {
        
        
        
        if (![responseObject[@"data"][@"goods_list"] isKindOfClass:[NSArray class]] ) {
            
            self.totalCount.text = @"0";
            
        }else{
            
            NSArray * array = responseObject[@"data"][@"goods_list"];//数组可以上空

            for (NSDictionary *dic in array) {
                CartModel *model = [CartModel new];
                [model setValuesForKeysWithDictionary:dic];
                [self.listArrGoods_sn addObject:model.goods_sn];
                //NSLog(@"%@-%@",model.rec_id,model.goods_number);
                [self.goods_snToRecDictionary setValue:model.rec_id forKey:model.goods_sn];
                [self.goods_snToNnmDictionary setValue:model.goods_number forKey:model.goods_sn];
                
                [self.listArrGoods_number addObject:model.goods_number];
                
            }

            
            CGFloat sum = [[self.listArrGoods_number valueForKeyPath:@"@sum.floatValue"] floatValue];
            self.totalCount.text = [NSString stringWithFormat:@"%.f",sum];
        }
        
  
        
    } successZero:^(id responseObject) {

        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //NSLog(@"token改变，登陆过期");
            
            [weakSelf showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
        }else{
            
            [weakSelf showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
        }
        
    } fail:^(NSError *error) {
        
        NSString *alterString = @"数据加载失败，请检查网络！";
        [weakSelf showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }];
    
}


//购物车抖动动画
-(void)shakeAnimation{
    CAKeyframeAnimation *anima = [CAKeyframeAnimation animationWithKeyPath:@"transform.rotation"];//在这里@"transform.rotation"==@"transform.rotation.z"
    NSValue *value1 = [NSNumber numberWithFloat:-M_PI/180*4];
    NSValue *value2 = [NSNumber numberWithFloat:M_PI/180*4];
    NSValue *value3 = [NSNumber numberWithFloat:-M_PI/180*4];
    anima.values = @[value1,value2,value3];
    anima.repeatCount = 5;
    
    [_backCart.layer addAnimation:anima forKey:@"shakeAnimation"];
    
    
}


- (NSMutableArray *)selectArray {
    if (!_selectArray) {
        self.selectArray = [NSMutableArray new];
    }
    return _selectArray;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
