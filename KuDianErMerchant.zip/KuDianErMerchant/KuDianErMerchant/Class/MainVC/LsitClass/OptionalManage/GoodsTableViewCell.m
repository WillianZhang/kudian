//
//  GoodsTableViewCell.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/12.
//  Copyright © 2018年 william. All rights reserved.
//

#import "GoodsTableViewCell.h"

@implementation GoodsTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        self.goodImageView = [MyUIClass makeUIImageWithFrame:CGRectMake(k_withBasedIphone6(5), k_withBasedIphone6(10), k_withBasedIphone6(70), k_withBasedIphone6(70)) andPicName:@""];
        
        self.goodsNameLabel = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(85), k_withBasedIphone6(10), k_withBasedIphone6(160), k_withBasedIphone6(40)) andText:@"" andTextColor:Color(50, 50, 50) andFontSize:13.0 andAlignment:NSTextAlignmentLeft];
        
        self.priceLabel = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(85), k_withBasedIphone6(55), k_withBasedIphone6(60), k_withBasedIphone6(20)) andText:@"" andTextColor:Color(231, 43, 50) andFontSize:18.0 andAlignment:NSTextAlignmentLeft];
        
        self.cutBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(140), k_withBasedIphone6(55), k_withBasedIphone6(20), k_withBasedIphone6(20)) andType:UIButtonTypeCustom andBackColor:Color(255, 255, 255) andTitle:@"-" andTitleFontSize:14.0 andTitleColor:Color(50, 50, 50) andTarget:self andSelector:@selector(cut:) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
        self.cutBtn.layer.borderWidth = 1;
        self.cutBtn.layer.borderColor = [UIColor lightGrayColor].CGColor;
        
        self.countLabel = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(160), k_withBasedIphone6(55), k_withBasedIphone6(40), k_withBasedIphone6(20)) andText:@"0" andTextColor:Color(231, 43, 50) andFontSize:15.0 andAlignment:NSTextAlignmentCenter];
        self.countLabel.layer.borderWidth = 1;
        self.countLabel.layer.borderColor = [UIColor lightGrayColor].CGColor;
        
        self.addBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(200), k_withBasedIphone6(55), k_withBasedIphone6(20), k_withBasedIphone6(20)) andType:UIButtonTypeCustom andBackColor:Color(255, 255, 255) andTitle:@"+" andTitleFontSize:14.0 andTitleColor:Color(50, 50, 50) andTarget:self andSelector:@selector(add:) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
        self.addBtn.layer.borderWidth = 1;
        self.addBtn.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
        self.clickBtn = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(230), k_withBasedIphone6(50), k_withBasedIphone6(30), k_withBasedIphone6(30)) andType:UIButtonTypeCustom andImageName:@"addcart" andTarget:self andSelector:@selector(click:) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
        [self.clickBtn setImage:[UIImage imageNamed:@"addcart_light"] forState:UIControlStateHighlighted];
        
        [self addSubview:_goodImageView];
        [self addSubview:_goodsNameLabel];
        [self addSubview:_priceLabel];
//        [self addSubview:_cutBtn];
//        [self addSubview:_countLabel];
//        [self addSubview:_addBtn];
        [self addSubview:_clickBtn];
        
        
        
        
        
    }

    return self;
}


//减
- (void)cut:(UIButton *)sender {
    NSInteger count = [self.countLabel.text integerValue];
    count--;
    if (count <= 0) {
        return;
    }
    self.countLabel.text = [NSString stringWithFormat:@"%ld", (long)count];
    if (self.CutBlock) {
        self.CutBlock(self.countLabel);
    }
}

//加
- (void)add:(UIButton *)sender {
    NSInteger count = [self.countLabel.text integerValue];
    count++;
    self.countLabel.text = [NSString stringWithFormat:@"%ld", (long)count];
    if (self.AddBlock) {
        self.AddBlock(self.countLabel);
    }
}

////选中
//- (void)click:(UIButton *)sender {
//    sender.selected = !sender.selected;
//    if (sender.selected) {
//        [sender setImage:[UIImage imageNamed:@"clicked"] forState:(UIControlStateNormal)];
//    } else {
//        [sender setImage:[UIImage imageNamed:@"unClick"] forState:(UIControlStateNormal)];
//    }
//    if (self.ClickRowBlock) {
//        self.ClickRowBlock(sender.selected);
//    }
//}

- (void)click:(UIButton *)sender {
    
 //   if (self.ClickRowBlock) {
//        self.ClickRowBlock(self.countLabel);//点击购物车按钮回调数量---如果不增加添加减少。在控制器创建一个可变数组，点击将产品的id加进去
        
//    }
    
    if (self.ClickBlock) {
        self.ClickBlock(self.goodImageView);
    }
    
    
    //self.ClickBlock();
}


-(void)setGoodsModel:(ListModel *)goodsModel{
    self.goodsNameLabel.text = goodsModel.name;
    

    NSString *string = goodsModel.img[@"small"];
    NSURL *url = [NSURL URLWithString:string];
    [self.goodImageView sd_setImageWithURL:url];
    
    
    //NSString *temp = [@"￥" stringByAppendingString:goodsModel.unformatted_shop_price ];
    NSString *temp = goodsModel.shop_price;
    NSMutableAttributedString *fontAttributeNameStr = [[NSMutableAttributedString alloc]initWithString:temp];
    [fontAttributeNameStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:13] range:NSMakeRange(0, 1)];
    [fontAttributeNameStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:13] range:NSMakeRange(temp.length - 2, 2)];
    self.priceLabel.attributedText = fontAttributeNameStr;
    
    //self.countLabel.text = goodsModel.numbers;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
