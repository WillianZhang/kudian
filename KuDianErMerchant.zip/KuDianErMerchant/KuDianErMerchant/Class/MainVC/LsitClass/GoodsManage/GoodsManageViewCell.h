//
//  GoodsManageViewCell.h
//  KuDianErMerchant
//
//  Created by william on 2018/7/19.
//  Copyright © 2018年 william. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GoodManageModel.h"

@interface GoodsManageViewCell : UITableViewCell


@property(nonatomic, strong) UIImageView *goodsImage;
@property(nonatomic, strong) UILabel *goodsName_lab;
@property(nonatomic, strong) UILabel *goods_sn_lab;
@property(nonatomic, strong) UILabel *shop_price_lab;



@property(nonatomic ,strong) GoodManageModel *manageModel;

@end
