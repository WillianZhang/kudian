//
//  GoodManageModel.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/19.
//  Copyright © 2018年 william. All rights reserved.
//

#import "GoodManageModel.h"

@implementation GoodManageModel

// 容错处理
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}


-(NSString *)description{
    
    return [NSString stringWithFormat:@"%@--%@--%@--%@", _name,_img,_shop_price,_goods_sn];
}

@end
