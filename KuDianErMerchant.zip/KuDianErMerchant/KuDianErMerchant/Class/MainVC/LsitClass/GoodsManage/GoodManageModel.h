//
//  GoodManageModel.h
//  KuDianErMerchant
//
//  Created by william on 2018/7/19.
//  Copyright © 2018年 william. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GoodManageModel : NSObject
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *img;
@property (nonatomic, strong) NSString * goods_sn;
@property (nonatomic, strong) NSString * shop_price;

@end
