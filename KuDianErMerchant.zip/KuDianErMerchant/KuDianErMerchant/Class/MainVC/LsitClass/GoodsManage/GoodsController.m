//
//  GoodsController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//  商品管理

#import "GoodsController.h"
#import "GoodManageModel.h"
#import "GoodsManageViewCell.h"
#import <WebKit/WebKit.h>
#import "DFYSVP.h"


@interface GoodsController ()<WKNavigationDelegate,WKUIDelegate,WKScriptMessageHandler>

@property (nonatomic ,strong) WKWebView *webView;
@property (nonatomic ,strong) WKWebViewConfiguration *configuration;

/*
//<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>
//@property(nonatomic, strong) UITableView *goodsListTableView;
//
//@property(nonatomic, strong) NSMutableArray *itemsArray;
*/




@end

@implementation GoodsController

-(void)viewWillAppear:(BOOL)animated{
    //这是删除所有缓存和cookie的
    NSSet *websiteDataTypes = [WKWebsiteDataStore allWebsiteDataTypes];
    //// Date from
    NSDate *dateFrom = [NSDate dateWithTimeIntervalSince1970:0];
    //// Execute
    [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:websiteDataTypes modifiedSince:dateFrom completionHandler:^{
        // Done

    }];
}

- (void)viewDidLoad{
    [super viewDidLoad];
    self.title = @"商品列表";

    //清除返回按钮上文字
    //    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:nil action:nil];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];//改变返回按钮颜色
    self.navigationController.navigationBarHidden = NO;//是否隐藏导航
    self.navigationController.navigationBar.barTintColor = Color(7, 196, 190);//导航栏颜色
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName :  [UIColor whiteColor]};//导航栏标题颜色
    self.view.backgroundColor = Color(240, 240, 240);
    
    [self creatWkWebView];

}

-(void)creatWkWebView{
    
    DFYSVPLoading(@"请稍等...", NO);
    //http://ecjia.cckdtj.com/sites/m/index.php?m=newgoods&c=index&a=manage&typeTo=ios   store_id就是登录店铺seller_id。uuid是获取token
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *seller_id = [userDefault objectForKey:@"Seller_id"];
    NSString *deviceUUID = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    
    NSString *newStr = [NSString stringWithFormat:@"/sites/m/index.php?m=newgoods&c=index&a=manage&typeTo=ios&store_id=%@&client=iPhone&code=6015&version=1.6&udid=%@",seller_id,deviceUUID];
    NSString *string = [cckdURL stringByAppendingString:newStr];
    
    self.configuration = [[WKWebViewConfiguration alloc] init];
    [_configuration.userContentController addScriptMessageHandler:self name:@"scan"];
    
    self.webView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H-64) configuration:_configuration];
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:string]]];
    self.webView.navigationDelegate = self;
    self.webView.UIDelegate = self;
    //开了支持滑动返回
    self.webView.allowsBackForwardNavigationGestures = YES;
    [self.view addSubview:self.webView];
    
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(20.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [DFYSVP dismiss];
    });
    
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
    //网页导航加载完毕
    [DFYSVP dismiss];
}

- (void)webView:(WKWebView *)webView didFailNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
    
    [DFYSVP dismiss];
    [self showAlertWithTitle:@"温馨提示" andMessage:@"数据加载失败，请检查网络" andActionTitle:@"重试" andactionBlock:^{
        
        [self creatWkWebView];
        
    } andActionCancelTitle:@"取消" andActionCancelBlock:nil andBool:YES];
    
}

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message{
 
    if ([message.name isEqualToString:@"scan"]) {
        //调用原生扫码
        [[NSNotificationCenter defaultCenter] postNotificationName:@"changeRootVC" object:self];//通知，修改MAIN成跟视图
    }
}
#pragma mark WKUIDelegate
//在JS端调用alert函数时，会触发此代理方法。
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:message?:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:([UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler();
    }])];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL))completionHandler{
    //    DLOG(@"msg = %@ frmae = %@",message,frame);
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:message?:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:([UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(NO);
    }])];
    [alertController addAction:([UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(YES);
    }])];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * _Nullable))completionHandler{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:prompt message:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.text = defaultText;
    }];
    [alertController addAction:([UIAlertAction actionWithTitle:@"完成" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(alertController.textFields[0].text?:@"");
    }])];
    [self presentViewController:alertController animated:YES completion:nil];
}

-(WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures
{
    if (!navigationAction.targetFrame.isMainFrame) {
        [webView loadRequest:navigationAction.request];
    }
    return nil;
}


-(void)dealloc{
    say(@"注册页面释放了吗？");
    
}

//退出页面释放内存
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    ///关闭web页时会释放内存
    [self.configuration.userContentController removeScriptMessageHandlerForName:@"scan"];
    self.webView.navigationDelegate = nil;
    self.webView.UIDelegate = nil;
}


//提示框小装 show = yes 有取消按钮。=no只有确定一个按钮
-(void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message andActionTitle:(NSString *)actionTitle andactionBlock:(void(^)(void))ActionBlock andActionCancelTitle:(NSString *)actionCancelTitle andActionCancelBlock:(void(^)(void))ActionCancelBlock andBool:(BOOL)show {
    
    if (show) {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:actionCancelTitle style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionCancelBlock) {
                ActionCancelBlock();
            }
        }];
        [alert addAction:actionCancel];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }else{
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}











/*
 //原生代码实现
//static NSString *indenfer = @"cellGoods";
//
//- (void)viewDidLoad {
//    [super viewDidLoad];
//    self.view.backgroundColor = Color(240, 240, 240);
//    self.title = @"商品列表";
//    [self creatUI];
//
//    [self parsing];
//}
//
//-(void)creatUI{
//    self.goodsListTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT) style:UITableViewStylePlain];
//    //_memberListTableView.separatorColor = [UIColor blackColor];
//    _goodsListTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
//    _goodsListTableView.delegate = self;
//    _goodsListTableView.dataSource = self;
//    _goodsListTableView.rowHeight = k_withBasedIphone6(60);
//    [_goodsListTableView registerClass:[GoodsManageViewCell class] forCellReuseIdentifier:indenfer];
//
//    [self.view addSubview:_goodsListTableView];
//}
//
//
////UITableViewDataSource
//-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//    return _itemsArray.count;
//}
//
//- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
//    GoodsManageViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indenfer];
//
//    cell.selectionStyle = UITableViewCellSelectionStyleNone;
//
////    cell.textLabel.text = _itemsArrName[indexPath.row];
//
//    GoodManageModel *model = _itemsArray[indexPath.row];
////    NSLog(@"~~~zz%@",_itemsArrName);
//    cell.manageModel = model;
//
//    return cell;
//}
//
//- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    NSLog(@"点击cell");
//
//}
////分区 header的高度
//- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
//{
//
//    return k_withBasedIphone6(115);
//}
//
//// 分区 header的视图
//- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
//
//    UIView *aView = [[UIView alloc] init];
//    aView.backgroundColor = Color(240, 240, 240);
//
//    UILabel *count = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(3), 0, k_withBasedIphone6(124), k_withBasedIphone6(20)) andText:@"总商品数量  15800" andTextColor:Color(150, 150, 150) andFontSize:13.0 andAlignment:NSTextAlignmentCenter];
//    [aView addSubview:count];
//    UILabel *countOnSell = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(127), 0, k_withBasedIphone6(124), k_withBasedIphone6(20)) andText:@"上架商品  150" andTextColor:Color(150, 150, 150) andFontSize:13.0 andAlignment:NSTextAlignmentCenter];
//    [aView addSubview:countOnSell];
//    UILabel *countUnSell = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(251), 0, k_withBasedIphone6(124), k_withBasedIphone6(20)) andText:@"下架商品  15" andTextColor:Color(150, 150, 150) andFontSize:13.0 andAlignment:NSTextAlignmentCenter];
//    [aView addSubview:countUnSell];
//
//    UIView *vvv = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(20), k_withBasedIphone6(60), k_withBasedIphone6(43)) andBackColor:[UIColor orangeColor]];
//    [aView addSubview:vvv];
//
//    UIView *bgView = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(61), k_withBasedIphone6(20), k_withBasedIphone6(253), k_withBasedIphone6(43)) andBackColor:Color(199, 187, 171)];
//    [aView addSubview:bgView];
//
//
//    UIView *leftView = [[UIView alloc]init];                  //textFile左视图
//    UIButton *search = [UIButton buttonWithType:UIButtonTypeCustom];          //左视图上图片
//    UITextField *textFiled = [[UITextField alloc]init];
//
//    textFiled.frame = CGRectMake(k_withBasedIphone6(15), k_withBasedIphone6(k_withBasedIphone6(6)), k_withBasedIphone6(223), k_withBasedIphone6(30));
//
//    CGRect leftViewFrame = CGRectMake(0, 0, k_withBasedIphone6(31), k_withBasedIphone6(30));
//    CGRect imageViewFrame = CGRectMake(0, 0, k_withBasedIphone6(31), k_withBasedIphone6(30));
//    leftView.frame = leftViewFrame;
//    textFiled.leftView = leftView;
//    textFiled.leftViewMode = UITextFieldViewModeAlways;
//    textFiled.placeholder = @"请输入会员手机号进行搜索";
//    textFiled.font = [UIFont systemFontOfSize:14];
//    [leftView addSubview:search];
//    search.frame = imageViewFrame;
//    textFiled.layer.masksToBounds = YES;
//    textFiled.layer.cornerRadius = 15;
//    textFiled.clearButtonMode = UITextFieldViewModeAlways;
//    [search setBackgroundImage:[UIImage imageNamed:@"搜索"] forState:UIControlStateNormal];
//    textFiled.keyboardType = UIKeyboardTypeDefault;
//    textFiled.delegate = self;
//    textFiled.returnKeyType = UIReturnKeySearch;
//    textFiled.backgroundColor = [UIColor whiteColor];
//    [bgView addSubview:textFiled];
//
//
//
//    UIButton *addGoods = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(315), k_withBasedIphone6(20), k_withBasedIphone6(60), k_withBasedIphone6(43)) andType:0 andTitle:@"" andTitleFontSize:0.0 andImageName:@"addGoods" andTarget:self andSelector:@selector(addGoods) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//    [aView addSubview:addGoods];
//
//    UIView *backView = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(65), Screen_W, k_withBasedIphone6(50)) andBackColor:Color(94, 202, 214)];
//    [aView addSubview:backView];
//
//
//    return aView;
//}
//
//
//#pragma mark -- 数据请求
//-(void)parsing{
//    NSString *URLString = @"http://wxmp.cckdtj.com/sites/api/?url=merchant/goods/list";
//    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
//    NSString *token = [userDefault objectForKey:@"Token"];
//    NSLog(@"token改变%@",token);
//    NSDictionary *parameters = @{
//
//
//
//                                 @"token" : @"549eaaa4060dcba74f5167eec73583be74838d54",
//                                 @"seller_id" : @81,
//                                 @"filter" : @{
//                                     @"category_id" : @"",
//                                     @"keywords" : @"",
//                                     @"sort_by" : @""
//                                 },
//                                 @"pagination":@{
//                                     @"count" : @10,
//                                     @"page"  : @1
//                                 },
//
//
//                                 };
//
//    [[MyHttpRequest shardWebUtil] postNetworkRequestURLString:URLString parameters:parameters success:^(id obj) {
//
//    } successOne:^(id responseObject) {
//
//    NSLog(@"aaa %@",responseObject);
//
//        NSArray *array = responseObject[@"data"];
//
//        for (NSDictionary *dic in array) {
//            GoodManageModel *model = [GoodManageModel new];
//            [model setValuesForKeysWithDictionary:dic];
////            NSLog(@"%@",model);
//
//            [self.itemsArray addObject:model];
//
////            NSLog(@"%@--%@",self->_itemsArrName,self->_itemsArrImg );
//        }
//
//        [self.goodsListTableView reloadData];
//    } successZero:^(id responseObject) {
//
////        NSString *alterStr = responseObject[@"status"][@"error_desc"];
////         NSLog(@"bbb %@",responseObject);
//
////        if ([alterStr isEqualToString:@"Invalid session"]) {
////
////            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"登陆过期，请重新登录" preferredStyle:(UIAlertControllerStyleAlert)];
////            UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
////
////                LoginViewController *vc = [[LoginViewController alloc]init];
////                [self.navigationController pushViewController:vc animated:YES];
////            }];
////            [alert addAction:action];
////            [self presentViewController:alert animated:YES completion:nil];
////
////        }else{
////
////            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:alterStr preferredStyle:(UIAlertControllerStyleAlert)];
////            UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:(UIAlertActionStyleDefault) handler:nil];
////            [alert addAction:action];
////            [self presentViewController:alert animated:YES completion:nil];
////        }
//    } fail:^(NSError *error) {
//
//    }];
//}
//
//#pragma mark -- 按钮点击方法
//
//-(void)addGoods{
//
//}
//
////点击search的操作
//- (BOOL)textFieldShouldReturn:(UITextField *)textField{
//    NSLog(@"这里就是你要做的操作");
//    return YES;
//}
//
//
//#pragma mark -- lazy load
////- (NSMutableArray *)onceArray{
////    if (!_onceArray) {
////        _onceArray = [[NSMutableArray alloc] init];
////    }
////    return _onceArray;
////}
//
//-(NSMutableArray *)itemsArray{
//    if (!_itemsArray) {
//        self.itemsArray = [NSMutableArray arrayWithCapacity:13];
//    }
//    return _itemsArray;
//}
*/


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
