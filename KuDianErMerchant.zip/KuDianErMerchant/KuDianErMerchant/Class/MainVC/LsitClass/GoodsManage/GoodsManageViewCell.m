//
//  GoodsManageViewCell.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/19.
//  Copyright © 2018年 william. All rights reserved.
//

#import "GoodsManageViewCell.h"

@implementation GoodsManageViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.goodsImage = [MyUIClass makeUIImageWithFrame:CGRectMake(k_withBasedIphone6(10), k_withBasedIphone6(5), k_withBasedIphone6(50), k_withBasedIphone6(50)) andPicName:@"goodsimage"];
        
        
        self.goodsName_lab = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(65), k_withBasedIphone6(10), k_withBasedIphone6(95), k_withBasedIphone6(20)) andText:@"" andTextColor:Color(51, 51, 51) andFontSize:15.0 andAlignment:NSTextAlignmentCenter];
        _goodsName_lab.backgroundColor = [UIColor yellowColor];
        
        self.goods_sn_lab = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(65), k_withBasedIphone6(30), k_withBasedIphone6(95), k_withBasedIphone6(20)) andText:@"货号：10011331" andTextColor:Color(51, 51, 51) andFontSize:13.0 andAlignment:NSTextAlignmentCenter];
        _goods_sn_lab.backgroundColor = [UIColor purpleColor];
        
        //        UILabel *spend = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(160), k_withBasedIphone6(20), k_withBasedIphone6(50), k_withBasedIphone6(20)) andText:@"1240" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentCenter];
        
        self.shop_price_lab = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(210), k_withBasedIphone6(20), k_withBasedIphone6(55), k_withBasedIphone6(20)) andText:@"¥24.00" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentCenter];
        
        //        UILabel *spend2 = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(265), k_withBasedIphone6(20), k_withBasedIphone6(55), k_withBasedIphone6(20)) andText:@"11110" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentCenter];
        //
        //        UILabel *spend3 = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(320), k_withBasedIphone6(20), k_withBasedIphone6(50), k_withBasedIphone6(20)) andText:@"已上架" andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentCenter];
        
        [self addSubview:_goodsImage];
        [self addSubview:_goodsName_lab];
        [self addSubview:_goods_sn_lab];
        //        [self addSubview:spend];
        [self addSubview:_shop_price_lab];
        //        [self addSubview:spend2];
        //        [self addSubview:spend3];
        
    }
    return self;
}

-(void)setManageModel:(GoodManageModel *)manageModel{
    
    _goodsName_lab.text = manageModel.name;
    
}




- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
