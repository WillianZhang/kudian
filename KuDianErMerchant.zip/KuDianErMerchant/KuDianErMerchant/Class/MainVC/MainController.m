//
//  MainController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//

#import "MainController.h"
#import "NewsController.h"
#import "SettingController.h"
#import "SettingController.h"
#import "MemberController.h"
#import "CardManageController.h"
#import "ReimburseController.h"
#import "SetManageController.h"
#import "GoodsController.h"
#import "OrderListController.h"
#import "QrCodeViewController.h"
#import "SellCardController.h"
#import "SettleAccountsController.h"
#import "OptionalGoodsController.h"
#import "DFYSVP.h"
#import "LoginController.h"

@interface MainController ()<UITextFieldDelegate>

@property(nonatomic, strong) UIView * orderView;
@property(nonatomic, strong) UIView * memberView;

//计算器
@property(nonatomic,strong)UIView * tmpBtnView;//按钮view
@property(nonatomic,strong)UILabel * tmpLabel;//显示输入内容
@property(nonatomic,strong)UILabel * tmpLabel1;//显示输出结果
@property(nonatomic,strong)NSMutableArray * tmpArray;
@property(nonatomic,strong) UIButton *secureBtn;//显示隐藏的小眼睛
@property(nonatomic,strong) UIView *Fview;

@property (nonatomic ,strong) NSString *membersIdName;//非默认会员登陆的账号

@property(nonatomic, assign)BOOL isSelect;

@property(nonatomic ,strong) UIView *alertView;
@property(nonatomic ,strong) UITextField *memberLoginField;
@property(nonatomic ,strong) NSString * memberIdString;

@property(nonatomic ,strong) UIView *alertView_Qr;
@property(nonatomic ,strong) UITextField *memberLoginField_Qr;
@property(nonatomic ,strong) NSString * memberIdString_Qr;

@end

@implementation MainController


- (void)viewDidLoad {
    [super viewDidLoad];
     self.view.backgroundColor = Color(240, 240, 240);
   self.navigationController.navigationBar.barTintColor = Color(7, 196, 190);

    [self creatUI];
    
    //为导航栏添加左侧(暂时隐藏)
    UIBarButtonItem *left = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"changeHomeView"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStyleDone target:self action:@selector(changeMainView)];
    self.navigationItem.leftBarButtonItem = left;
    
    //为导航栏添加右侧按钮1
    UIBarButtonItem *right1 = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"set"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStyleDone target:self action:@selector(pushToSettingVC)];
    //为导航栏添加右侧按钮2
//    UIBarButtonItem *right2 = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"message"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStyleDone target:self action:@selector(pushToNewsVC)];
    NSArray *arr = [[NSArray alloc]initWithObjects:right1,nil];
    self.navigationItem.rightBarButtonItems = arr;
    
   
    //增加监听，当键盘出现或改变时收出消息
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    //增加监听，当键退出时收出消息
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
   
}

#pragma mark - 控件创建
-(void)creatUI{
    
    self.Fview = [MyUIClass makeUIViewWithFrame:CGRectMake(0, 0, k_withBasedIphone6(375), k_withBasedIphone6(80)) andBackColor:[UIColor whiteColor]];
    [self.view addSubview:_Fview];
    NSArray *headTitle = @[@"今日销售额",@"本日销售额",@"账户余额"];
    
    for (int i = 0; i < 3; i++) {
        
    UILabel *labTitle = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20)+k_withBasedIphone6(100)*i, k_withBasedIphone6(15), k_withBasedIphone6(85), k_withBasedIphone6(24)) andText:headTitle[i] andTextColor:Color(255, 255, 255) andFontSize:12.0 andAlignment:NSTextAlignmentCenter];
        [labTitle.layer setCornerRadius:12.0];
        [labTitle.layer setMasksToBounds:YES];
    labTitle.backgroundColor = Color(7, 196, 190);
    [_Fview addSubview:labTitle];
        
        UILabel *labelData = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20)+k_withBasedIphone6(100)*i, k_withBasedIphone6(45), k_withBasedIphone6(85), k_withBasedIphone6(24)) andText:@"******" andTextColor:Color(102, 102, 102) andFontSize:14.0 andAlignment:NSTextAlignmentCenter];
        labelData.tag = 200+i;
        [_Fview addSubview:labelData];
    }
    
    CGRect secureBtnFrame = CGRectMake(k_withBasedIphone6(330), k_withBasedIphone6(45), k_withBasedIphone6(20), k_withBasedIphone6(12));
    self.secureBtn = [MyUIClass makeImageButtonWithFrame:secureBtnFrame andType:UIButtonTypeCustom andImageName:@"close_eye" andTarget:self andSelector:@selector(changeEye:) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [self.secureBtn setEnlargeEdgeWithTop:20 right:10 bottom:20 left:20];
    [_Fview addSubview:_secureBtn];
    
    
  
    //没计算器页面
    self.orderView = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(95), k_withBasedIphone6(375), k_withBasedIphone6(458)) andBackColor:Color(240, 238, 241)];
    
    [self.view addSubview:_orderView];
    
    UIView *btnView = [MyUIClass makeUIViewWithFrame:CGRectMake(0, 0, k_withBasedIphone6(375), k_withBasedIphone6(266)) andBackColor:[UIColor whiteColor]];
    [_orderView addSubview:btnView];
    
    NSArray *orderList = @[@"会员管理",@"商品管理",@"订单管理",@"经营数据",@"卡管理",@"店铺推广",@"退货管理",@"设置"];
    NSArray *imageArr = @[@"memberManage_h",@"goodsManage",@"orderManage",@"businessData_h",@"cardManage_h",@"storePromotion_h",@"backGoods_h",@"setting_h"];
    for (int i = 0; i < 8; i++) {
        
        UIButton *btn = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(60)+ i%3 *k_withBasedIphone6(100), k_withBasedIphone6(10)+ i/3 *k_withBasedIphone6(88), k_withBasedIphone6(40), k_withBasedIphone6(40)) andType:UIButtonTypeCustom andImageName:imageArr[i] andTarget:self andSelector:@selector(pushToList:) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
        btn.tag = i;
        [btnView addSubview:btn];
        
        UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(40)+ i%3 *k_withBasedIphone6(100), k_withBasedIphone6(50)+ i/3 *k_withBasedIphone6(88), k_withBasedIphone6(80), k_withBasedIphone6(20)) andText:orderList[i] andTextColor:Color(102, 102, 102) andFontSize:14.0 andAlignment:NSTextAlignmentCenter];
        [btnView addSubview:label];
    }

    
    UIView *lineL = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(290), k_withBasedIphone6(150), 2) andBackColor:Color(7, 196, 190)];
    UILabel *lab = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(150), k_withBasedIphone6(275), k_withBasedIphone6(75), 30) andText:@"订单结账" andTextColor:Color(102, 102, 102) andFontSize:16.0 andAlignment:NSTextAlignmentCenter];
    UIView *lineR = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(225), k_withBasedIphone6(290), k_withBasedIphone6(150), 2) andBackColor:Color(7, 196, 190)];
    [_orderView addSubview:lineL];
    [_orderView addSubview:lineR];
    [_orderView addSubview:lab];
    
    //扫码按钮
    UIButton *QrButton = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(70), k_withBasedIphone6(330), k_withBasedIphone6(80), k_withBasedIphone6(80)) andType:UIButtonTypeCustom andImageName:@"Qr_btn" andTarget:self andSelector:@selector(pushToQrVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [_orderView addSubview:QrButton];
    
    //自选订单按钮
    UIButton *orderBtn = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(225), k_withBasedIphone6(330), k_withBasedIphone6(80), k_withBasedIphone6(80)) andType:UIButtonTypeCustom andImageName:@"optional_btn" andTarget:self andSelector:@selector(pushToOrderVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [_orderView addSubview:orderBtn];
    
    

    
    //有计算器页面
    self.memberView = [MyUIClass makeUIViewWithFrame:CGRectMake(0, k_withBasedIphone6(95), k_withBasedIphone6(375), k_withBasedIphone6(458)) andBackColor:[UIColor whiteColor]];
    _memberView.hidden = YES;
    [self.view addSubview:_memberView];
    NSArray *memberList = @[@"会员管理",@"卡管理",@"订单管理",@"经营数据",@"商品管理",@"退款管理",@"设置"];
    NSArray *imageName = @[@"memberManage_h",@"cardManage_h",@"orderManage_h",@"businessData_h",@"goodsManage_h",@"refund_h",@"setting_h"];
    for (int i = 0; i < 7; i++) {
        
        UIButton *btn = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(45)+ i%4*k_withBasedIphone6(80), k_withBasedIphone6(10)+i/4*k_withBasedIphone6(80), k_withBasedIphone6(40), k_withBasedIphone6(40)) andType:UIButtonTypeCustom andImageName:imageName[i] andTarget:self andSelector:@selector(click:) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
        [btn setEnlargeEdgeWithTop:0 right:k_withBasedIphone6(10) bottom:k_withBasedIphone6(20) left:k_withBasedIphone6(10)];
             btn.tag = 100+i;
        [_memberView addSubview:btn];
        
        UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(30)+  i%4*k_withBasedIphone6(80), k_withBasedIphone6(50)+i/4*k_withBasedIphone6(80), k_withBasedIphone6(70), k_withBasedIphone6(20)) andText:memberList[i] andTextColor:Color(102, 102, 102) andFontSize:13.0 andAlignment:NSTextAlignmentCenter];
        [_memberView addSubview:label];
    }
    
    //计算器
    UIImageView *imageV = [MyUIClass makeUIImageWithFrame:CGRectMake(0, k_withBasedIphone6(160),k_withBasedIphone6(375), k_withBasedIphone6(310)) andPicName:@"calculatorBack"];//298屏幕大的适配 下面留白边
    imageV.userInteractionEnabled = YES;
    [_memberView addSubview:imageV];

    self.tmpArray = [NSMutableArray arrayWithObjects:@"1",@"2",@"3",@"＋",@"4",@"5",@"6",@"－",@"7",@"8",@"9",@"×",@"AC",@"0",@".",@"÷",@"=", nil];
    //     self.tmpArray = [NSMutableArray arrayWithObjects:@"1",@"2",@"＋",@"3",@"4",@"－",@"5",@"6",@"×",@"7",@"8",@"÷",@"9",@"0",@"AC",@".",@"=", nil];
    
    
    
    UIImageView *tmpView = [MyUIClass makeUIImageWithFrame:CGRectMake(k_withBasedIphone6(30), k_withBasedIphone6(10),k_withBasedIphone6(315), k_withBasedIphone6(70)) andPicName:@"labelBack"];
    [imageV addSubview:tmpView];
    
    self.tmpLabel = [[UILabel alloc]initWithFrame:CGRectMake(k_withBasedIphone6(10), 0, k_withBasedIphone6(295), k_withBasedIphone6(45))];
    
    [self.tmpLabel setText:@"0"];
    
    [self.tmpLabel setBackgroundColor:[UIColor clearColor]];
    
    [self.tmpLabel setTextColor:[UIColor blackColor]];
    
    [self.tmpLabel setFont:[UIFont systemFontOfSize:32.0]];

    self.tmpLabel.adjustsFontSizeToFitWidth = YES;
    
    [self.tmpLabel setTextAlignment:NSTextAlignmentRight];
    
    [tmpView addSubview:self.tmpLabel];
    
    self.tmpLabel1 = [[UILabel alloc]initWithFrame:CGRectMake(k_withBasedIphone6(10), k_withBasedIphone6(45), k_withBasedIphone6(295), k_withBasedIphone6(22))];
    
    [self.tmpLabel1 setFont:[UIFont systemFontOfSize:25.0]];
    [self.tmpLabel1 setBackgroundColor:[UIColor clearColor]];
    [self.tmpLabel1 setTextColor:[UIColor blackColor]];

    self.tmpLabel1.adjustsFontSizeToFitWidth = YES;
    
    [self.tmpLabel1 setTextAlignment:NSTextAlignmentRight];
    
    [tmpView addSubview:self.tmpLabel1];
    
    
    
    self.tmpBtnView = [[UIView alloc]initWithFrame:CGRectMake(0, k_withBasedIphone6(90),Screen_W , k_withBasedIphone6(208))];
    
    [self.tmpBtnView setBackgroundColor:[UIColor clearColor]];
    
    [imageV addSubview:self.tmpBtnView];
    
    for (int i = 0; i<self.tmpArray.count; i++)
    {
        UIButton * tmpBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        
        
        if (i == 16) {
            [tmpBtn setFrame:CGRectMake(k_withBasedIphone6(30)+i%4 * k_withBasedIphone6(80), i/4*k_withBasedIphone6(40), k_withBasedIphone6(315), k_withBasedIphone6(35))];
            
        }else{
            
            [tmpBtn setFrame:CGRectMake(k_withBasedIphone6(30)+i%4 * k_withBasedIphone6(80), i/4*k_withBasedIphone6(40), k_withBasedIphone6(75), k_withBasedIphone6(35))];
        }
        
        
        
        [tmpBtn setTitle:[NSString stringWithFormat:@"%@",self.tmpArray[i]] forState:UIControlStateNormal];
        
        [tmpBtn.layer setCornerRadius:4.0];
        
        [tmpBtn.layer setMasksToBounds:YES];
        
        [tmpBtn setBackgroundColor:Color(238, 238, 238)];
        [tmpBtn setTitleColor:Color(51, 51, 51) forState:UIControlStateNormal];
        
        [tmpBtn setTag:i];
        
        [tmpBtn addTarget:self action:@selector(setBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.tmpBtnView addSubview:tmpBtn];
    }
    
    
    
    //最下面tabbar
    UIView *Tview = [MyUIClass makeUIViewWithFrame:CGRectMake(0, Screen_H-IPHONE_X_NAV_HEIGHT-k_withBasedIphone6(50), k_withBasedIphone6(375), k_withBasedIphone6(50)) andBackColor:[UIColor whiteColor]];
    [self.view addSubview:Tview];
    
    UIButton *sellcard = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(0), k_withBasedIphone6(0), k_withBasedIphone6(187), k_withBasedIphone6(50)) andType:UIButtonTypeCustom andTitle:@" 售卖储值卡" andTitleFontSize:16.0 andImageName:@"totalcount" andBackColor:Color(7, 196, 190) andTarget:self andSelector:@selector(pushToSellCardVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [Tview addSubview:sellcard];
    
    UIButton *settle_accountsBtn = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(188), k_withBasedIphone6(0), k_withBasedIphone6(187), k_withBasedIphone6(50)) andType:UIButtonTypeCustom andTitle:@" 结账" andTitleFontSize:16.0 andImageName:@"soldcard" andBackColor:Color(218, 177, 121) andTarget:self andSelector:@selector(pushToSettleAccountsVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [Tview addSubview:settle_accountsBtn];

     [self creatOptionalAlertView];
     [self creatQrAlertView];
    
}

-(void)creatOptionalAlertView{
    //提示会员登陆页面--自选
    self.alertView = [[UIView alloc]initWithFrame:CGRectMake(Screen_W, 0 , Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT)];
    self.alertView.backgroundColor = [UIColor colorWithWhite:0.f alpha:0.5];
    [self.view addSubview:_alertView];
    
    UIView *backView = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(35), Screen_H/2, k_withBasedIphone6(305), k_withBasedIphone6(165)) andBackColor:[UIColor whiteColor]];
    backView.layer.masksToBounds = YES;
    backView.layer.cornerRadius = 8;
    [_alertView addSubview:backView];
    
    UIView *bgcolor = [MyUIClass makeUIViewWithFrame:CGRectMake(0, 0, k_withBasedIphone6(305), k_withBasedIphone6(8)) andBackColor:Color(7, 196, 190)];
    [backView addSubview:bgcolor];
    
    UILabel *titleLab = [[UILabel alloc]initWithFrame:CGRectMake(0, k_withBasedIphone6(20), k_withBasedIphone6(305), k_withBasedIphone6(15))];
    titleLab.textAlignment = NSTextAlignmentCenter;
    titleLab.text = @"会员码";
    [backView addSubview:titleLab];
    
    //会员登陆框
    self.memberLoginField = [MyUIClass simpleTextFieldWithFrame:CGRectMake(k_withBasedIphone6(44), k_withBasedIphone6(55), k_withBasedIphone6(225), k_withBasedIphone6(20)) andPlaceHolder:@"请输入会员码" andClearBtnMode:UITextFieldViewModeWhileEditing andBackColor:[UIColor whiteColor] andFontSize:14.0];
    //    _memberLoginField.keyboardType = UIKeyboardTypeDefault;
    _memberLoginField.returnKeyType = UIReturnKeyDone;
    _memberLoginField.delegate = self;
    [_memberLoginField addTarget:self action:@selector(textFieldChanged:) forControlEvents:UIControlEventEditingChanged];
    [backView addSubview:_memberLoginField];
    
    UIView *bgcolorline = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(37),k_withBasedIphone6(75), k_withBasedIphone6(225), k_withBasedIphone6(1)) andBackColor:[UIColor lightGrayColor]];
    [backView addSubview:bgcolorline];
    
    UILabel *labDescripe = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(38), k_withBasedIphone6(82), k_withBasedIphone6(225), k_withBasedIphone6(30)) andText:@"*本店会员请输入会员码并点击确认，非会员请直接点击取消" andTextColor:Color(7, 196, 190) andFontSize:10.0 andAlignment:NSTextAlignmentLeft];
    labDescripe.numberOfLines = 0;
    [backView addSubview:labDescripe];
    
    UIButton *cancelBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(0, k_withBasedIphone6(125), k_withBasedIphone6(152), k_withBasedIphone6(30)) andType:UIButtonTypeCustom andBackColor:[UIColor whiteColor] andTitle:@"取消" andTitleFontSize:15.0 andTitleColor:Color(50, 50, 50) andTarget:self andSelector:@selector(cancelClick) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    
    UIView *bgmiddleline = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(152),k_withBasedIphone6(130), k_withBasedIphone6(1), k_withBasedIphone6(20)) andBackColor:[UIColor lightGrayColor]];
    [backView addSubview:bgmiddleline];
    
    UIButton *defaultBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(153), k_withBasedIphone6(125), k_withBasedIphone6(152), k_withBasedIphone6(30)) andType:UIButtonTypeCustom andBackColor:[UIColor whiteColor] andTitle:@"确定" andTitleFontSize:15.0 andTitleColor:Color(50, 50, 50) andTarget:self andSelector:@selector(defaultClick) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    
    [backView addSubview:cancelBtn];
    [backView addSubview:defaultBtn];
    
}

-(void)creatQrAlertView{
    //提示会员登陆页面--Qr
    self.alertView_Qr = [[UIView alloc]initWithFrame:CGRectMake(-Screen_W, 0 , Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT)];
    self.alertView_Qr.backgroundColor = [UIColor colorWithWhite:0.f alpha:0.5];
    [self.view addSubview:_alertView_Qr];
    
    UIView *backView = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(35), Screen_H/2, k_withBasedIphone6(305), k_withBasedIphone6(165)) andBackColor:[UIColor whiteColor]];
    backView.layer.masksToBounds = YES;
    backView.layer.cornerRadius = 8;
    [_alertView_Qr addSubview:backView];
    
    UIView *bgcolor = [MyUIClass makeUIViewWithFrame:CGRectMake(0, 0, k_withBasedIphone6(305), k_withBasedIphone6(8)) andBackColor:Color(7, 196, 190)];
    [backView addSubview:bgcolor];
    
    UILabel *titleLab = [[UILabel alloc]initWithFrame:CGRectMake(0, k_withBasedIphone6(20), k_withBasedIphone6(305), k_withBasedIphone6(15))];
    titleLab.textAlignment = NSTextAlignmentCenter;
    titleLab.text = @"会员码";
    [backView addSubview:titleLab];
    
    //会员登陆框
    self.memberLoginField_Qr = [MyUIClass simpleTextFieldWithFrame:CGRectMake(k_withBasedIphone6(44), k_withBasedIphone6(55), k_withBasedIphone6(225), k_withBasedIphone6(20)) andPlaceHolder:@"请输入会员码" andClearBtnMode:UITextFieldViewModeWhileEditing andBackColor:[UIColor whiteColor] andFontSize:14.0];
    //    _memberLoginField.keyboardType = UIKeyboardTypeDefault;
    _memberLoginField_Qr.returnKeyType = UIReturnKeyDone;
    _memberLoginField_Qr.delegate = self;
    [_memberLoginField_Qr addTarget:self action:@selector(textFieldChanged_Qr:) forControlEvents:UIControlEventEditingChanged];
    [backView addSubview:_memberLoginField_Qr];
    
    UIView *bgcolorline = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(37),k_withBasedIphone6(75), k_withBasedIphone6(225), k_withBasedIphone6(1)) andBackColor:[UIColor lightGrayColor]];
    [backView addSubview:bgcolorline];
    
    UILabel *labDescripe = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(38), k_withBasedIphone6(82), k_withBasedIphone6(225), k_withBasedIphone6(30)) andText:@"*本店会员请输入会员码并点击确认，非会员请直接点击取消" andTextColor:Color(7, 196, 190) andFontSize:10.0 andAlignment:NSTextAlignmentLeft];
    labDescripe.numberOfLines = 0;
    [backView addSubview:labDescripe];
    
    UIButton *cancelBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(0, k_withBasedIphone6(125), k_withBasedIphone6(152), k_withBasedIphone6(30)) andType:UIButtonTypeCustom andBackColor:[UIColor whiteColor] andTitle:@"取消" andTitleFontSize:15.0 andTitleColor:Color(50, 50, 50) andTarget:self andSelector:@selector(cancelClick_Qr) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    
    UIView *bgmiddleline = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(152),k_withBasedIphone6(130), k_withBasedIphone6(1), k_withBasedIphone6(20)) andBackColor:[UIColor lightGrayColor]];
    [backView addSubview:bgmiddleline];
    
    UIButton *defaultBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(153), k_withBasedIphone6(125), k_withBasedIphone6(152), k_withBasedIphone6(30)) andType:UIButtonTypeCustom andBackColor:[UIColor whiteColor] andTitle:@"确定" andTitleFontSize:15.0 andTitleColor:Color(50, 50, 50) andTarget:self andSelector:@selector(defaultClick_Qr) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    
    [backView addSubview:cancelBtn];
    [backView addSubview:defaultBtn];
}


#pragma mark - 按钮点击事件Action
-(void)cancelClick{
    say(@"自选取消");
    DFYSVPLoading(@"请稍后...", NO);
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    //取出默认会员账号登陆数据
    NSString *defaultMemberToken = [userDefault objectForKey:@"defaultMember_token"];
    NSString *defaultMemberUser_id = [userDefault objectForKey:@"defaultMember_user_id"];
    //存会员登陆id 与购物车同步使用判断事哪个会员买的商品
    //将默认会员登陆信息存入，其他页面使用到
    [userDefault setObject:defaultMemberToken forKey:@"member_token"];
    [userDefault setObject:defaultMemberUser_id forKey:@"member_user_id"];
    [userDefault synchronize];
    
    [DFYSVP dismiss];
    
    OptionalGoodsController *vc = [[OptionalGoodsController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    
    self.alertView.frame = CGRectMake(Screen_W, 0 , Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT);
}

-(void)defaultClick{
    say(@"自选确认%@",_memberIdString);
    if (_memberIdString == nil) {
        
        [self showAlertWithTitle:@"温馨提示" andMessage:@"输入的会员码为空，如没有会员码请直接点击取消" andActionTitle:@"确认" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }else{
        BOOL phone = [MyUIClass valiMobile:_memberIdString];
        
        if (phone == YES) {
            
            [self UnDefaultmemberLoginin:_memberIdString];
            
        }else{
            
            [self showAlertWithTitle:@"温馨提示" andMessage:@"你输入的电话号码有误" andActionTitle:@"确认" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        }
        
    }
}

-(void)cancelClick_Qr{
    say(@"自选取消");
    DFYSVPLoading(@"请稍后...", NO);
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    //取出默认会员账号登陆数据
    NSString *defaultMemberToken = [userDefault objectForKey:@"defaultMember_token"];
    NSString *defaultMemberUser_id = [userDefault objectForKey:@"defaultMember_user_id"];
    //        //存会员登陆id 与购物车同步使用判断事哪个会员买的商品
    //将默认会员登陆信息存入，其他页面使用到
    [userDefault setObject:defaultMemberToken forKey:@"member_token"];
    [userDefault setObject:defaultMemberUser_id forKey:@"member_user_id"];
    [userDefault synchronize];
    
    [DFYSVP dismiss];
    
    QrCodeViewController *vc = [[QrCodeViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    
    self.alertView_Qr.frame = CGRectMake(-Screen_W, 0 , Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT);
}

-(void)defaultClick_Qr{
    say(@"自选确认%@",_memberIdString_Qr);
    if (_memberIdString_Qr == nil) {
        
        [self showAlertWithTitle:@"温馨提示" andMessage:@"输入的会员码为空，如没有会员码请直接点击取消" andActionTitle:@"确认" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }else{
        
        BOOL phone = [MyUIClass valiMobile:_memberIdString_Qr];
        
        if (phone == YES) {
            
            [self UnDefaultmemberLoginin:_memberIdString_Qr];
            
        }else{
            
            [self showAlertWithTitle:@"温馨提示" andMessage:@"你输入的电话号码有误" andActionTitle:@"确认" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        }
    }
}

//首页最上的密文数据
-(void)changeEye:(UIButton *)btn{
    
    btn.selected = !btn.selected;
    
    if (btn.selected) {
        [self.secureBtn setImage:[UIImage imageNamed:@"open_eye"] forState:UIControlStateNormal];
        
        for (int i = 0; i < 3; i++) {
            
            UILabel *label = (UILabel *)[self.Fview viewWithTag:200+i];
            label.text = @"127638";
            
        }
        

    }else{
        [self.secureBtn setImage:[UIImage imageNamed:@"close_eye"] forState:UIControlStateNormal];
        for (int i = 0; i < 3; i++) {
            
            UILabel *label = (UILabel *)[self.Fview viewWithTag:200+i];
            label.text = @"******";
            
        }
       
    }
}

//切换计算器与无计算器页面
-(void)changeMainView{
    
    _isSelect = !_isSelect;
    
    if (_isSelect) {
        
        self.orderView.hidden = YES;
        self.memberView.hidden = NO;
       
    }else{
       
        self.memberView.hidden = YES;
        self.orderView.hidden = NO;
    }

}

#pragma mark - 键盘高度监听事件
//当键盘出现或改变时调用
- (void)keyboardWillShow:(NSNotification *)aNotification {


    //获取键盘的高度
    NSDictionary *userInfo = [aNotification userInfo];
    NSValue *aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [aValue CGRectValue];
    int height = keyboardRect.size.height;
    NSLog(@"键盘高度监听事件%d",height);


    self.alertView.frame =  CGRectMake(self.alertView.frame.origin.x, - height, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT);
    self.alertView_Qr.frame = CGRectMake(self.alertView_Qr.frame.origin.x, - height, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT);

}
//当键退出时调用
- (void)keyboardWillHide:(NSNotification *)aNotification{
    LLog(@"当键退出时调用");
    self.alertView.frame = CGRectMake(self.alertView.frame.origin.x,0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT);
    self.alertView_Qr.frame = CGRectMake(self.alertView_Qr.frame.origin.x, 0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT);
}

//监听减现输入框中现金变化 计算付款金额  --- c出现下面支付方式
- (void)textFieldChanged:(UITextField*)textField{

    self.memberIdString = textField.text;
    

}
- (void)textFieldChanged_Qr:(UITextField*)textField{
    
    self.memberIdString_Qr = textField.text;
    
    
}



//键盘Return按键回调
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    NSLog(@"键盘事件");
    [_memberLoginField resignFirstResponder];
    [_memberLoginField_Qr resignFirstResponder];
    return YES;
}

#pragma mark - 点击跳转事件

-(void)pushToNewsVC{
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    //改变返回按钮颜色
//    self.navigationController.navigationBar.tintColor = Color(7, 196, 190);
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    NewsController *vc = [[NewsController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)pushToSettingVC{
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    //改变返回按钮颜色
   self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    SettingController *vc = [[SettingController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    
}

//售卡
-(void)pushToSellCardVC{
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    SellCardController *vc = [[SellCardController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

//结账
-(void)pushToSettleAccountsVC{
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    SettleAccountsController *vc  = [[SettleAccountsController alloc ] init];
    [self.navigationController pushViewController:vc animated:YES];
    
}

#pragma mark - 无计算器会员列表点击跳转
//订单页面九点击按钮
-(void)pushToList:(UIButton *)sender{
    
    if (sender.tag == 1) {
        GoodsController *goods = [[GoodsController alloc]init];
       [self.navigationController pushViewController:goods animated:YES];
        
    }else if (sender.tag == 2){

        OrderListController *vc = [[OrderListController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];

    }else{
        
        [self showAlertWithTitle:@"提示" andMessage:@"系统功能开发中" andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
    }
    
    
//    if (sender.tag == 0) {
//
//        MemberController * memberVC = [[MemberController alloc]init];
//        [self.navigationController pushViewController:memberVC animated:YES];
//
//    }else if (sender.tag == 1){
//
//        GoodsController *goods = [[GoodsController alloc]init];
//        [self.navigationController pushViewController:goods animated:YES];
//
//    }else if (sender.tag == 2){
//
//        OrderListController *vc = [[OrderListController alloc]init];
//        [self.navigationController pushViewController:vc animated:YES];
//
//    }else if (sender.tag == 3){
//
//    }else if (sender.tag == 4){
//
//        CardManageController * cardManageVC = [[CardManageController alloc]init];
//        [self.navigationController pushViewController:cardManageVC animated:YES];
//
//    }else if (sender.tag == 5){
//
//    }else if (sender.tag == 6){
//
//    }else{
//        SetManageController * setManageVC = [[SetManageController alloc]init];
//        [self.navigationController pushViewController:setManageVC animated:YES];
//    }
}

#pragma mark - 带计算器会员版列表按钮跳转
-(void)click:(UIButton *)sender{
    
    if (sender.tag == 100) {
//        MemberController * memberVC = [[MemberController alloc]init];
//    [self.navigationController pushViewController:memberVC animated:YES];
        [self showAlertWithTitle:@"提示" andMessage:@"系统功能开发中" andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }else if (sender.tag == 101){
        
//        CardManageController * cardManageVC = [[CardManageController alloc]init];
//        [self.navigationController pushViewController:cardManageVC animated:YES];
         [self showAlertWithTitle:@"提示" andMessage:@"系统功能开发中" andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }else if (sender.tag == 105){
        
//        ReimburseController * reimburseVC = [[ReimburseController alloc]init];
//        [self.navigationController pushViewController:reimburseVC animated:YES];
         [self showAlertWithTitle:@"提示" andMessage:@"系统功能开发中" andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }else if (sender.tag == 106){
        
//        SetManageController * setManageVC = [[SetManageController alloc]init];
//        [self.navigationController pushViewController:setManageVC animated:YES];
         [self showAlertWithTitle:@"提示" andMessage:@"系统功能开发中" andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }else{
        
        
        [self showAlertWithTitle:@"提示" andMessage:@"如需此项服务请开启订单管理功能" andActionTitle:@"开启功能" andactionBlock:^{
            say(@"开启功能");
            SetManageController * setManageVC = [[SetManageController alloc]init];
            [self.navigationController pushViewController:setManageVC animated:YES];
            
        } andActionCancelTitle:@"取消" andActionCancelBlock:nil andBool:YES];
      
    }

}

//扫码订单
-(void)pushToQrVC{
  
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];

    
    [UIView animateWithDuration:0.5 animations:^{
        self.alertView_Qr.frame = CGRectMake(0, 0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT);
    }];
    
   
    //生成提示框 提示会员登陆
    //[self creatTextFiledAlertQr];
    
}

//自选订单
-(void)pushToOrderVC{

    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];

    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
//CGRectMake(k_withBasedIphone6(375), k_withBasedIphone6(320), k_withBasedIphone6(275), k_withBasedIphone6(120))
    
    [UIView animateWithDuration:0.5 animations:^{
       self.alertView.frame = CGRectMake(0, 0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT);
    }];


    //生成提示框 提示会员登陆
    //[self creatTextFiledAlert];
}



//生成带有输入框的提示框
-(void)creatTextFiledAlertQr{
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"会员请输入会员码并点击确认，非会员请点击取消" preferredStyle:(UIAlertControllerStyleAlert)];
    //UIAlertControllerStyleActionSheet 在底部出现
    
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"请输入会员码";
        
        // 如果要监听UITextField开始、结束、改变状态，则需要添加监听代码
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(alertTextFieldDidChangeQr:) name:UITextFieldTextDidChangeNotification object:textField];
    }];
    
    //按钮title：名字style：样式UIAlertActionStyleDestructive重置   handler：点击按钮执行的代码
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {
        //say(@"点击取消");
        
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        //取出默认会员账号登陆数据
        NSString *defaultMemberToken = [userDefault objectForKey:@"defaultMember_token"];
        NSString *defaultMemberUser_id = [userDefault objectForKey:@"defaultMember_user_id"];
        //        //存会员登陆id 与购物车同步使用判断事哪个会员买的商品
        //将默认会员登陆信息存入，其他页面使用到
        [userDefault setObject:defaultMemberToken forKey:@"member_token"];
        [userDefault setObject:defaultMemberUser_id forKey:@"member_user_id"];
        [userDefault synchronize];
        
        QrCodeViewController *vc = [[QrCodeViewController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
        
        
        
    }];
    
    UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
        //say(@"点击确认进行新账号书记解析%@",self->_membersIdName);
        //从新登陆新号获取新会员token和编号
        [self UnDefaultmemberLogininQr:self->_membersIdName];
        
    }];
    
    [alertController addAction:cancelAction];
    [alertController addAction:defaultAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
}
//有输入框提示框的输入监测
- (void)alertTextFieldDidChangeQr:(NSNotification *)notification{
    UIAlertController *alertController = (UIAlertController *)self.presentedViewController;
    if (alertController) {
        
        // 监测的lisn默认是数组格式 下标为1 的是添加了监听事件 也是最后一个AlertController.textField.lastObject
        //UITextField *lisen = alertController.textFields[1];
        UITextField *lisen = alertController.textFields.firstObject;
        say(@"监听Qr%@",lisen.text);
        
    }
}

//生成带有输入框的提示框
-(void)creatTextFiledAlert{
  
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"会员请输入会员码并点击确认，非会员请点击取消" preferredStyle:(UIAlertControllerStyleAlert)];
    //UIAlertControllerStyleActionSheet 在底部出现
  
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"请输入会员码";

        // 如果要监听UITextField开始、结束、改变状态，则需要添加监听代码
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(alertTextFieldDidChange:) name:UITextFieldTextDidChangeNotification object:textField];
    }];
    
    //按钮title：名字style：样式UIAlertActionStyleDestructive重置   handler：点击按钮执行的代码
  
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {
        //say(@"点击取消");
        
//        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
//        //取出默认会员账号登陆数据
//        NSString *defaultMemberToken = [userDefault objectForKey:@"defaultMember_token"];
//        NSString *defaultMemberUser_id = [userDefault objectForKey:@"defaultMember_user_id"];
////        //存会员登陆id 与购物车同步使用判断事哪个会员买的商品
//        //将默认会员登陆信息存入，其他页面使用到
//        [userDefault setObject:defaultMemberToken forKey:@"member_token"];
//        [userDefault setObject:defaultMemberUser_id forKey:@"member_user_id"];
//        [userDefault synchronize];
        
        OptionalGoodsController *vc = [[OptionalGoodsController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];

        
        
    }];
    
    UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
        say(@"点击确认进行新账号书记解析%@",self->_membersIdName);
        //从新登陆新号获取新会员token和编号
        //[self UnDefaultmemberLoginin:self->_membersIdName];
    }];
    
    [alertController addAction:cancelAction];
    [alertController addAction:defaultAction];

    [self presentViewController:alertController animated:YES completion:nil];
}
//有输入框提示框的输入监测
- (void)alertTextFieldDidChange:(NSNotification *)notification{
    UIAlertController *alertController = (UIAlertController *)self.presentedViewController;
    if (alertController) {
        
        // 监测的lisn默认是数组格式 下标为1 的是添加了监听事件 也是最后一个AlertController.textField.lastObject
        //UITextField *lisen = alertController.textFields[1];
        UITextField *lisen = alertController.textFields.firstObject;
        say(@"监听坚挺%@",lisen.text);
        
    }
}


//封装提示框
-(void)creatAlertWithTitle:(NSString *)title andMessage:(NSString *)message andActionTitle:(NSString *)actionDefault andStyle:(UIAlertActionStyle )DefaultStyle andCancelActionTitle:(NSString *)actionCancel andCancelStyle:(UIAlertActionStyle )CancelStyle Default:(void (^)(void))fault Cancel:(void (^)(void))cancel{
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:actionDefault style:DefaultStyle handler:^(UIAlertAction * _Nonnull action) {
        fault();
    }];
    UIAlertAction *action2 = [UIAlertAction actionWithTitle:actionCancel style:CancelStyle handler:^(UIAlertAction * _Nonnull action) {
        cancel();
    }];
    
    [alert addAction:action1];
    [alert addAction:action2];
    
    [self presentViewController:alert animated:YES completion:nil];
}



#pragma mark - 创建计算器
-(void)creat_simple_calculator{
    
}

-(void)setBtnAction:(UIButton *)sender
{
    
    if(self.tmpLabel1.text.length > 0)
    {
        
        [self.tmpLabel setText:@"0"];
        
        [self.tmpLabel1 setText:@""];
        
    }
    if(sender.tag == 0 || sender.tag == 1 || sender.tag == 2 || sender.tag == 4 || sender.tag == 5 || sender.tag == 6 || sender.tag == 8 || sender.tag == 9 || sender.tag == 10 || sender.tag == 13)
    {
        if([self.tmpLabel.text isEqualToString:@"0"])
        {
            [self.tmpLabel setText:[NSString stringWithFormat:@"%@",self.tmpArray[sender.tag]]];
        }
        else
        {
            [self.tmpLabel setText:[NSString stringWithFormat:@"%@%@",self.tmpLabel.text ,self.tmpArray[sender.tag]]];
        }
    }
    else if(sender.tag == 14)
    {
        [self.tmpLabel setText:[NSString stringWithFormat:@"%@%@",self.tmpLabel.text ,self.tmpArray[sender.tag]]];
    }
    else if (sender.tag == 3 || sender.tag == 7 || sender.tag == 11 || sender.tag == 15)
    {
        if([self.tmpLabel.text hasSuffix:@"＋"] || [self.tmpLabel.text hasSuffix:@"－"] || [self.tmpLabel.text hasSuffix:@"×"] || [self.tmpLabel.text hasSuffix:@"÷"])
        {
            [self.tmpLabel setText:[NSString stringWithFormat:@"%@",self.tmpLabel.text]];
        }
        else
        {
            [self.tmpLabel setText:[NSString stringWithFormat:@"%@%@",self.tmpLabel.text ,self.tmpArray[sender.tag]]];
        }
    }
    else if (sender.tag == 12)
    {
        
        //            NSString *cccc = [self.tmpLabel.text substringToIndex:[self.tmpLabel.text length] - 1];
        //            [self.tmpLabel setText:cccc];
        [self.tmpLabel setText:@"0"];
        
        [self.tmpLabel1 setText:@""];
    }
    else
    {
        
        [self resultStr:self.tmpLabel.text];
    }
    
}


-(NSString*) removeLastOneChar:(NSString*)origin
{
    NSString* cutted;
    if([origin length] > 0){
        cutted = [origin substringToIndex:([origin length]-1)];// 去掉最后一个","
    }else{
        cutted = origin;
    }
    return cutted;
}


-(void)resultStr:(NSString *)str
{
    
    NSMutableArray * tmpArray = [NSMutableArray array];
    
    for (int i = 0; i<str.length; i++)
    {
        NSString *string2 = [str substringWithRange:NSMakeRange(i, 1)];
        
        if([string2 isEqualToString:@"＋"] || [string2 isEqualToString:@"－"] || [string2 isEqualToString:@"÷"] || [string2 isEqualToString:@"×"])
        {
            
            [tmpArray addObject:string2];
        }
        else
        {
            
            if(tmpArray.count >0)
            {
                NSInteger tmpCount = tmpArray.count;
                
                NSString * tmpStr = [NSString stringWithFormat:@"%@",tmpArray[tmpCount-1]];
                
                if([tmpStr isEqualToString:@"＋"] || [tmpStr isEqualToString:@"－"] || [tmpStr isEqualToString:@"÷"] || [tmpStr isEqualToString:@"×"])
                {
                    
                    [tmpArray addObject:string2];
                    
                    
                }else
                {
                    NSString * str = [NSString stringWithFormat:@"%@%@",tmpArray[tmpCount-1],string2];
                    
                    [tmpArray replaceObjectAtIndex:tmpCount-1 withObject:str];
                }
            }
            else
            {
                [tmpArray addObject:string2];
            }
            
        }
        
    }
    
    
    if([tmpArray containsObject:@"＋"] && ![tmpArray containsObject:@"－"] && ![tmpArray containsObject:@"×"] && ![tmpArray containsObject:@"÷"])
    {
        [self setOnlySum:tmpArray];
        
    }
    else if (![tmpArray containsObject:@"＋"] && [tmpArray containsObject:@"－"] && ![tmpArray containsObject:@"×"] && ![tmpArray containsObject:@"÷"])
    {
        [self setOnlySub:tmpArray];
    }
    else if (![tmpArray containsObject:@"＋"] && ![tmpArray containsObject:@"－"] && [tmpArray containsObject:@"×"] && ![tmpArray containsObject:@"÷"])
    {
        [self setMultiResutl:tmpArray];
    }
    else if (![tmpArray containsObject:@"＋"] && ![tmpArray containsObject:@"－"] && ![tmpArray containsObject:@"×"] && [tmpArray containsObject:@"÷"])
    {
        [self setOnlyDivid:tmpArray];
    }
    else if ([tmpArray containsObject:@"＋"] && [tmpArray containsObject:@"－"] && ![tmpArray containsObject:@"×"] && ![tmpArray containsObject:@"÷"])
    {
        [self setOnlySub:tmpArray];
        
    }
    else if (![tmpArray containsObject:@"＋"] && ![tmpArray containsObject:@"－"] && [tmpArray containsObject:@"×"] && [tmpArray containsObject:@"÷"])
    {
        
        [self setDividResutl:tmpArray];
        
    }
    else
    {
        [self setDividResutl:tmpArray];
    }
    
}

//加减乘除运算

//乘
-(void )setMultiResutl:(NSMutableArray *)tmpArray
{
    for(int i = 0;i < tmpArray.count;i++)
    {
        if([tmpArray[i] isEqualToString:@"×"])
        {
            if(i>0)
            {
                NSDecimalNumber *number1 = [NSDecimalNumber decimalNumberWithString:tmpArray[i-1]];
                
                NSDecimalNumber *number2 = [NSDecimalNumber decimalNumberWithString:tmpArray[i+1]];
                
                NSDecimalNumber  * multiNum = [number1 decimalNumberByMultiplyingBy:number2];
                
                [tmpArray replaceObjectAtIndex:i withObject:[NSString stringWithFormat:@"%@",multiNum]];
                
                [tmpArray removeObjectAtIndex:i-1];
                
                [tmpArray removeObjectAtIndex:i];
                
                
            }
            
        }
    }
    
    if([tmpArray containsObject:@"×"])
    {
        
        [self setMultiResutl:tmpArray];
    }
    else if([tmpArray containsObject:@"÷"])
    {
        
        [self setDividResutl:tmpArray];
    }
    else if([tmpArray containsObject:@"－"])
    {
        [self setSubResutl:tmpArray];
    }
    else if ([tmpArray containsObject:@"＋"])
    {
        [self setOnlySum:tmpArray];
    }
    else
    {
        
    }
    
    [self.tmpLabel1 setText:[NSString stringWithFormat:@"%@",tmpArray[0]]];
}
//除
-(void)setDividResutl:(NSMutableArray *)tmpArray
{
    for(int i = 0;i < tmpArray.count;i++)
    {
        if ([tmpArray[i] isEqualToString:@"÷"])
        {
            if(i>0)
            {
                NSDecimalNumber *number1 = [NSDecimalNumber decimalNumberWithString:tmpArray[i-1]];
                
                NSDecimalNumber *number2 = [NSDecimalNumber decimalNumberWithString:tmpArray[i+1]];
                
                NSDecimalNumber  * dividNum = [number1 decimalNumberByDividingBy:number2];
                
                [tmpArray replaceObjectAtIndex:i withObject:[NSString stringWithFormat:@"%@",dividNum]];
                
                [tmpArray removeObjectAtIndex:i-1];
                
                [tmpArray removeObjectAtIndex:i];
                
            }
            
        }
    }
    
    if([tmpArray containsObject:@"÷"])
    {
        
        [self setDividResutl:tmpArray];
    }
    else if([tmpArray containsObject:@"×"])
    {
        [self setMultiResutl:tmpArray];
    }
    else if([tmpArray containsObject:@"－"])
    {
        [self setSubResutl:tmpArray];
    }
    else if ([tmpArray containsObject:@"＋"])
    {
        [self setOnlySum:tmpArray];
    }
    else
    {
        
    }
    
    
    [self.tmpLabel1 setText:[NSString stringWithFormat:@"%@",tmpArray[0]]];
}

//加
-(void)setSumResutl:(NSMutableArray *)tmpArray
{
    
    for(int i = 0;i < tmpArray.count;i++)
    {
        if([tmpArray[i] isEqualToString:@"＋"])
        {
            if(i>0)
            {
                NSDecimalNumber *number1 = [NSDecimalNumber decimalNumberWithString:tmpArray[i-1]];
                
                NSDecimalNumber *number2 = [NSDecimalNumber decimalNumberWithString:tmpArray[i+1]];
                
                NSDecimalNumber  * sumNum = [number1 decimalNumberByAdding:number2];
                
                [tmpArray replaceObjectAtIndex:i withObject:[NSString stringWithFormat:@"%@",sumNum]];
                
                [tmpArray removeObjectAtIndex:i-1];
                
                [tmpArray removeObjectAtIndex:i];
                
                
            }
            
        }
    }
    if([tmpArray containsObject:@"＋"])
    {
        say(@"lalal");
        
        [self setSumResutl:tmpArray];
    }
    
    [self.tmpLabel1 setText:[NSString stringWithFormat:@"%@",tmpArray[0]]];
}
//减
-(void)setSubResutl:(NSMutableArray *)tmpArray
{
    
    for(int i = 0;i < tmpArray.count;i++)
    {
        if([tmpArray[i] isEqualToString:@"－"])
        {
            if(i>0)
            {
                NSDecimalNumber *number1 = [NSDecimalNumber decimalNumberWithString:tmpArray[i-1]];
                
                NSDecimalNumber *number2 = [NSDecimalNumber decimalNumberWithString:tmpArray[i+1]];
                
                NSDecimalNumber  * subNum = [number1 decimalNumberBySubtracting:number2];
                
                [tmpArray replaceObjectAtIndex:i withObject:[NSString stringWithFormat:@"%@",subNum]];
                
                [tmpArray removeObjectAtIndex:i-1];
                
                [tmpArray removeObjectAtIndex:i];
                
            }
            
            
        }
    }
    
    if([tmpArray containsObject:@"－"])
    {
        
        
        [self setSubResutl:tmpArray];
    }
    else if([tmpArray containsObject:@"＋"])
    {
        
        [self setSumResutl:tmpArray];
    }
    
    [self.tmpLabel1 setText:[NSString stringWithFormat:@"%@",tmpArray[0]]];
    
}

//只有乘
-(void)setOnlyMulti:(NSMutableArray *)tmparrray
{
    [self setMultiResutl:tmparrray];
}
//只有除
-(void)setOnlyDivid:(NSMutableArray *)tmparrray
{
    [self setDividResutl:tmparrray];
}
//只有加
-(void)setOnlySum:(NSMutableArray *)tmparrray
{
    [self setSumResutl:tmparrray];
}
//只有减
-(void)setOnlySub:(NSMutableArray *)tmparrray
{
    [self setSubResutl:tmparrray];
}


#pragma mark - 非默认会员登陆

-(void)UnDefaultmemberLogininQr:(NSString *)memberName{
    
    NSString *temp = @"/sites/api/?url=user/signin";
    NSString *string = [cckdURL stringByAppendingString:temp];//会员登录接口
    NSDictionary *dic = @{
                          @"name": memberName,
                          };
    
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:dic success:^(id obj) {
        
    } successOne:^(id responseObject) {
        LLog(@"bb%@",responseObject);
        //存会员登陆id 与购物车同步使用判断事哪个会员买的商品
        NSUserDefaults *userDefault =[NSUserDefaults standardUserDefaults];
        [userDefault setObject:responseObject[@"data"][@"session"][@"sid"] forKey:@"member_token"];
        [userDefault setObject:responseObject[@"data"][@"session"][@"uid"] forKey:@"member_user_id"];
        [userDefault synchronize];
        
        QrCodeViewController *vc = [[QrCodeViewController alloc]init];
        [weakSelf.navigationController pushViewController:vc animated:YES];
        
        self.alertView_Qr.frame = CGRectMake(-Screen_W, 0 , Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT);
        
    } successZero:^(id responseObject) {
        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //say(@"token改变，登陆过期");
            [weakSelf showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
            
        }else{
            
            [weakSelf showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:^{
           
            } andActionCancelTitle:@"取消" andActionCancelBlock:^{
                
            } andBool:YES];
        }
    } fail:^(NSError *error) {
        
        NSString *alterString = @"数据加载失败，请检查网络！";
        [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:^{
          
        } andActionCancelTitle:@"取消" andActionCancelBlock:^{
            
        } andBool:YES];
    }];
    
}


-(void)UnDefaultmemberLoginin:(NSString *)memberName{
    
    NSString *temp = @"/sites/api/?url=user/signin";
    NSString *string = [cckdURL stringByAppendingString:temp];//会员登录接口
    NSDictionary *dic = @{
                          @"name": memberName,
                          };
    
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:dic success:^(id obj) {
        
    } successOne:^(id responseObject) {
        LLog(@"bb%@",responseObject);
        //存会员登陆id 与购物车同步使用判断事哪个会员买的商品
        NSUserDefaults *userDefault =[NSUserDefaults standardUserDefaults];
        [userDefault setObject:responseObject[@"data"][@"session"][@"sid"] forKey:@"member_token"];
        [userDefault setObject:responseObject[@"data"][@"session"][@"uid"] forKey:@"member_user_id"];
        [userDefault synchronize];
        
        OptionalGoodsController *vc = [[OptionalGoodsController alloc]init];
        [weakSelf.navigationController pushViewController:vc animated:YES];
        
        self.alertView.frame = CGRectMake(Screen_W, 0 , Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT);
        
    } successZero:^(id responseObject) {
        
        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //say(@"token改变，登陆过期");
            [weakSelf showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
            
            
        }else{
            
            [weakSelf showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:^{
                
            } andActionCancelTitle:@"取消" andActionCancelBlock:^{
                
            } andBool:YES];
        }
    } fail:^(NSError *error) {
        
        NSString *alterString = @"数据加载失败，请检查网络！";
        [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:^{
            
        } andActionCancelTitle:@"取消" andActionCancelBlock:^{
            
        } andBool:YES];
    }];
    
}


//提示框小装 show = yes 有取消按钮。=no只有确定一个按钮__weak typeof(self) weakSelf = self;
-(void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message andActionTitle:(NSString *)actionTitle andactionBlock:(void(^)(void))ActionBlock andActionCancelTitle:(NSString *)actionCancelTitle andActionCancelBlock:(void(^)(void))ActionCancelBlock andBool:(BOOL)show {
    
    if (show) {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:actionCancelTitle style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionCancelBlock) {
                ActionCancelBlock();
            }
        }];
        [alert addAction:actionCancel];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }else{
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}


-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [_memberLoginField resignFirstResponder];
    [_memberLoginField_Qr resignFirstResponder];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
