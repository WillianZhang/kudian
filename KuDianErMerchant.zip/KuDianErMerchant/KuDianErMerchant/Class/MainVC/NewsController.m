//
//  NewsController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//

#import "NewsController.h"
#import "SettingController.h"

@interface NewsController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic, strong) UITableView *newsTableView;

@end
@implementation NewsController
static NSString *identufuer = @"cellReuse";

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = Color(240, 240, 240);
    self.title = @"消息";
//    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:23],NSForegroundColorAttributeName:[UIColor cyanColor]}];
    //为导航栏添加右侧按钮1
    UIBarButtonItem *right1 = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"set"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStyleDone target:self action:@selector(pushToSettingVC)];
   
    self.navigationItem.rightBarButtonItem = right1;
    [self creatUI];
}

-(void)creatUI{
    self.newsTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT) style:UITableViewStylePlain];
//    _newsTableView.separatorColor = [UIColor blackColor];
//    _newsTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _newsTableView.delegate = self;
    _newsTableView.dataSource = self;
    _newsTableView.rowHeight = k_withBasedIphone6(60);
    [_newsTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:identufuer];
    
    [self.view addSubview:_newsTableView];
}

//UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 20;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identufuer];
    
    UIImageView *image = [MyUIClass makeUIImageWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(5), k_withBasedIphone6(50), k_withBasedIphone6(50)) andPicName:@""];
    
    UILabel *tit = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(75), k_withBasedIphone6(5), k_withBasedIphone6(100), k_withBasedIphone6(30)) andText:@"VIP会员通知" andTextColor:Color(51, 51, 51) andFontSize:16 andAlignment:NSTextAlignmentLeft];
    
    UILabel *tittle = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(75), k_withBasedIphone6(35), k_withBasedIphone6(280), k_withBasedIphone6(20)) andText:@"这里是一条测试用的通知内容" andTextColor:Color(200, 200, 200) andFontSize:14 andAlignment:NSTextAlignmentLeft];
    
    UILabel *time = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(295), k_withBasedIphone6(5), k_withBasedIphone6(60), k_withBasedIphone6(30)) andText:@"7月9日" andTextColor:Color(200, 200, 200) andFontSize:14 andAlignment:NSTextAlignmentRight];
    
    [cell addSubview:image];
    [cell addSubview:tit];
    [cell addSubview:tittle];
    [cell addSubview:time];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    say(@"点击cell");
}


-(void)pushToSettingVC{
    
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    //改变返回按钮颜色
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    SettingController *vc = [[SettingController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    
}

-(void)viewWillDisappear:(BOOL)animated{
    self.navigationController.navigationBar.barTintColor = Color(7, 196, 190);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
