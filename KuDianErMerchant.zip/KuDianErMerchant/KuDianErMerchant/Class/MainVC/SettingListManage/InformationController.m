//
//  InformationController.m
//  KuDianErMerchant
//
//  Created by william on 2018/8/22.
//  Copyright © 2018年 william. All rights reserved.
//

#import "InformationController.h"
#import "NewsController.h"


@interface InformationController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic ,strong)NSString * avator_img;
@property(nonatomic ,strong)NSString * role_name;
@property(nonatomic ,strong)NSString * username;
@property(nonatomic ,strong)NSString * mobile;
@property(nonatomic ,strong)NSString * last_login;
@property(nonatomic ,strong)NSString * seller_name;
@property(nonatomic ,strong)NSString * last_ip;
@end

static NSString * information = @"informationCell";
@implementation InformationController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = Color(240, 240, 240);
    self.title = @"账户设置";
    
    //为导航栏添加右侧按钮2
    UIBarButtonItem *right2 = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"message"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStyleDone target:self action:@selector(pushToNewsVC)];
    
    self.navigationItem.rightBarButtonItem = right2;
    
    //userinfoDic
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSDictionary *seller_id = [userDefault objectForKey:@"userinfoDic"];
    self.role_name = @"蓝色海洋";
    self.username = [seller_id objectForKey:@"username"];
    self.mobile = [seller_id objectForKey:@"mobile"];
    self.last_login = [seller_id objectForKey:@"last_login"];
    self.seller_name = [seller_id objectForKey:@"seller_name"];
    self.last_ip = [seller_id objectForKey:@"last_ip"];
    
    
    [self creatUI];
    

}

-(void)creatUI{
    
    UITableView *tab = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT) style:UITableViewStylePlain];
    
    tab.delegate = self;
    tab.dataSource = self;
   
    
    [tab registerClass:[UITableViewCell class] forCellReuseIdentifier:information];
    
    [self.view addSubview:tab];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 9;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:information];
    

    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (indexPath.row == 0) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        
        CGRect frame = CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(30), k_withBasedIphone6(80), k_withBasedIphone6(20));
        UILabel *lab = [MyUIClass simpleLabelWithFrame:frame andText:@"头像" andTextColor:Color(30, 30, 30) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
        [cell addSubview:lab];
        
        UIImageView *imgView = [[UIImageView alloc]initWithFrame:CGRectMake(k_withBasedIphone6(280),k_withBasedIphone6(10), k_withBasedIphone6(60), k_withBasedIphone6(60))];
        imgView.backgroundColor = [UIColor yellowColor];
        [cell addSubview:imgView];
        
    }else if (indexPath.row ==1) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        

        CGRect frame = CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(20), k_withBasedIphone6(80), k_withBasedIphone6(20));
        UILabel *lab = [MyUIClass simpleLabelWithFrame:frame andText:@"昵称" andTextColor:Color(30, 30, 30) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
        [cell addSubview:lab];
        
        CGRect labD = CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(20), k_withBasedIphone6(240), k_withBasedIphone6(20));
        UILabel *labDetal = [MyUIClass simpleLabelWithFrame:labD andText:_role_name andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentRight];
        [cell addSubview:labDetal];
        
       
    }else if (indexPath.row == 2){
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        CGRect frame = CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(20), k_withBasedIphone6(80), k_withBasedIphone6(20));
        UILabel *lab = [MyUIClass simpleLabelWithFrame:frame andText:@"姓名" andTextColor:Color(30, 30, 30) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
        [cell addSubview:lab];
        
        CGRect labD = CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(20), k_withBasedIphone6(240), k_withBasedIphone6(20));
        UILabel *labDetal = [MyUIClass simpleLabelWithFrame:labD andText:_username andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentRight];
        [cell addSubview:labDetal];
        
    }else if (indexPath.row == 3){
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        CGRect frame = CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(20), k_withBasedIphone6(80), k_withBasedIphone6(20));
        UILabel *lab = [MyUIClass simpleLabelWithFrame:frame andText:@"电话" andTextColor:Color(30, 30, 30) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
        [cell addSubview:lab];
        
        CGRect labD = CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(20), k_withBasedIphone6(240), k_withBasedIphone6(20));
        UILabel *labDetal = [MyUIClass simpleLabelWithFrame:labD andText:_mobile andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentRight];
        [cell addSubview:labDetal];
        
    }else if (indexPath.row == 4){
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        CGRect frame = CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(20), k_withBasedIphone6(80), k_withBasedIphone6(20));
        UILabel *lab = [MyUIClass simpleLabelWithFrame:frame andText:@"上次登陆" andTextColor:Color(30, 30, 30) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
        [cell addSubview:lab];
        
        CGRect labD = CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(20), k_withBasedIphone6(240), k_withBasedIphone6(20));
        UILabel *labDetal = [MyUIClass simpleLabelWithFrame:labD andText:_last_login andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentRight];
        [cell addSubview:labDetal];
        
    }else if (indexPath.row == 5){
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        CGRect frame = CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(20), k_withBasedIphone6(80), k_withBasedIphone6(20));
        UILabel *lab = [MyUIClass simpleLabelWithFrame:frame andText:@"商铺名称" andTextColor:Color(30, 30, 30) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
        [cell addSubview:lab];
        
        CGRect labD = CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(20), k_withBasedIphone6(240), k_withBasedIphone6(20));
        UILabel *labDetal = [MyUIClass simpleLabelWithFrame:labD andText:_seller_name andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentRight];
        [cell addSubview:labDetal];
        
    }else if (indexPath.row == 6){
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        CGRect frame = CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(20), k_withBasedIphone6(80), k_withBasedIphone6(20));
        UILabel *lab = [MyUIClass simpleLabelWithFrame:frame andText:@"登陆地址" andTextColor:Color(30, 30, 30) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
        [cell addSubview:lab];
        
        CGRect labD = CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(20), k_withBasedIphone6(240), k_withBasedIphone6(20));
        UILabel *labDetal = [MyUIClass simpleLabelWithFrame:labD andText:_last_ip andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentRight];
        [cell addSubview:labDetal];
        
    }else if (indexPath.row == 7){
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        CGRect frame = CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(20), k_withBasedIphone6(80), k_withBasedIphone6(20));
        UILabel *lab = [MyUIClass simpleLabelWithFrame:frame andText:@"密码管理" andTextColor:Color(30, 30, 30) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
        [cell addSubview:lab];
        
        CGRect labD = CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(20), k_withBasedIphone6(240), k_withBasedIphone6(20));
        UILabel *labDetal = [MyUIClass simpleLabelWithFrame:labD andText:@"重置" andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentRight];
        [cell addSubview:labDetal];
        
    }else{
       
        
        UILabel *lab  = [[UILabel alloc]initWithFrame:CGRectMake(0, 0,Screen_W, k_withBasedIphone6(60))];
         lab.textAlignment = NSTextAlignmentCenter;
        lab.font = [UIFont systemFontOfSize:17.0];
        lab.text = @"退出";
        [cell addSubview:lab];
        
    }
    
 
    return cell;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    say(@"%ld",(long)indexPath.row);
    
    if (indexPath.row == 8) {
        
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        [userDefault removeObjectForKey:@"Token"];
        [userDefault removeObjectForKey:@"member_token"];
        [userDefault removeObjectForKey:@"member_user_id"];
        [userDefault removeObjectForKey:@"Seller_id"];
        [userDefault removeObjectForKey:@"userinfoDic"];
        [userDefault synchronize];
        
        NSString *token = [userDefault objectForKey:@"Token"];
        NSString *membertoken = [userDefault objectForKey:@"member_token"];
        say(@"🐯ii%@-%@",token,membertoken);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"changeRootVC" object:self];//通知，修改viewcontroller成跟视图
    }
}



-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row == 0) {
        return k_withBasedIphone6(80);
    }else{
        return k_withBasedIphone6(60);
    }
}



-(void)pushToNewsVC{
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    //改变返回按钮颜色
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    NewsController *vc = [[NewsController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
