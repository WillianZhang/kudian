//
//  SettingController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//

#import "SettingController.h"
#import "LoginController.h"
#import "NewsController.h"
#import "SettingController.h"

#import "InformationController.h"//账户设置

@interface SettingController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic, strong) UITableView *setTableView;
@property(nonatomic, strong) NSArray *imgArray;
@property(nonatomic, strong) NSArray *titleArray;

@end

@implementation SettingController
static NSString *idenfuerSet = @"cellSet";

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = Color(240, 240, 240);
    self.title = @"设置";
    
   
    
    [self creatUI];
    
    self.imgArray = @[@"",@"",@"",@"",@"",@"",@"",@"",@"",@""];
    self.titleArray = @[@"账户设置",@"商户认证",@"结算设置",@"会员设置",@"权限设置",@"店铺推广",@"营销设置",@"酷点儿联盟",@"打印设置",@"安全设置"];
    
  
    //为导航栏添加右侧按钮2
    UIBarButtonItem *right2 = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"message"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStyleDone target:self action:@selector(pushToNewsVC)];
  
    self.navigationItem.rightBarButtonItem = right2;
}

-(void)creatUI{
    //userinfoDic
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSDictionary *seller_id = [userDefault objectForKey:@"userinfoDic"];
    NSString *username = [seller_id objectForKey:@"username"];
    NSString *mobile = [seller_id objectForKey:@"mobile"];
    say(@"%@-%@",username,mobile);
    
    self.setTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H-IPHONE_X_NAV_HEIGHT) style:UITableViewStylePlain];
    //_memberListTableView.separatorColor = [UIColor blackColor];
    _setTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _setTableView.delegate = self;
    _setTableView.dataSource = self;
    _setTableView.rowHeight = k_withBasedIphone6(50);
    [_setTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:idenfuerSet];
    [self.view addSubview:_setTableView];
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, k_withBasedIphone6(750), k_withBasedIphone6(100))];
    headerView.backgroundColor = Color(230, 230, 230);
    _setTableView.tableHeaderView = headerView;
    
    UIImageView *headImg = [MyUIClass makeUIImageWithFrame:CGRectMake(k_withBasedIphone6(50), k_withBasedIphone6(20), k_withBasedIphone6(60), k_withBasedIphone6(60)) andPicName:@""];
    headImg.backgroundColor = [UIColor orangeColor];
    headImg.layer.masksToBounds = YES;
    headImg.layer.cornerRadius = k_withBasedIphone6(30);
    [headerView addSubview:headImg];
    
    UILabel *nameLabel = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(120), k_withBasedIphone6(30), k_withBasedIphone6(150), k_withBasedIphone6(20)) andText:username andTextColor:Color(51, 51, 51) andFontSize:14.0 andAlignment:NSTextAlignmentLeft];
    [headerView addSubview:nameLabel];
    
    UILabel *telLabel = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(120), k_withBasedIphone6(50), k_withBasedIphone6(150), k_withBasedIphone6(20)) andText:mobile andTextColor:Color(51, 51, 51) andFontSize:13.0 andAlignment:NSTextAlignmentLeft];
    [headerView addSubview:telLabel];
    
    
    
    
}

//UITableViewDataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _titleArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:idenfuerSet];
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;//cell的右边有一个小箭头，距离右边有十几像素；
    cell.selectionStyle = UITableViewCellSelectionStyleNone;//点击无阴影
    UILabel *memberID = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(50), k_withBasedIphone6(15), k_withBasedIphone6(90), k_withBasedIphone6(20)) andText:@"13633231473" andTextColor:Color(51, 51, 51) andFontSize:14 andAlignment:NSTextAlignmentLeft];

    memberID.text = _titleArray[indexPath.row];

    [cell addSubview:memberID];

    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    say(@"点击cell-%ld",(long)indexPath.row);
    switch (indexPath.row) {
        case 0:
            [self loginOut];

            
            break;
        case 1:
            
            break;
        case 2:
            
            break;
        case 3:
            
            break;
        case 4:
            
            break;
        case 5:
            
            break;
        case 6:
            
            break;
        case 7:
            
            break;
        case 8:
            
            break;
        case 9:
            
            break;
            
        default:
            break;
    }
  
}

-(void)loginOut{
    

    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    //改变返回按钮颜色
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    InformationController *vc = [[InformationController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    
}


-(void)pushToNewsVC{
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    //改变返回按钮颜色
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    NewsController *vc = [[NewsController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
