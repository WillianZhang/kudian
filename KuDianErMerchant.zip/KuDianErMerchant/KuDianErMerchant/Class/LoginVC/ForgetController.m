//
//  ForgetController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/13.
//  Copyright © 2018年 william. All rights reserved.
//

#import "ForgetController.h"
#import "ResetController.h"

@interface ForgetController ()<UIPickerViewDelegate,UIPickerViewDataSource>

@property(nonatomic , strong) NSArray *numArray;
@property(nonatomic , strong) NSArray *countryArray;
@property(nonatomic , strong) UIPickerView *pickerView;
@property(nonatomic,strong) UIButton *btnClose;
@property(nonatomic,strong) UILabel *label;
@property(nonatomic,strong) UILabel *labDetail;

@end

@implementation ForgetController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"找回密码";
    self.view.backgroundColor = Color(255, 255, 255);
  
    [self creatUI];
    
    _numArray = [[NSArray alloc]initWithObjects:@"+86",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",nil];
    _countryArray = [[NSArray alloc]initWithObjects:@"中国",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",nil];
}

-(void)creatUI{
    self.label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(40), k_withBasedIphone6(55), k_withBasedIphone6(30)) andText:@"+86" andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
    _label.backgroundColor = [UIColor yellowColor];
    [self.view addSubview:_label];
    
    self.labDetail = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(40), k_withBasedIphone6(180), k_withBasedIphone6(30)) andText:@"中国" andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
    _labDetail.backgroundColor = [UIColor yellowColor];
    [self.view addSubview:_labDetail];
    
    UIButton *pickerBtn = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(270), k_withBasedIphone6(40), k_withBasedIphone6(85), k_withBasedIphone6(30)) andType:UIButtonTypeCustom andImageName:@"" andTarget:self andSelector:@selector(creatUIPickerView) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [self.view addSubview:pickerBtn];
    
    
    for (int i = 0; i < 2; i++) {
        
        UIView *line = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(78)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(335), k_withBasedIphone6(2)) andBackColor:Color(222, 222, 222)];
        [self.view addSubview:line];
        
       
    }
 
        
        UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(95), k_withBasedIphone6(65), k_withBasedIphone6(30)) andText:@"手机号" andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
        label.backgroundColor = [UIColor yellowColor];
        [self.view addSubview:label];
        
       UITextField *filed = [MyUIClass simpleTextFieldWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(95), k_withBasedIphone6(180), k_withBasedIphone6(30)) andPlaceHolder:@"填写手机号" andClearBtnMode:UITextFieldViewModeWhileEditing andBackColor:Color(255, 255, 255) andFontSize:15.0];
        [self.view addSubview:filed];
        
        
    UIButton *nextBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(50), k_withBasedIphone6(230), k_withBasedIphone6(275), k_withBasedIphone6(44)) andType:UIButtonTypeCustom andBackColor:Color(94, 202, 214) andTitle:@"下一步" andTitleFontSize:18.0 andTitleColor:Color(255, 255, 255) andTarget:self andSelector:@selector(pushToNextVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
  
    [self.view addSubview:nextBtn];
    
    
}

- (UIPickerView *)pickerView{
    
    if (!_pickerView) {
        
        self.pickerView = [[UIPickerView alloc] init];
        
    }
    
    return _pickerView;
    
}
-(void)creatUIPickerView{
    
    self.pickerView.frame = CGRectMake(k_withBasedIphone6(60), k_withBasedIphone6(100), k_withBasedIphone6(250), k_withBasedIphone6(150));
    self.pickerView.backgroundColor = Color(94, 202, 214);
    // 显示选中框
    _pickerView.showsSelectionIndicator=YES;
    _pickerView.dataSource = self;
    _pickerView.delegate = self;
    [self.view addSubview:_pickerView];
    self.btnClose = [UIButton buttonWithType:(UIButtonTypeSystem)];
    _btnClose.frame = CGRectMake(k_withBasedIphone6(60), k_withBasedIphone6(220), k_withBasedIphone6(250), k_withBasedIphone6(30));
    [_btnClose setTitle:@"确定" forState:(UIControlStateNormal)];
    [_btnClose setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    _btnClose.backgroundColor = Color(116, 195, 255);
    _btnClose.titleLabel.font = [UIFont systemFontOfSize:19];
    [_btnClose addTarget:self action:@selector(close) forControlEvents:(UIControlEventTouchUpInside)];
    [self.view addSubview:_btnClose];
    
    
}
#pragma Mark -- UIPickerViewDataSource
// pickerView 列数
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 2;
}

// pickerView 每列个数
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [_numArray count];
    //    if (component == 0) {
    //        return [_numArray count];
    //    }
    //
    //    return [_countryArray count];
}
// 每列宽度
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    return k_withBasedIphone6(120);
   
}


//返回当前行的内容,此处是将数组中数值添加到滚动的那个显示栏上
-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (component == 0) {
        _label.text = [_numArray objectAtIndex:row];
        return [_numArray objectAtIndex:row];
    } else {
        _labDetail.text = [_countryArray objectAtIndex:row];
        return [_countryArray objectAtIndex:row];
        
    }
}


#pragma mark -- 按钮点击事件

-(void)pushToNextVC{
    
//    UITextField *textField = (UITextField *)[self.view viewWithTag:1000];
//    if ([textField.text isEqualToString:@""])
//    {
//        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请填写正确的手机号" preferredStyle:UIAlertControllerStyleAlert];
//        UIAlertAction *action = [UIAlertAction actionWithTitle:@"知道了" style:(UIAlertActionStyleDefault) handler:nil];
//        [alert addAction:action];
//        [self presentViewController:alert animated:YES completion:nil];
//    }
//    else
//    {
//
//    }
    
    ResetController *vc = [[ResetController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
 
}


//选择器上的关闭按钮
- (void)close{
    
    [ _pickerView removeFromSuperview];
    [_btnClose removeFromSuperview];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
