//
//  ResetSuccessController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/13.
//  Copyright © 2018年 william. All rights reserved.
//

#import "ResetSuccessController.h"

@interface ResetSuccessController ()

@end

@implementation ResetSuccessController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"密码重置成功";
    self.view.backgroundColor = Color(255, 255, 255);
   
    [self creatUI];
}

-(void)creatUI{
    
    UIButton *to_loginBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(50), k_withBasedIphone6(230), k_withBasedIphone6(275), k_withBasedIphone6(44)) andType:UIButtonTypeCustom andBackColor:Color(94, 202, 214) andTitle:@"重新登录" andTitleFontSize:18.0 andTitleColor:Color(255, 255, 255) andTarget:self andSelector:@selector(pushToLoginVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    
    [self.view addSubview:to_loginBtn];
}

-(void)pushToLoginVC{
    
    [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:1] animated:YES];
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
