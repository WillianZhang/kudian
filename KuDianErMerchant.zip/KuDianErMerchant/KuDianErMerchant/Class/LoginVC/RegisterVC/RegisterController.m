//
//  RegisterController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//

#import "RegisterController.h"
#import <WebKit/WebKit.h>
#import "DFYSVP.h"
//#import "LoginController.h"


@interface RegisterController ()<WKNavigationDelegate,WKUIDelegate,WKScriptMessageHandler>
@property (nonatomic ,strong) WKWebView *webView;
@property (nonatomic ,strong) WKWebViewConfiguration *configuration;

/*
//<UIPickerViewDelegate,UIPickerViewDataSource>
//{
//    int _time;
//    NSTimer *_timer;
//}
//
//@property(nonatomic , strong) NSArray *numArray;
//@property(nonatomic , strong) NSArray *countryArray;
//@property(nonatomic , strong) UIPickerView *pickerView;
//@property(nonatomic,strong) UIButton *btnClose;
//@property(nonatomic,strong) UILabel *label;
//@property(nonatomic,strong) UILabel *labDetail;
 */

@end

@implementation RegisterController

-(void)viewWillAppear:(BOOL)animated{
    //这是删除所有缓存和cookie的
    NSSet *websiteDataTypes = [WKWebsiteDataStore allWebsiteDataTypes];
    //// Date from
    NSDate *dateFrom = [NSDate dateWithTimeIntervalSince1970:0];
    //// Execute
    [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:websiteDataTypes modifiedSince:dateFrom completionHandler:^{
        // Done
        say(@"已经清楚");
    }];
}

- (void)viewDidLoad{
    [super viewDidLoad];
    self.title = @"注册";
    //晴空返回按钮上文字
//    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:nil action:nil];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];//改变返回按钮颜色
    self.navigationController.navigationBarHidden = NO;//是否隐藏导航
    self.navigationController.navigationBar.barTintColor = Color(7, 196, 190);//导航栏颜色
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName :  [UIColor whiteColor]};//导航栏标题颜色
    self.view.backgroundColor = Color(240, 240, 240);
 
    
    DFYSVPLoading(@"请稍等...", NO);
//    //http://ecjia.cckdtj.com/sites/m/index.php?m=newfranchisee&c=index&a=first&typeTo=ios
    NSString *string = [cckdURL stringByAppendingString:@"/sites/m/index.php?m=newfranchisee&c=index&a=first&typeTo=ios"];
    
    self.configuration = [[WKWebViewConfiguration alloc] init];
    [_configuration.userContentController addScriptMessageHandler:self name:@"scan"];

    self.webView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, Screen_W, Screen_H-64) configuration:_configuration];
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:string]]];
    self.webView.navigationDelegate = self;
    self.webView.UIDelegate = self;
    //开了支持滑动返回
    self.webView.allowsBackForwardNavigationGestures = YES;
    [self.view addSubview:self.webView];
    

}


// 页面加载完成之后调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    
   [DFYSVP dismiss];
    
}

//提交发生错误时调用
- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    DFYSVPError(@"获取信息失败");
}


- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message{
    say(@"xxxxxxxxxxxx");
    if ([message.name isEqualToString:@"scan"]) {
        //调用原生通知代码 app delegate中注册的通知 切换登陆页为跟视图控制器
       [[NSNotificationCenter defaultCenter] postNotificationName:@"changeRootVC" object:self];//通知，修改Login成跟视图
    }
}
#pragma mark WKUIDelegate
//在JS端调用alert函数时，会触发此代理方法。
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:message?:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:([UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler();
    }])];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL))completionHandler{
    //    DLOG(@"msg = %@ frmae = %@",message,frame);
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:message?:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:([UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(NO);
    }])];
    [alertController addAction:([UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(YES);
    }])];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * _Nullable))completionHandler{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:prompt message:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.text = defaultText;
    }];
    [alertController addAction:([UIAlertAction actionWithTitle:@"完成" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(alertController.textFields[0].text?:@"");
    }])];
    [self presentViewController:alertController animated:YES completion:nil];
}

-(WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures
{
    if (!navigationAction.targetFrame.isMainFrame) {
        [webView loadRequest:navigationAction.request];
    }
    return nil;
}


-(void)dealloc{
    say(@"注册页面释放了吗？");
    
}

//退出页面释放内存
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    ///关闭web页时会释放内存
    [self.configuration.userContentController removeScriptMessageHandlerForName:@"scan"];
    self.webView.navigationDelegate = nil;
    self.webView.UIDelegate = nil;
}












/*
//- (void)viewDidLoad {
//    [super viewDidLoad];
//    self.navigationController.navigationBarHidden = NO;
//    self.title = @"注册";
//    self.view.backgroundColor = Color(255, 255, 255);
//    _time = 60;
//    [self creatUI];
//
//    _numArray = [[NSArray alloc]initWithObjects:@"+86",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",nil];
//    _countryArray = [[NSArray alloc]initWithObjects:@"中国",@"美国",@"日本",@"4",@"5",@"6",@"7",@"8",@"9",@"10",nil];
//}
//
//-(void)creatUI{
//    self.label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(40), k_withBasedIphone6(55), k_withBasedIphone6(30)) andText:@"+86" andTextColor:Color(50, 50, 50) andFontSize:17.0 andAlignment:NSTextAlignmentLeft];
//    _label.backgroundColor = [UIColor yellowColor];
//    [self.view addSubview:_label];
//
//    self.labDetail = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(40), k_withBasedIphone6(180), k_withBasedIphone6(30)) andText:@"中国" andTextColor:Color(50, 50, 50) andFontSize:17.0 andAlignment:NSTextAlignmentLeft];
//    _labDetail.backgroundColor = [UIColor yellowColor];
//    [self.view addSubview:_labDetail];
//
//
//    for (int i = 0; i < 6; i++) {
//
//        UIView *line = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(78)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(335), k_withBasedIphone6(2)) andBackColor:Color(222, 222, 222)];
//        [self.view addSubview:line];
//
//        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
//        btn.frame = CGRectMake(k_withBasedIphone6(270), k_withBasedIphone6(40)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(85), k_withBasedIphone6(30));
//        btn.tag = 20+i;
//        [self.view addSubview:btn];
//
//        if (btn.tag == 20) {
//            btn.backgroundColor = [UIColor lightGrayColor];
//            [btn addTarget:self action:@selector(creatUIPickerView) forControlEvents:UIControlEventTouchUpInside];
//        }else if (btn.tag == 21){
//            btn.backgroundColor = Color(205, 190, 150);
//            btn.titleLabel.font = [UIFont systemFontOfSize:14.0];
//            [btn setTitle:@"获取验证码" forState:(UIControlStateNormal)];
//            [btn addTarget:self action:@selector(getMobile) forControlEvents:UIControlEventTouchUpInside];
//        }else{
//
//        }
//    }
//    NSArray *arr = @[@"手机号",@"验证码",@"密码",@"确认密码",@"推荐码"];
//    NSArray *array = @[@"填写手机号",@"填写手机验证码",@"填写6～12位密码",@"重新输入密码",@"推荐码，如没有可不填"];
//    for (int i = 0; i < 5; i++) {
//
//        UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(95)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(65), k_withBasedIphone6(30)) andText:@"" andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
//        label.text = arr[i];
//        label.tag = i;
//        label.backgroundColor = [UIColor yellowColor];
//        [self.view addSubview:label];
//
//
//        UITextField *filed = [MyUIClass simpleTextFieldWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(95)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(180), k_withBasedIphone6(30)) andPlaceHolder:array[i] andClearBtnMode:UITextFieldViewModeWhileEditing andBackColor:[UIColor yellowColor] andFontSize:15.0];
//        filed.tag = 10+i;
//        [self.view addSubview:filed];
//
//
//    }
//
//    UIButton *btn_protocol = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(80), k_withBasedIphone6(380), k_withBasedIphone6(15), k_withBasedIphone6(15)) andType:UIButtonTypeCustom andImageName:@"未选中" andTarget:self andSelector:@selector(btn_protocol) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//    [self.view addSubview:btn_protocol];
//
//    UILabel *lab_protocol = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(380), k_withBasedIphone6(215), k_withBasedIphone6(15)) andText:@"我已阅读并同意《条款007》" andTextColor:Color(51, 51, 51) andFontSize:12.0 andAlignment:NSTextAlignmentLeft];
//    [self.view addSubview:lab_protocol];
//
//
//    UIButton *btn_protocol_Next = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(80), k_withBasedIphone6(400), k_withBasedIphone6(15), k_withBasedIphone6(15)) andType:UIButtonTypeCustom andImageName:@"未选中" andTarget:self andSelector:@selector(btn_protocol_Next) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//    [self.view addSubview:btn_protocol_Next];
//
//    UILabel *lab_protocol_Next = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(100), k_withBasedIphone6(400), k_withBasedIphone6(120), k_withBasedIphone6(15)) andText:@"同意加入酷点儿联盟" andTextColor:Color(51, 51, 51) andFontSize:12.0 andAlignment:NSTextAlignmentLeft];
//    [self.view addSubview:lab_protocol_Next];
//
//    UIButton *protocal_descripe_Btn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(230), k_withBasedIphone6(400), k_withBasedIphone6(65), k_withBasedIphone6(15)) andType:UIButtonTypeCustom andBackColor:Color(255, 255, 255) andTitle:@"酷点儿联盟说明" andTitleFontSize:11.0 andTitleColor:Color(94, 202, 214) andTarget:self andSelector:@selector(protocal_descripe) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//    [self.view addSubview:protocal_descripe_Btn];
//
//
//
//    UIButton *regiserBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(50), k_withBasedIphone6(440), k_withBasedIphone6(275), k_withBasedIphone6(45)) andType:UIButtonTypeCustom andBackColor:Color(94, 202, 214) andTitle:@"注册" andTitleFontSize:14.0 andTitleColor:Color(255, 255, 255) andTarget:self andSelector:@selector(toRegiser) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//        [self.view addSubview:regiserBtn];
//
//    UIButton *loginBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(210), k_withBasedIphone6(500), k_withBasedIphone6(110), k_withBasedIphone6(15)) andType:UIButtonTypeCustom andBackColor:Color(255, 255, 255) andTitle:@"已有账号，请登陆" andTitleFontSize:12.0 andTitleColor:Color(94, 202, 214) andTarget:self andSelector:@selector(pushToLoginVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//    [self.view addSubview:loginBtn];
//
//
//}
//
//- (UIPickerView *)pickerView{
//
//    if (!_pickerView) {
//
//        self.pickerView = [[UIPickerView alloc] init];
//
//    }
//
//    return _pickerView;
//
//}
//-(void)creatUIPickerView{
//
//    self.pickerView.frame = CGRectMake(k_withBasedIphone6(60), k_withBasedIphone6(100), k_withBasedIphone6(250), k_withBasedIphone6(150));
//    self.pickerView.backgroundColor = Color(94, 202, 214);
//    // 显示选中框
//    _pickerView.showsSelectionIndicator=YES;
//    _pickerView.dataSource = self;
//    _pickerView.delegate = self;
//    [self.view addSubview:_pickerView];
//    self.btnClose = [UIButton buttonWithType:(UIButtonTypeSystem)];
//    _btnClose.frame = CGRectMake(k_withBasedIphone6(60), k_withBasedIphone6(220), k_withBasedIphone6(250), k_withBasedIphone6(30));
//    [_btnClose setTitle:@"确定" forState:(UIControlStateNormal)];
//    [_btnClose setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
//    _btnClose.backgroundColor = Color(116, 195, 255);
//    _btnClose.titleLabel.font = [UIFont systemFontOfSize:19];
//    [_btnClose addTarget:self action:@selector(close) forControlEvents:(UIControlEventTouchUpInside)];
//    [self.view addSubview:_btnClose];
//
//
//}
//#pragma Mark -- UIPickerViewDataSource
//// pickerView 列数
//- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
//    return 2;
//}
//
//// pickerView 每列个数
//- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
//    return [_numArray count];
//    //    if (component == 0) {
//    //        return [_numArray count];
//    //    }
//    //
//    //    return [_countryArray count];
//}
//// 每列宽度
//- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
//    return k_withBasedIphone6(120);
//    //    if (component == 1) {
//    //        return 40;
//    //    }
//    //    return 180;
//}
//// 返回选中的行
////- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
////{
////    if (component == 0) {
////        NSString  *_proNameStr = [_numArray objectAtIndex:row];
////        say(@"nameStr=%@",_proNameStr);
////    } else {
////        NSString  *_proTimeStr = [_countryArray objectAtIndex:row];
////        say(@"_proTimeStr=%@",_proTimeStr);
////    }
////
////}
//
////返回当前行的内容,此处是将数组中数值添加到滚动的那个显示栏上
//-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
//{
//    if (component == 0) {
//        _label.text = [_numArray objectAtIndex:row];
//        return [_numArray objectAtIndex:row];
//    } else {
//        _labDetail.text = [_countryArray objectAtIndex:row];
//        return [_countryArray objectAtIndex:row];
//
//    }
//}
//
//
//#pragma mark -- 按钮点击事件
//
//
//-(void)btn_protocol{
//
//}
//
//-(void)btn_protocol_Next{
//
//}
//
//-(void)protocal_descripe{
//
//}
//
//-(void)toRegiser{
////     [[NSNotificationCenter defaultCenter] postNotificationName:@"back" object:self];//通知，修改MAIN成跟视图
//}
//-(void)pushToLoginVC{
//
//}
//
//
////选择器上的关闭按钮
//- (void)close{
//
//    [ _pickerView removeFromSuperview];
//    [_btnClose removeFromSuperview];
//}
//
//
//
//- (void)getMobile
//{
//    say(@"getMobilegetMobile");
//    UITextField *textField = (UITextField *)[self.view viewWithTag:1000];
//    if ([textField.text isEqualToString:@""])
//    {
//        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请填写正确的手机号" preferredStyle:UIAlertControllerStyleAlert];
//        UIAlertAction *action = [UIAlertAction actionWithTitle:@"知道了" style:(UIAlertActionStyleDefault) handler:nil];
//        [alert addAction:action];
//        [self presentViewController:alert animated:YES completion:nil];
//    }
//    else
//    {
//        if (_time == 60 || _time == 0)
//        {
//            say(@"开始倒计时");
//
//            [self.view endEditing:YES];
//
//
//            //开启定时器
//            [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(time:) userInfo:nil repeats:YES];
//            say(@"成功");
//            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"发送成功" preferredStyle:UIAlertControllerStyleAlert];
//            UIAlertAction *action = [UIAlertAction actionWithTitle:@"知道了" style:(UIAlertActionStyleDefault) handler:nil];
//            [alert addAction:action];
//            [self presentViewController:alert animated:YES completion:nil];
//
//
//        }
//    }
//
//}
//
//// 获取验证码
//- (void)time:(NSTimer *)timer
//{
//    UIButton *_btnGet = (UIButton *)[self.view viewWithTag:21];
//    if (_time == 0) {
//        say(@"走了吗aaaaa");
//        [timer invalidate];
//        timer = nil;
//        //_jiShiLab.text = @"重新获取";
//        [_btnGet setTitle:@"重新获取" forState:(UIControlStateNormal)];
//        _time = 60;
//    }else
//    {
//        say(@"走了吗bbb");
//        [self.view reloadInputViews];
//        [_btnGet setTitle:[NSString stringWithFormat:@"%ds",_time] forState:(UIControlStateNormal)];
//        //_jiShiLab.text = [NSString stringWithFormat:@"%d秒后重新获取",_time];
//        _time -=  1;
//    }
//}
//
//- (void)didReceiveMemoryWarning {
//    [super didReceiveMemoryWarning];
//    // Dispose of any resources that can be recreated.
//}
//
//- (void)dealloc
//{
//    say(@"RegisterController.h");
//}
*/
@end
