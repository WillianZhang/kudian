//
//  LoginController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//

#import "LoginController.h"
#import "MainController.h"
#import "ForgetController.h"
#import "RegisterController.h"
#import "DFYSVP.h"

@interface LoginController ()<UIPickerViewDelegate,UIPickerViewDataSource>
{
    int _time;
    NSTimer *_timer;
}

@property(nonatomic , strong) NSArray *numArray;
@property(nonatomic , strong) NSArray *countryArray;
@property(nonatomic , strong) UIPickerView *pickerView;
@property(nonatomic,strong) UIButton *btnClose;
@property(nonatomic,strong) UILabel *label;
@property(nonatomic,strong) UILabel *labDetail;
@property(nonatomic,strong) UILabel *label_user;
@property(nonatomic,strong) UILabel *labDetail_user;

@property(nonatomic,strong) UIView *view_userName_password_login;
@property(nonatomic,strong) UIView *view_phone_login;
@property(nonatomic,strong) UIButton *loginStyleBtn;
@end

@implementation LoginController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [[NSURLCache sharedURLCache] removeAllCachedResponses];//每次进入登陆页 af清空缓存
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    self.title = @"登陆";
    self.view.backgroundColor = Color(255, 255, 255);
    _time = 60;
    [self creatUI];
    
    _numArray = [[NSArray alloc]initWithObjects:@"+86",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",nil];
    _countryArray = [[NSArray alloc]initWithObjects:@"中国",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",nil];
  
}


-(void)creatUI{
  //电话验证码登陆
    self.view_phone_login = [MyUIClass makeUIViewWithFrame:CGRectMake(0, 0, Screen_W, k_withBasedIphone6(320)) andBackColor:Color(255, 255, 255)];
    _view_phone_login.hidden = YES;
    [self.view addSubview:_view_phone_login];
    
    
    self.label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(40), k_withBasedIphone6(55), k_withBasedIphone6(30)) andText:@"+86" andTextColor:Color(50, 50, 50) andFontSize:17.0 andAlignment:NSTextAlignmentLeft];
//    _label.backgroundColor = [UIColor yellowColor];
    [_view_phone_login addSubview:_label];
    
    self.labDetail = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(40), k_withBasedIphone6(180), k_withBasedIphone6(30)) andText:@"中国" andTextColor:Color(50, 50, 50) andFontSize:17.0 andAlignment:NSTextAlignmentLeft];
//    _labDetail.backgroundColor = [UIColor yellowColor];
    [_view_phone_login addSubview:_labDetail];

    
    for (int i = 0; i < 3; i++) {
        
        UIView *line = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(78)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(335), k_withBasedIphone6(2)) andBackColor:Color(222, 222, 222)];
        [_view_phone_login addSubview:line];
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(k_withBasedIphone6(270), k_withBasedIphone6(40)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(85), k_withBasedIphone6(30));
        btn.tag = 20+i;
        [_view_phone_login addSubview:btn];

        if (btn.tag == 20) {
            btn.backgroundColor = [UIColor lightGrayColor];
            [btn addTarget:self action:@selector(creatUIPickerView) forControlEvents:UIControlEventTouchUpInside];
        }else if (btn.tag == 21){
            btn.backgroundColor = Color(205, 190, 150);
            btn.titleLabel.font = [UIFont systemFontOfSize:14.0];
            [btn setTitle:@"获取验证码" forState:(UIControlStateNormal)];
            [btn addTarget:self action:@selector(getMobile) forControlEvents:UIControlEventTouchUpInside];
        }else{
            
        }
    }
    NSArray *arr = @[@"手机号",@"验证码"];
    NSArray *array = @[@"填写手机号",@"填写手机验证码"];
    for (int i = 0; i < 2; i++) {
        
        UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(95)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(65), k_withBasedIphone6(30)) andText:arr[i] andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
//        label.backgroundColor = [UIColor yellowColor];
        [_view_phone_login addSubview:label];
        
       
        UITextField *filed = [MyUIClass simpleTextFieldWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(95)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(180), k_withBasedIphone6(30)) andPlaceHolder:array[i] andClearBtnMode:UITextFieldViewModeWhileEditing andBackColor:Color(255, 255, 255) andFontSize:15.0];
        filed.tag = i;
        [_view_phone_login addSubview:filed];
        
        
    }
    
    UIButton *loginBtn_phone = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(50), k_withBasedIphone6(270), k_withBasedIphone6(275), k_withBasedIphone6(44)) andType:1 andTitle:@"登陆" andTitleFontSize:18.0 andImageName:nil andTarget:self andSelector:@selector(phone_login) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    loginBtn_phone.backgroundColor = Color(94, 202, 214);
    [loginBtn_phone setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_view_phone_login addSubview:loginBtn_phone];
    
//账号密码登陆
    
    self.view_userName_password_login = [MyUIClass makeUIViewWithFrame:CGRectMake(0, 0, Screen_W, k_withBasedIphone6(320)) andBackColor:Color(255, 255, 255)];
    [self.view addSubview:_view_userName_password_login];
    
    self.label_user = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(40), k_withBasedIphone6(55), k_withBasedIphone6(30)) andText:@"+86" andTextColor:Color(50, 50, 50) andFontSize:17.0 andAlignment:NSTextAlignmentLeft];
//    _label_user.backgroundColor = [UIColor yellowColor];
    [_view_userName_password_login addSubview:_label_user];
    
    self.labDetail_user = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(40), k_withBasedIphone6(180), k_withBasedIphone6(30)) andText:@"中国" andTextColor:Color(50, 50, 50) andFontSize:17.0 andAlignment:NSTextAlignmentLeft];
//    _labDetail_user.backgroundColor = [UIColor yellowColor];
    [_view_userName_password_login addSubview:_labDetail_user];
    
    
//    UIButton *creatPickerBtn = [MyUIClass makeImageButtonWithFrame:CGRectMake(k_withBasedIphone6(325), k_withBasedIphone6(40), k_withBasedIphone6(30), k_withBasedIphone6(30)) andType:UIButtonTypeCustom andImageName:@"右箭头" andTarget:self andSelector:@selector(creatUIPickerView) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//    [creatPickerBtn setEnlargeEdgeWithTop:0 right:k_withBasedIphone6(50) bottom:0 left:0];
//    [_view_userName_password_login addSubview:creatPickerBtn];
    
    
    for (int i = 0; i < 3; i++) {
        
        UIView *line = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(78)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(335), k_withBasedIphone6(2)) andBackColor:Color(222, 222, 222)];
        [_view_userName_password_login addSubview:line];
        
       
    }
    NSArray *arr_user = @[@"账号",@"密码"];
    NSArray *array_user = @[@"请填写账号或手机号",@"6～16位登陆密码"];
    for (int i = 0; i < 2; i++) {
        
        UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(95)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(65), k_withBasedIphone6(30)) andText:arr_user[i] andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
//        label.backgroundColor = [UIColor yellowColor];
        [_view_userName_password_login addSubview:label];
        
        
        UITextField *filed = [MyUIClass simpleTextFieldWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(95)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(180), k_withBasedIphone6(30)) andPlaceHolder:array_user[i] andClearBtnMode:UITextFieldViewModeWhileEditing andBackColor:Color(255, 255, 255) andFontSize:15.0];
        filed.tag = 10+i;
        [_view_userName_password_login addSubview:filed];
        
        
    }
    
    UIButton *loginBtn_user = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(50), k_withBasedIphone6(270), k_withBasedIphone6(275), k_withBasedIphone6(44)) andType:1 andTitle:@"登陆" andTitleFontSize:18.0 andImageName:nil andTarget:self andSelector:@selector(userNameLogin) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    loginBtn_user.backgroundColor = Color(94, 202, 214);
    [loginBtn_user setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_view_userName_password_login addSubview:loginBtn_user];
    
    
    
//    self.loginStyleBtn = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(50), k_withBasedIphone6(370), k_withBasedIphone6(150), k_withBasedIphone6(30)) andType:1 andTitle:@"使用验证码登陆" andTitleFontSize:14.0 andImageName:nil andTarget:self andSelector:@selector(changeLoginStyle:) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//    [_loginStyleBtn setTitleColor:Color(94, 202, 214) forState:UIControlStateNormal];
//    [self.view addSubview:_loginStyleBtn];
//
//    UIButton *loginByWechat = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(245), k_withBasedIphone6(370), k_withBasedIphone6(80), k_withBasedIphone6(30)) andType:1 andTitle:@"微信登陆" andTitleFontSize:14.0 andImageName:nil andTarget:self andSelector:@selector(wechatLogin) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//    [loginByWechat setTitleColor:Color(94, 202, 214) forState:UIControlStateNormal];
//    [self.view addSubview:loginByWechat];
//
//    UIButton *resetPassword = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(120), k_withBasedIphone6(500), k_withBasedIphone6(70), k_withBasedIphone6(30)) andType:1 andTitle:@"找回密码" andTitleFontSize:14.0 andImageName:nil andTarget:self andSelector:@selector(toResetPassword) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//    [resetPassword setTitleColor:Color(94, 202, 214) forState:UIControlStateNormal];
//    [self.view addSubview:resetPassword];
    
    UIButton *regiser = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(265), k_withBasedIphone6(325), k_withBasedIphone6(80), k_withBasedIphone6(30)) andType:1 andTitle:@"注册" andTitleFontSize:14.0 andImageName:nil andTarget:self andSelector:@selector(toRegiser) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    [regiser setTitleColor:Color(94, 202, 214) forState:UIControlStateNormal];
    [self.view addSubview:regiser];
//    UIButton *regiser = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(210), k_withBasedIphone6(500), k_withBasedIphone6(30), k_withBasedIphone6(30)) andType:1 andTitle:@"注册" andTitleFontSize:14.0 andImageName:nil andTarget:self andSelector:@selector(toRegiser) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
//    [regiser setTitleColor:Color(94, 202, 214) forState:UIControlStateNormal];
//    [self.view addSubview:regiser];
}

- (UIPickerView *)pickerView{
    
    if (!_pickerView) {
        
        self.pickerView = [[UIPickerView alloc] init];
        
    }
    
    return _pickerView;
    
}
-(void)creatUIPickerView{
   
//    self.pickerView.frame = CGRectMake(k_withBasedIphone6(60), k_withBasedIphone6(100), k_withBasedIphone6(250), k_withBasedIphone6(150));
//    self.pickerView.backgroundColor = Color(94, 202, 214);
//    // 显示选中框
//    _pickerView.showsSelectionIndicator=YES;
//    _pickerView.dataSource = self;
//    _pickerView.delegate = self;
//    [self.view addSubview:_pickerView];
//    self.btnClose = [UIButton buttonWithType:(UIButtonTypeSystem)];
//    _btnClose.frame = CGRectMake(k_withBasedIphone6(60), k_withBasedIphone6(220), k_withBasedIphone6(250), k_withBasedIphone6(30));
//    [_btnClose setTitle:@"确定" forState:(UIControlStateNormal)];
//    [_btnClose setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
//    _btnClose.backgroundColor = Color(116, 195, 255);
//    _btnClose.titleLabel.font = [UIFont systemFontOfSize:19];
//    [_btnClose addTarget:self action:@selector(close) forControlEvents:(UIControlEventTouchUpInside)];
//    [self.view addSubview:_btnClose];
    
    
}
#pragma Mark -- UIPickerViewDataSource
// pickerView 列数
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 2;
}

// pickerView 每列个数
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [_numArray count];
//    if (component == 0) {
//        return [_numArray count];
//    }
//
//    return [_countryArray count];
}
// 每列宽度
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    return k_withBasedIphone6(120);
//    if (component == 1) {
//        return 40;
//    }
//    return 180;
}
// 返回选中的行
//- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
//{
//    if (component == 0) {
//        NSString  *_proNameStr = [_numArray objectAtIndex:row];
//        say(@"nameStr=%@",_proNameStr);
//    } else {
//        NSString  *_proTimeStr = [_countryArray objectAtIndex:row];
//        say(@"_proTimeStr=%@",_proTimeStr);
//    }
//
//}

//返回当前行的内容,此处是将数组中数值添加到滚动的那个显示栏上
-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (component == 0) {
        _label.text = [_numArray objectAtIndex:row];
        _label_user.text = [_numArray objectAtIndex:row];
        return [_numArray objectAtIndex:row];
    } else {
        _labDetail_user.text = [_countryArray objectAtIndex:row];
        _labDetail.text = [_countryArray objectAtIndex:row];
        return [_countryArray objectAtIndex:row];
        
    }
}


#pragma mark -- 数据请求

-(void)parsing{
    
    UITextField *name = [(UITextField *)_view_userName_password_login viewWithTag:10];
    UITextField *password = [(UITextField *)_view_userName_password_login viewWithTag:11];
    
    NSString *temp = @"/sites/api/?url=admin/user/signin";
    NSString *URLString = [cckdURL stringByAppendingString:temp];

    NSDictionary *parameters = @{
                                 @"username": name.text,
                                 @"password": password.text
                                 };
    if ([name.text isEqualToString:@""] || [password.text isEqualToString:@""]) {
     
        [self showAlertWithTitle:@"温馨提示" andMessage:@"账号或密码输入为空" andActionTitle:@"确认" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
    }
    else{

        
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        //设置请求参数的类型:HTTP (AFJSONRequestSerializer,AFHTTPRequestSerializer)
        manager.requestSerializer = [AFHTTPRequestSerializer serializer];
        //设置请求的超时时间
        manager.requestSerializer.timeoutInterval = 20.f;
        //设置服务器返回结果的类型:JSON (AFJSONResponseSerializer,AFHTTPResponseSerializer)
        manager.responseSerializer = [AFJSONResponseSerializer serializer];
        
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html",@"text/plain", nil];
        __weak typeof(self) weakSelf = self;
        
        [manager POST:URLString parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSString * suc = [NSString stringWithFormat:@"%@",responseObject[@"status"][@"succeed"]];
            
            if ([suc isEqual:@"1"]) {
                
                //存数据
                say(@"🐲登陆解析a%@",responseObject);
                NSUserDefaults *userDefault =[NSUserDefaults standardUserDefaults];
                [userDefault setObject:responseObject[@"data"][@"session"][@"sid"] forKey:@"Token"];
                [userDefault setObject:responseObject[@"data"][@"userinfo"][@"seller_id"] forKey:@"Seller_id"];//店铺号用于拉取店家商品分类和列表
                [userDefault setObject:responseObject[@"data"][@"userinfo"] forKey:@"userinfoDic"];//店铺userinfo内详细信息
                [userDefault synchronize];
    
                [weakSelf memberLoginin]; //收银员登陆后 默认非会员的用户登陆
    
            }else{
                
                NSString *alterStr = responseObject[@"status"][@"error_desc"];
                
                if ([alterStr isEqualToString:@"Invalid session"]) {
                    
                    //say(@"token改变，登陆过期");
                    
                    [weakSelf showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                        
                        LoginController *vc = [[LoginController alloc]init];
                        [weakSelf.navigationController pushViewController:vc animated:YES];
                        
                    } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
                    
                    
                    
                }else{
                    
                    [weakSelf showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"重试" andactionBlock:^{
                        [weakSelf parsing];
                    } andActionCancelTitle:@"取消" andActionCancelBlock:^{
                        
                    } andBool:YES];
                }

            }
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            
            NSString *alterString = @"数据加载失败，请检查网络！";
            [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"重试" andactionBlock:^{
                [weakSelf parsing];
            } andActionCancelTitle:@"取消" andActionCancelBlock:^{
                
            } andBool:YES];

        }];
        
//        [[ZbwHttpRequest shardWebUtil]postNetworkRequestURLString:URLString parameters:parameters success:^(id obj) {
//
//        } successOne:^(id responseObject) {
//            //存数据
//            say(@"🐲登陆解析a%@",responseObject);
//
//            NSUserDefaults *userDefault =[NSUserDefaults standardUserDefaults];
//            [userDefault setObject:responseObject[@"data"][@"session"][@"sid"] forKey:@"Token"];
//            [userDefault setObject:responseObject[@"data"][@"userinfo"][@"seller_id"] forKey:@"Seller_id"];//店铺号用于拉取店家商品分类和列表
//            [userDefault setObject:responseObject[@"data"][@"userinfo"] forKey:@"userinfoDic"];//店铺userinfo内详细信息
//            [userDefault synchronize];
//
//            [weakSelf memberLoginin]; //收银员登陆后 默认非会员的用户登陆
//
//        } successZero:^(id responseObject) {
//
//            NSString *alterStr = responseObject[@"status"][@"error_desc"];
//
//            if ([alterStr isEqualToString:@"Invalid session"]) {
//
//                //say(@"token改变，登陆过期");
//
//                [weakSelf showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
//
//                    LoginController *vc = [[LoginController alloc]init];
//                    [weakSelf.navigationController pushViewController:vc animated:YES];
//
//                } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
//
//
//
//            }else{
//
//                [weakSelf showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"重试" andactionBlock:^{
//                    [weakSelf parsing];
//                } andActionCancelTitle:@"取消" andActionCancelBlock:^{
//
//                } andBool:YES];
//            }
//
//        } fail:^(NSError *error) {
//
//            NSString *alterString = @"数据加载失败，请检查网络！";
//            [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"重试" andactionBlock:^{
//                [weakSelf parsing];
//            } andActionCancelTitle:@"取消" andActionCancelBlock:^{
//
//            } andBool:YES];
//
//        }];

    }

}


//-(void)parsingSuccessBlock:(void(^)(void))SuccessBlock{
//    DFYSVPLoading(@"请稍后...", NO);
//        UITextView *name = [(UITextField *)_view_userName_password_login viewWithTag:10];
//        UITextView *password = [(UITextField *)_view_userName_password_login viewWithTag:11];
//    
//       NSString *URLString = @"http://ecjia.cckdtj.com/sites/api/?url=admin/user/signin";
//       [self.view endEditing:YES];
//    
//    if ([name.text isEqualToString:@""] || [password.text isEqualToString:@""]) {
//        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请输入用户名或密码" preferredStyle:(UIAlertControllerStyleAlert)];
//        UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:(UIAlertActionStyleDefault) handler:nil];
//        [alert addAction:action];
//        [self presentViewController:alert animated:YES completion:nil];
//    }
//    else{
//
//
//        NSDictionary *parameters = @{
//                                     @"username": @"18222660102" ,
//                                     @"password": @"185144"
//                                     };
//        [[MyHttpRequest shardWebUtil] postNetworkRequestURLString:URLString parameters:parameters success:^(id obj) {
//
//        } successOne:^(id responseObject) {
//            //存数据
//            say(@"🐲登陆解析a%@",responseObject);
//            NSUserDefaults *userDefault =[NSUserDefaults standardUserDefaults];
//            [userDefault setObject:responseObject[@"data"][@"session"][@"sid"] forKey:@"Token"];//商家token
//            [userDefault setObject:responseObject[@"data"][@"userinfo"][@"seller_id"] forKey:@"Seller_id"];//店铺号用于拉取店家商品分类和列表
//            [userDefault setObject:responseObject[@"data"][@"userinfo"][@"username"] forKey:@"Username"];//店铺使用用户名
//            [userDefault synchronize];
//
//            
//            if (SuccessBlock) {
//                SuccessBlock();
//            }
//
//            [DFYSVP dismiss];
//
//        } successZero:^(id responseObject) {
//            [DFYSVP dismiss];
//            NSString *alterStr = responseObject[@"status"][@"error_desc"];
//
//            if ([alterStr isEqualToString:@"Invalid session"]) {
//
//                //say(@"token改变，登陆过期");
//                __weak typeof(self) weakSelf = self;
//                [self showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
//                    
//                    LoginController *vc = [[LoginController alloc]init];
//                    [weakSelf.navigationController pushViewController:vc animated:YES];
//                    
//                } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
//
//
//
//            }else{
//
//                [self showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
//            }
//
//        } fail:^(NSError *error) {
//            [DFYSVP dismiss];
//           
//            NSString *alterString = @"数据加载失败，请检查网络！";
//            [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"确定" andactionBlock:nil andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
//
//        }];
//
//    }
//}



//点击登陆
-(void)userNameLogin{
    
    
    [self parsing];//以前的做法
    
    //登陆步骤一致，但是如果第一次安装没有任何token则登录进入主页////登陆过期的情况，登陆后返回当前页面
//    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
//    NSString *token = [userDefault objectForKey:@"Token"];
//    if (token) {
//
//        [userDefault removeObjectForKey:@"Token"];
//        [userDefault synchronize];
//        __weak typeof(self) weakSelf = self;
//        [self parsingSuccessBlock:^{
//
//            [weakSelf.navigationController popViewControllerAnimated:YES];
//        }];
//    }else{
//        __weak typeof(self) weakSelf = self;
//        [self parsingSuccessBlock:^{
//
//            MainController *vc = [[MainController alloc]init];
//            [weakSelf.navigationController pushViewController:vc animated:YES];
//        }];
//    }
    
    
}

-(void)phone_login{
//    UITextView *phone = [(UITextField *)_view_userName_password_login viewWithTag:1];
//    UITextView *sure = [(UITextField *)_view_userName_password_login viewWithTag:2];
}


-(void)changeLoginStyle:(UIButton *)btn{
    btn.selected = !btn.selected;
    if (btn.selected) {
        self.view_userName_password_login.hidden = YES;
        self.view_phone_login.hidden = NO;
        [self.loginStyleBtn setTitle:@"使用账号密码登陆" forState:UIControlStateNormal];
        
    }else{
        self.view_phone_login.hidden = YES;
        self.view_userName_password_login.hidden = NO;
        [self.loginStyleBtn setTitle:@"使用验证码登陆" forState:UIControlStateNormal];
     
    }
    
}


-(void)wechatLogin{
    
}

-(void)toResetPassword{
    
    ForgetController *vc = [[ForgetController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    
}

-(void)toRegiser{
    
    RegisterController *vc = [[RegisterController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    
}
//选择器上的关闭按钮
- (void)close{
    
    [ _pickerView removeFromSuperview];
    [_btnClose removeFromSuperview];
}



- (void)getMobile
{
    say(@"getMobilegetMobile");
    UITextField *textField = (UITextField *)[self.view viewWithTag:1000];
    if ([textField.text isEqualToString:@""])
    {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"请填写正确的手机号" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"知道了" style:(UIAlertActionStyleDefault) handler:nil];
        [alert addAction:action];
        [self presentViewController:alert animated:YES completion:nil];
    }
    else
    {
        if (_time == 60 || _time == 0)
        {
            say(@"开始倒计时");
            
            [self.view endEditing:YES];
            
            
            //开启定时器
            [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(time:) userInfo:nil repeats:YES];
            say(@"成功");
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"发送成功" preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *action = [UIAlertAction actionWithTitle:@"知道了" style:(UIAlertActionStyleDefault) handler:nil];
            [alert addAction:action];
            [self presentViewController:alert animated:YES completion:nil];
            
            
        }
    }
    
}

// 获取验证码
- (void)time:(NSTimer *)timer
{
    UIButton *_btnGet = (UIButton *)[self.view viewWithTag:21];
    if (_time == 0) {
        say(@"走了吗aaaaa");
        [timer invalidate];
        timer = nil;
        //_jiShiLab.text = @"重新获取";
        [_btnGet setTitle:@"重新获取" forState:(UIControlStateNormal)];
        _time = 60;
    }else
    {
        say(@"走了吗bbb");
        [self.view reloadInputViews];
        [_btnGet setTitle:[NSString stringWithFormat:@"%ds",_time] forState:(UIControlStateNormal)];
        //_jiShiLab.text = [NSString stringWithFormat:@"%d秒后重新获取",_time];
        _time -=  1;
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}


-(void)memberLoginin{
    
    NSString *temp = @"/sites/api/?url=user/signin";
    NSString *string = [cckdURL stringByAppendingString:temp];//会员登录接口
    NSDictionary *dic = @{
                          @"name": @"18502205299",
                          };
    
    __weak typeof(self) weakSelf = self;
    [[ZbwHttpRequest shardWebUtil] postNetworkRequestURLString:string parameters:dic success:^(id obj) {
        
    } successOne:^(id responseObject) {
        LLog(@"bb%@",responseObject);
        //存会员登陆id 与购物车同步使用判断事哪个会员买的商品
        NSUserDefaults *userDefault =[NSUserDefaults standardUserDefaults];
        [userDefault setObject:responseObject[@"data"][@"session"][@"sid"] forKey:@"defaultMember_token"];
        [userDefault setObject:responseObject[@"data"][@"session"][@"uid"] forKey:@"defaultMember_user_id"];
        [userDefault synchronize];
    
        MainController *vc = [[MainController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
        
    } successZero:^(id responseObject) {
        NSString *alterStr = responseObject[@"status"][@"error_desc"];
        
        if ([alterStr isEqualToString:@"Invalid session"]) {
            
            //say(@"token改变，登陆过期");
            [weakSelf showAlertWithTitle:@"提示" andMessage:@"登陆过期，请重新登录" andActionTitle:@"确定" andactionBlock:^{
                
                LoginController *vc = [[LoginController alloc]init];
                [weakSelf.navigationController pushViewController:vc animated:YES];
                
            } andActionCancelTitle:nil andActionCancelBlock:nil andBool:NO];
        
            
        }else{
            
            [weakSelf showAlertWithTitle:@"提示" andMessage:alterStr andActionTitle:@"重试" andactionBlock:^{
                [weakSelf memberLoginin];
            } andActionCancelTitle:@"取消" andActionCancelBlock:^{
                
            } andBool:YES];
        }
    } fail:^(NSError *error) {
        
        NSString *alterString = @"数据加载失败，请检查网络！";
        [self showAlertWithTitle:@"提示" andMessage:alterString andActionTitle:@"重试" andactionBlock:^{
            [weakSelf memberLoginin];
        } andActionCancelTitle:@"取消" andActionCancelBlock:^{
            
        } andBool:YES];
    }];
    
}


//提示框小装 show = yes 有取消按钮。=no只有确定一个按钮__weak typeof(self) weakSelf = self;
-(void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message andActionTitle:(NSString *)actionTitle andactionBlock:(void(^)(void))ActionBlock andActionCancelTitle:(NSString *)actionCancelTitle andActionCancelBlock:(void(^)(void))ActionCancelBlock andBool:(BOOL)show {
    
    if (show) {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:actionCancelTitle style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionCancelBlock) {
                ActionCancelBlock();
            }
        }];
        [alert addAction:actionCancel];
        
        [self presentViewController:alert animated:YES completion:nil];
        
    }else{
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            if (ActionBlock) {
                ActionBlock();
            }
        }];
        [alert addAction:action];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
