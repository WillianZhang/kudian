//
//  ResetController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/13.
//  Copyright © 2018年 william. All rights reserved.
//

#import "ResetController.h"
#import "ResetSuccessController.h"

@interface ResetController ()
{
    int _time;
    NSTimer *_timer;
}
@end

@implementation ResetController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"重置密码";
    self.view.backgroundColor = Color(255, 255, 255);
    _time = 60;
    [self creatUI];
    [self getMobile];
}

-(void)creatUI{
    
    NSArray *arr = @[@"验证码",@"设置密码"];
    NSArray *array = @[@"6位验证码",@"6～16位组合密码"];
    
    for (int i = 0; i < 2; i++) {
        
        UILabel *label = [MyUIClass simpleLabelWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(40)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(65), k_withBasedIphone6(30)) andText:arr[i] andTextColor:Color(50, 50, 50) andFontSize:15.0 andAlignment:NSTextAlignmentLeft];
        label.backgroundColor = [UIColor yellowColor];
        [self.view addSubview:label];
        
        
        UITextField *filed = [MyUIClass simpleTextFieldWithFrame:CGRectMake(k_withBasedIphone6(90), k_withBasedIphone6(40)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(180), k_withBasedIphone6(30)) andPlaceHolder:array[i] andClearBtnMode:UITextFieldViewModeWhileEditing andBackColor:[UIColor yellowColor] andFontSize:15.0];
        filed.tag = 10+i;
        [self.view addSubview:filed];
        
        UIView *line = [MyUIClass makeUIViewWithFrame:CGRectMake(k_withBasedIphone6(20), k_withBasedIphone6(78)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(335), k_withBasedIphone6(2)) andBackColor:Color(222, 222, 222)];
        [self.view addSubview:line];
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        
        btn.tag = 20+i;
        
        if (btn.tag == 20) {
            btn.frame = CGRectMake(k_withBasedIphone6(270), k_withBasedIphone6(40)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(85), k_withBasedIphone6(30));
            btn.backgroundColor = Color(205, 190, 150);
            btn.titleLabel.font = [UIFont systemFontOfSize:14.0];
//            [btn setTitle:@"获取验证码" forState:(UIControlStateNormal)];
            [btn addTarget:self action:@selector(getMobile) forControlEvents:UIControlEventTouchUpInside];
        }else if (btn.tag == 21){
            btn.frame = CGRectMake(k_withBasedIphone6(270), k_withBasedIphone6(40)+ k_withBasedIphone6(55)*i, k_withBasedIphone6(30), k_withBasedIphone6(30));
            [btn setImage:[UIImage imageNamed:@"眼睛-闭"] forState:UIControlStateNormal];
            [btn addTarget:self action:@selector(changeStaue) forControlEvents:UIControlEventTouchUpInside];
        }
        
        [self.view addSubview:btn];
    }
    
    
    UIButton *nextBtn = [MyUIClass makeTitleButtonWithFrame:CGRectMake(k_withBasedIphone6(50), k_withBasedIphone6(230), k_withBasedIphone6(275), k_withBasedIphone6(44)) andType:UIButtonTypeCustom andBackColor:Color(94, 202, 214) andTitle:@"确定重置" andTitleFontSize:18.0 andTitleColor:Color(255, 255, 255) andTarget:self andSelector:@selector(pushToNextVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    
    [self.view addSubview:nextBtn];
    
    
}


#pragma mark -- 按钮点击方法

-(void)pushToNextVC{
    
    ResetSuccessController *vc = [[ResetSuccessController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    
}

- (void)getMobile
{
    say(@"getMobilegetMobile");
  
        if (_time == 60 || _time == 0)
        {
            say(@"开始倒计时");
            
            [self.view endEditing:YES];
            
            
            //开启定时器
            [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(time:) userInfo:nil repeats:YES];
            say(@"成功");
//            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"发送成功" preferredStyle:UIAlertControllerStyleAlert];
//            UIAlertAction *action = [UIAlertAction actionWithTitle:@"知道了" style:(UIAlertActionStyleDefault) handler:nil];
//            [alert addAction:action];
//            [self presentViewController:alert animated:YES completion:nil];
            
            
        }
    
    
}

// 获取验证码
- (void)time:(NSTimer *)timer
{
    
    UIButton *btnGet = [(UIButton *)self.view viewWithTag:20];
    if (_time == 0) {
    
        [timer invalidate];
        timer = nil;
        [btnGet setTitle:@"重新获取" forState:(UIControlStateNormal)];
        _time = 60;
    }else
    {
        
        [self.view reloadInputViews];
        [btnGet setTitle:[NSString stringWithFormat:@"%ds",_time] forState:(UIControlStateNormal)];
        //_jiShiLab.text = [NSString stringWithFormat:@"%d秒后重新获取",_time];
        _time -=  1;
    }
}


int m = 1;
//点击切换密码明文输入
-(void)changeStaue{
    UITextField *newFiled = [(UIView *)self.view viewWithTag:11];
    UIButton *newBtn = [(UIButton *)self.view viewWithTag:21];
    if (m == 1) {
        newFiled.secureTextEntry = NO;
        [newBtn setImage:[UIImage imageNamed:@"眼睛-挣"] forState:UIControlStateNormal];
        m = 2;
    }else{
        newFiled.secureTextEntry = YES;
        [newBtn setImage:[UIImage imageNamed:@"眼睛-闭"] forState:UIControlStateNormal];
        m = 1;
    }
    
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
