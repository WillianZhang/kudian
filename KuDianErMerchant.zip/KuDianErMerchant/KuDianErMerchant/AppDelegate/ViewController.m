//
//  ViewController.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//

#import "ViewController.h"
#import "LoginController.h"
#import "RegisterController.h"

@interface ViewController ()

@end

@implementation ViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

- (void)viewDidLoad {
    self.title = @"";
    [super viewDidLoad];
    [self creatUI];

}

-(void)creatUI{
    
    UIImageView *imageV = [[UIImageView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    imageV.image = [UIImage imageNamed:@"welcome"];
    imageV.userInteractionEnabled = YES;
    [self.view addSubview:imageV];
    
    UIButton *btnLogin = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(30), k_withBasedIphone6(530), k_withBasedIphone6(140), k_withBasedIphone6(45)) andType:1 andTitle:@"登陆" andTitleFontSize:18.0 andImageName:nil andTarget:self andSelector:@selector(pushToLoginVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    btnLogin.backgroundColor = [UIColor whiteColor];
    [btnLogin setTitleColor:Color(106, 83, 69) forState:UIControlStateNormal];
    [imageV addSubview:btnLogin];
    
    UIButton *btnRegister = [MyUIClass makeUIButtonWithFrame:CGRectMake(k_withBasedIphone6(200), k_withBasedIphone6(530), k_withBasedIphone6(140), k_withBasedIphone6(45)) andType:1 andTitle:@"注册" andTitleFontSize:18.0 andImageName:nil andTarget:self andSelector:@selector(pushToRegisterVC) andEvent:UIControlEventTouchUpInside andState:UIControlStateNormal];
    btnRegister.backgroundColor = Color(217, 178, 121);
    [btnRegister setTitleColor:Color(255, 255, 255) forState:UIControlStateNormal];
    [imageV addSubview:btnRegister];
    
}


#pragma make -- 按钮点击事件
-(void)pushToLoginVC{
    
    LoginController *vc = [[LoginController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)pushToRegisterVC{
    
    RegisterController *vc = [[RegisterController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    say(@"ViewController.m");
}


//防止注册页面添加图片崩溃
//-(void)dismissViewControllerAnimated:(BOOL)flag completion:(void (^)(void))completion{
//    if ( self.presentedViewController){
//        [super dismissViewControllerAnimated:flag completion:completion];
//    }
//}

@end
