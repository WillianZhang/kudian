//
//  AppDelegate.m
//  KuDianErMerchant
//
//  Created by william on 2018/7/6.
//  Copyright © 2018年 william. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"
#import "MainController.h"
#import "LoginController.h"
#import "GoodsController.h"
#import "RegisterController.h"
#import "CreatQrController.h"
#import "PaySuccessController.h"


@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];

    NSString *token = [userDefault objectForKey:@"Token"];
    if(token != nil) {

        self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
        MainController *vc = [[MainController alloc]init];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:vc];
        nav.navigationBar.translucent = NO;
        self.window.rootViewController = nav;
        [self.window makeKeyAndVisible];

    }else{

        self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
        ViewController *nav = [[ViewController alloc]init];
        UINavigationController *navgation = [[UINavigationController alloc]initWithRootViewController:nav];
        navgation.navigationBar.translucent = NO;
        self.window.rootViewController = navgation;
        [self.window makeKeyAndVisible];

    }

//测试专用代码段。无实际意义
//            self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
//            UINavigationController *navgation = [[UINavigationController alloc]initWithRootViewController:[PaySuccessController new]];
//            navgation.navigationBar.translucent = NO;
//            self.window.rootViewController = navgation;
//            [self.window makeKeyAndVisible];

    
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(callBack)
                                                 name: @"back"
                                               object: nil];
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(changeRootVC)
                                                 name: @"changeRootVC"
                                               object: nil];
    
    return YES;
    
    
}

//main成为跟视图的通知：PaySuccessController页面在支付成功会出发通知
- (void)callBack{
    say(@"this is Notification.");
    
    MainController *nav = [[MainController alloc]init];
    UINavigationController *navv = [[UINavigationController alloc]initWithRootViewController:nav];
    navv.navigationBar.translucent = NO;
    
    self.window.rootViewController = navv;
    [self.window makeKeyAndVisible];
  
}

- (void)changeRootVC{
    say(@"this is changeRootVC.");
    
    LoginController *nav = [[LoginController alloc]init];
    UINavigationController *navv = [[UINavigationController alloc]initWithRootViewController:nav];
    navv.navigationBar.translucent = NO;
    
    self.window.rootViewController = navv;
    [self.window makeKeyAndVisible];
    
}

- (void)dealloc {
  
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"back" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"changeRootVC" object:nil];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
